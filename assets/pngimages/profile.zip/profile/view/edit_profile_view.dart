import 'dart:async';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../core/services/service_locator.dart';
import '../../../core/utils/extensions.dart';
import '../../../core/utils/phoneix.dart';
import '../../../core/widgets/app_btn.dart';
import '../../../core/widgets/app_field.dart';
import '../../../core/widgets/app_sheet.dart';
import '../../../core/widgets/custom_image.dart';
import '../../../core/widgets/flash_helper.dart';
import '../../../core/widgets/pick_image.dart';
import '../../../gen/locale_keys.g.dart';
import '../bloc/profile_bloc.dart';
import '../bloc/profile_events.dart';
import '../bloc/profile_states.dart';
import '../widgets/custom_date.dart';
import '../widgets/custom_edit_profile_app_bar.dart';
import '../widgets/custom_selected_container.dart';

class EditProfileView extends StatefulWidget {
  const EditProfileView({Key? key}) : super(key: key);

  @override
  State<EditProfileView> createState() => _EditProfileViewState();
}

class _EditProfileViewState extends State<EditProfileView> {
  final event = StartUpdateProfileEvent();
  final phoneEvent = StartUpdatePhoneEvent();
  final form = GlobalKey<FormState>(), phoneForm = GlobalKey<FormState>();
  final _buttonStream = StreamController<bool>();
  final _confirmEmailStream = StreamController<bool>();
  final bloc = sl<ProfileBloc>();

  @override
  void initState() {
    event.fullName.addListener(() => _buttonStream.add(event.canUpdate));
    event.height.addListener(() => _buttonStream.add(event.canUpdate));
    event.age.addListener(() => _buttonStream.add(event.canUpdate));
    event.weight.addListener(() => _buttonStream.add(event.canUpdate));
    event.skills.addListener(() => _buttonStream.add(event.canUpdate));
    event.email.addListener(() => _buttonStream.add(event.canUpdate));
    phoneEvent.phone.addListener(() => _confirmEmailStream.add(phoneEvent.canUpdate));

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomEditProfileAppBar(
        image: GestureDetector(
          onTap: () {
            showModalBottomSheet(
              context: context,
              builder: (context) => PickImage(
                title: LocaleKeys.change_profile_image.tr(),
              ),
            ).then((value) {
              if (value != null) {
                setState(() {
                  event.image = value;
                });
                _buttonStream.add(event.canUpdate);
              }
            });
          },
          child: CustomImage(
            event.image.path,
            height: 102.r,
            isFile: true,
            width: 102.r,
            fit: BoxFit.cover,
            borderRadius: BorderRadius.circular(500),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Form(
          key: form,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AppField(
                controller: event.fullName,
                labelText: LocaleKeys.name.tr(),
                labelColor: context.primaryColorLight.withOpacity(.8),
                hintText: LocaleKeys.full_name.tr(),
                fillColor: context.primaryColor,
              ).withPadding(horizontal: 16.w, vertical: 8.h, top: 8.h),
              Form(
                key: phoneForm,
                child: AbsorbPointer(
                  child: AppField(
                    controller: phoneEvent.phone,
                    initCountry: phoneEvent.country,
                    onChangeCountry: (country) => phoneEvent.country = country,
                    labelText: LocaleKeys.phone_number.tr(),
                    labelColor: context.primaryColorLight.withOpacity(.8),
                    hintText: LocaleKeys.phone_number.tr(),
                    fillColor: context.hintColor.withOpacity(.1),
                    margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                    keyboardType: TextInputType.phone,
                    suffixIcon: Container(
                      width: 80.w,
                      height: 60.h,
                      decoration: const BoxDecoration(),
                      alignment: Alignment.center,
                      // child: StreamBuilder<bool>(
                      //   stream: _confirmEmailStream.stream,
                      //   builder: (context, sna) {
                      //     return BlocConsumer<ProfileBloc, ProfileState>(
                      //       bloc: bloc,
                      //       listenWhen: (previous, current) => previous.updatePhoneState != current.updatePhoneState,
                      //       buildWhen: (previous, current) => previous.updatePhoneState != current.updatePhoneState,
                      //       listener: (context, state) {
                      //         if (state.updatePhoneState.isDone) {
                      //           showModalBottomSheet(
                      //             isScrollControlled: true,
                      //             context: context,
                      //             builder: (context) => BlocProvider.value(
                      //               value: bloc,
                      //               child: VerifyPhoneSheet(event: phoneEvent),
                      //             ),
                      //           ).then((value) {
                      //             if (value == true) _confirmEmailStream.add(phoneEvent.canUpdate);
                      //           });
                      //         }
                      //       },
                      //       builder: (context, state) {
                      //         if (state.updatePhoneState.isLoading) {
                      //           return const CustomProgress(size: 14).center;
                      //         }
                      //         return GestureDetector(
                      //           onTap: () => sna.data == true && phoneForm.isValid ? bloc.add(phoneEvent) : null,
                      //           child: Container(
                      //             margin: EdgeInsets.symmetric(vertical: 16.h, horizontal: 8.w),
                      //             padding: EdgeInsetsDirectional.symmetric(horizontal: 16.w, vertical: 6.h),
                      //             decoration: BoxDecoration(borderRadius: BorderRadius.circular(35.r), color: context.hoverColor.withOpacity(.1)),
                      //             child: Text(
                      //               LocaleKeys.edit.tr(),
                      //               style: context.mediumText.copyWith(
                      //                 fontSize: 14.sp,
                      //                 color: context.hoverColor.withOpacity(sna.data == true ? 1 : .2),
                      //                 height: 0,
                      //               ),
                      //             ),
                      //           ),
                      //         );
                      //       },
                      //     );
                      //   },
                      // ),
                    ),
                  ),
                ),
              ),
              AppField(
                controller: event.email,
                labelText: LocaleKeys.email.tr(),
                labelColor: context.primaryColorLight.withOpacity(.8),
                hintText: LocaleKeys.email.tr(),
                fillColor: context.primaryColor,
              ).withPadding(horizontal: 16.w, vertical: 8.h, top: 8.h),
              Text(
                LocaleKeys.demographic.tr(),
                style: context.semiboldText.copyWith(color: context.primaryColorLight),
              ).withPadding(top: 8.h, horizontal: 16.w),
              Row(
                children: [
                  Expanded(
                    child: AppField(
                      controller: event.weight,
                      labelText: LocaleKeys.weight.tr(),
                      keyboardType: TextInputType.number,
                      labelColor: context.primaryColorLight.withOpacity(.8),
                      isRequired: false,
                      fillColor: context.primaryColor,
                      suffixIcon: Text(
                        LocaleKeys.kg.tr(),
                        textAlign: TextAlign.end,
                        style: context.regularText.copyWith(color: context.primaryColorLight.withOpacity(.8)),
                      ).withPadding(vertical: 16.h, horizontal: 16.w),
                    ),
                  ),
                  SizedBox(width: 16.w),
                  Expanded(
                    child: AppField(
                      controller: event.height,
                      labelText: LocaleKeys.hight.tr(),
                      labelColor: context.primaryColorLight.withOpacity(.8),
                      keyboardType: TextInputType.number,
                      fillColor: context.primaryColor,
                      isRequired: false,
                      suffixIcon: Text(
                        LocaleKeys.cm.tr(),
                        textAlign: TextAlign.end,
                        style: context.regularText.copyWith(color: context.primaryColorLight.withOpacity(.8)),
                      ).withPadding(vertical: 16.h, horizontal: 16.w),
                    ),
                  ),
                ],
              ).withPadding(vertical: 8.h, horizontal: 16.w),
              AppField(
                  controller: event.age,
                  isRequired: false,
                  onTap: () {
                    showModalBottomSheet(
                      context: context,
                      builder: (context) {
                        return const CustomAppSheet(children: [DataOfBirth()]);
                      },
                    ).then((v) {
                      if (v != null) {
                        event.age.text = DateFormat('yyyy-MM-dd', "en").format(v['data']);
                      }
                    });
                  },
                  margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                  labelText: LocaleKeys.age.tr(),
                  labelColor: context.primaryColorLight.withOpacity(.8),
                  hintText: LocaleKeys.age.tr(),
                  fillColor: context.primaryColor),
              Text(
                LocaleKeys.gender.tr(),
                style: context.regularText.copyWith(color: context.primaryColorLight.withOpacity(.8), fontSize: 14.sp),
              ).withPadding(top: 8.h, horizontal: 16.w),
              Row(
                children: List.generate(
                  2,
                  (index) => Expanded(
                    child: CustomSelectedContainer(
                      isSelected: event.gender == ['male', 'female'][index],
                      title: ["male".tr(), "female".tr()][index],
                      onTap: () {
                        setState(() {
                          event.gender = ['male', 'female'][index];
                          _buttonStream.add(event.canUpdate);
                        });
                      },
                    ).withPadding(horizontal: 4.w),
                  ),
                ),
              ).withPadding(vertical: 8.h, horizontal: 8.w),
              Text(
                LocaleKeys.position.tr(),
                style: context.regularText.copyWith(color: context.primaryColorLight.withOpacity(.8), fontSize: 14.sp),
              ).withPadding(top: 8.h, horizontal: 16.w),
              Row(
                children: List.generate(
                  2,
                  (index) => Expanded(
                    child: CustomSelectedContainer(
                      isSelected: event.position == ['right', 'left'][index],
                      title: [LocaleKeys.right_position.tr(), LocaleKeys.left_position.tr()][index],
                      onTap: () {
                        setState(() {
                          event.position = ['right', 'left'][index];
                          _buttonStream.add(event.canUpdate);
                        });
                      },
                    ).withPadding(horizontal: 4.w),
                  ),
                ),
              ).withPadding(vertical: 8.h, horizontal: 8.w),
              Text(
                LocaleKeys.used_hand.tr(),
                style: context.regularText.copyWith(color: context.primaryColorLight.withOpacity(.8), fontSize: 14.sp),
              ).withPadding(top: 8.h, horizontal: 16.w),
              Row(
                children: List.generate(
                  2,
                  (index) => Expanded(
                    child: CustomSelectedContainer(
                      isSelected: event.usedHand == ['right', 'left'][index],
                      title: [LocaleKeys.right_hand.tr(), LocaleKeys.left_hand.tr()][index],
                      onTap: () {
                        setState(() {
                          event.usedHand = ['right', 'left'][index];
                          _buttonStream.add(event.canUpdate);
                        });
                      },
                    ).withPadding(horizontal: 4.w),
                  ),
                ),
              ).withPadding(vertical: 8.h, horizontal: 8.w),
              AppField(
                margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                isRequired: false,
                controller: event.skills,
                labelText: LocaleKeys.skills.tr(),
                labelColor: context.primaryColorLight.withOpacity(.8),
                hintText: LocaleKeys.the_lob.tr(),
                fillColor: context.primaryColor,
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: StreamBuilder<bool?>(
          stream: _buttonStream.stream,
          builder: (context, snapshot) {
            return BlocConsumer<ProfileBloc, ProfileState>(
              bloc: bloc,
              listenWhen: (previous, current) => previous.updateProfile != current.updateProfile,
              buildWhen: (previous, current) => previous.updateProfile != current.updateProfile,
              listener: (context, state) {
                if (state.updateProfile.isDone) {
                  Phoenix.rebirth(context);
                  _buttonStream.add(event.canUpdate);
                  FlashHelper.showToast(state.msg, type: MessageType.success);
                }
              },
              builder: (context, state) {
                return AppBtn(
                  loading: state.updateProfile.isLoading,
                  enable: snapshot.data == true,
                  onPressed: () => form.isValid ? bloc.add(event) : null,
                  title: LocaleKeys.edit_information.tr(),
                  backgroundColor: Colors.transparent,
                  borderColor: context.hoverColor,
                  textColor: context.hoverColor,
                );
              },
            ).withPadding(horizontal: 24.w, vertical: 20.h);
          }),
    );
  }
}
