import 'dart:math';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../models/user.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../blocs/static_pages/static_pages_bloc.dart';
import '../../../blocs/static_pages/static_pages_events.dart';
import '../../../blocs/static_pages/static_pages_states.dart';
import '../../../core/routes/app_routes_fun.dart';
import '../../../core/routes/routes.dart';
import '../../../core/services/service_locator.dart';
import '../../../core/utils/extensions.dart';
import '../../../core/widgets/confirmation_sheet.dart';
import '../../../core/widgets/custom_image.dart';
import '../../../gen/assets.gen.dart';
import '../../../gen/locale_keys.g.dart';
import '../../global/custom_row.dart';
import '../bloc/profile_bloc.dart';
import '../bloc/profile_events.dart';
import '../bloc/profile_states.dart';
import '../widgets/custom_profile_header.dart';

class ProfileView extends StatefulWidget {
  const ProfileView({Key? key}) : super(key: key);

  @override
  State<ProfileView> createState() => _ProfileViewState();
}

class _ProfileViewState extends State<ProfileView> {
  final bloc = sl<ProfileBloc>()..add(StartProfileEvent());
  final staticPagesBloc = sl<StaticPagesBloc>()..add(StartStaticPagesEvent());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          BlocProvider(
            create: (context) => bloc,
            child: const CustomProfileHeader(),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              child: Column(
                children: [
                  CustomRow(
                    onTap: () => push(NamedRoutes.wallet),
                    title: LocaleKeys.wallet.tr(),
                    icon: Assets.svg.wallet,
                    suffixIcon: Row(
                      children: [
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                          margin: EdgeInsetsDirectional.only(end: 8.w),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(50.r),
                            color: context.hoverColor.withOpacity(.1),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                UserModel.i.wallet,
                                style: context.mediumText.copyWith(fontSize: 14.sp, color: context.hoverColor),
                              ),
                              Text(
                                LocaleKeys.sar.tr(),
                                style: context.mediumText.copyWith(fontSize: 8.sp, color: context.hoverColor),
                              ),
                            ],
                          ),
                        ),
                        Transform.rotate(
                          angle: context.locale.languageCode == 'en' ? 0 : pi,
                          child: CustomImage(
                            Assets.svg.arrowRight,
                            width: 16.r,
                            height: 16.r,
                            fit: BoxFit.fill,
                            color: context.hintColor.withOpacity(.7),
                          ),
                        )
                      ],
                    ),
                  ),
                  CustomRow(
                    title: LocaleKeys.my_package.tr(),
                    icon: Assets.svg.pacakge,
                    onTap: () => push(NamedRoutes.myPackage),
                  ),
                  CustomRow(
                    onTap: () => push(NamedRoutes.rewords),
                    title: LocaleKeys.rewards.tr(),
                    icon: Assets.svg.rewards,
                  ),
                  CustomRow(
                    title: LocaleKeys.settings.tr(),
                    icon: Assets.svg.setting,
                    onTap: () => push(NamedRoutes.settings),
                  ),
                  BlocBuilder<StaticPagesBloc, StaticPagesState>(
                    bloc: staticPagesBloc,
                    builder: (context, state) => Column(
                      children: List.generate(
                        state.links.length,
                        (index) => CustomRow(
                          title: state.links[index].name.tr(),
                          icon: state.links[index].image ?? '',
                          onTap: () => launchUrl(state.links[index].data, mode: LaunchMode.externalApplication),
                        ),
                      ),
                    ),
                  ),
                  BlocConsumer<ProfileBloc, ProfileState>(
                    bloc: bloc,
                    listener: (context, state) {
                      if (state.logoutState.isDone) {
                        pushAndRemoveUntil(NamedRoutes.login);
                      }
                    },
                    builder: (context, state) {
                      return CustomRow(
                        loading: state.logoutState.isLoading,
                        title: LocaleKeys.log_out.tr(),
                        icon: Assets.svg.logout,
                        color: context.errorColor,
                        onTap: () => showModalBottomSheet(
                          context: context,
                          builder: (context) => ConfirmationSheet(
                            title: LocaleKeys.log_out.tr(),
                            trueBtn: LocaleKeys.log_out.tr(),
                            subtitle: LocaleKeys.are_you_sure_to_val.tr(args: [LocaleKeys.log_out.tr()]),
                          ),
                        ).then((value) {
                          if (value == true) bloc.add(StartLogoutEvent());
                        }),
                      );
                    },
                  ),
                  const SafeArea(top: false, child: SizedBox()),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
