import 'dart:io';

import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:padelgate/models/country.dart';
import 'package:share_plus/share_plus.dart';

import '../../../core/services/local_notifications_service.dart';
import '../../../models/user.dart';

class ProfileEvent {}

class StartLogoutEvent extends ProfileEvent {
  Future<Map<String, dynamic>> get body async => {
        'device_type': Platform.isAndroid ? 'android' : "ios",
        'device_token': await GlobalNotification.getFcmToken(),
      };

  StartLogoutEvent();
}

class StartUpdateProfileEvent extends ProfileEvent {
  final fullName = TextEditingController(text: UserModel.i.fullName);
  final height = TextEditingController(text: UserModel.i.height);
  final email = TextEditingController(text: UserModel.i.email);
  final age = TextEditingController(text: UserModel.i.dob != null ? DateFormat('yyyy-MM-dd', "en").format(UserModel.i.dob!) : null);

  final weight = TextEditingController(text: UserModel.i.weight);
  final skills = TextEditingController(text: UserModel.i.skills);
  String position = UserModel.i.position;
  String usedHand = UserModel.i.usedHand;
  String gender = UserModel.i.gender;
  XFile image = XFile(UserModel.i.image);

  Map<String, dynamic> get body => {
        if (!image.path.startsWith('http')) "image": MultipartFile.fromFileSync(image.path),
        "full_name": fullName.text,
        "height": height.text,
        "d_o_b": age.text,
        "weight": weight.text,
        "used_hand": usedHand,
        "email": email.text,
        "position": position,
        "gender": gender,
        "skills": skills.text,
      };

  StartUpdateProfileEvent();

  bool get canUpdate =>
      fullName.text != UserModel.i.fullName ||
      image.path != UserModel.i.image ||
      height.text != UserModel.i.height ||
      weight.text != UserModel.i.weight ||
      position != UserModel.i.position ||
      gender != UserModel.i.gender ||
      email.text != UserModel.i.email ||
      usedHand != UserModel.i.usedHand ||
      skills.text != UserModel.i.skills ||
      DateFormat('yyyy-MM-dd', "en").tryParse(age.text) != UserModel.i.dob;
}

class StartUpdatePhoneEvent extends ProfileEvent {
  bool isResend = false;
  final phone = TextEditingController(text: UserModel.i.phone);
  CountryModel country = CountryModel.fromJson({'flag': UserModel.i.flag, 'phone_code': UserModel.i.phoneCode, 'phone_limit': UserModel.i.phoneLimit});

  Map<String, dynamic> get body => {"phone": phone.text, "phone_code": country.phoneCode};

  StartUpdatePhoneEvent();

  bool get canUpdate => phone.text != UserModel.i.phone;
}

class StartVerifyEmailToUpdateEvent extends ProfileEvent {
  final String phone;
  final CountryModel country;

  final code = TextEditingController();

  Map<String, dynamic> get body => {"phone": phone, "phone_code": country.phoneCode, 'code': code.text};

  StartVerifyEmailToUpdateEvent(this.phone, this.country);
}

class StartProfileEvent extends ProfileEvent {}
