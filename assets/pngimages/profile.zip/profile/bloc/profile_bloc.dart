import 'dart:async';

import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../core/services/server_gate.dart';
import '../../../core/utils/enums.dart';
import '../../../core/widgets/flash_helper.dart';
import '../../../models/user.dart';
import 'profile_events.dart';
import 'profile_states.dart';

class ProfileBloc extends Bloc<ProfileEvent, ProfileState> {
  ProfileBloc() : super(ProfileState()) {
    on<StartLogoutEvent>(_logout);
    on<StartUpdateProfileEvent>(_updateProfile);
    on<StartUpdatePhoneEvent>(_updatePhone);
    on<StartVerifyEmailToUpdateEvent>(_verifyPhone);
    on<StartProfileEvent>(_profile);
    // on<StartChangeLanguageEvent>(_changeLang);
    // on<StartToggleNotificationEvent>(_toggleNotification);
    // on<StartChengePasswordEvent>(_changePassowrd);
  }

  Future<void> _logout(StartLogoutEvent event, Emitter<ProfileState> emit) async {
    emit(state.copyWith(logoutState: RequestState.loading));
    final result = await ServerGate.i.sendToServer(url: 'client/logout', body: await event.body);
    if (result.success || result.statusCode == 401) {
      UserModel.i.clear();
      emit(state.copyWith(logoutState: RequestState.done, msg: result.msg));
    } else {
      emit(state.copyWith(logoutState: RequestState.error, msg: result.msg, errorType: result.errType));
    }
  }

  Future<void> _updateProfile(StartUpdateProfileEvent event, Emitter<ProfileState> emit) async {
    emit(state.copyWith(updateProfile: RequestState.loading));
    final result = await ServerGate.i.sendToServer(
      url: 'client/account/edit/profile',
      formData: event.body..addAll({'_method': 'PUT'}),
    );
    if (result.success) {
      result.data['data']['token'] = UserModel.i.token;
      UserModel.i.fromJson(result.data['data']);
      UserModel.i.save();
      emit(state.copyWith(updateProfile: RequestState.done, msg: result.msg));
    } else {
      FlashHelper.showToast(result.msg);
      emit(state.copyWith(updateProfile: RequestState.error, msg: result.msg, errorType: result.errType));
    }
  }

  FutureOr<void> _updatePhone(StartUpdatePhoneEvent event, Emitter<ProfileState> emit) async {
    emit(state.copyWith(resendCodeState: event.isResend ? RequestState.loading : null, updatePhoneState: event.isResend ? null : RequestState.loading));
    final result = await ServerGate.i.putToServer(url: 'client/account/edit/phone', body: event.body);
    if (result.success) {
      emit(state.copyWith(
        resendCodeState: event.isResend ? RequestState.done : null,
        updatePhoneState: event.isResend ? null : RequestState.done,
        msg: result.msg,
      ));
    } else {
      FlashHelper.showToast(result.msg);
      emit(
        state.copyWith(
          resendCodeState: event.isResend ? RequestState.error : null,
          updatePhoneState: event.isResend ? null : RequestState.error,
          msg: result.msg,
          errorType: result.errType,
        ),
      );
    }
  }

  Future<void> _verifyPhone(StartVerifyEmailToUpdateEvent event, Emitter<ProfileState> emit) async {
    emit(state.copyWith(verifyState: RequestState.loading));
    final result = await ServerGate.i.putToServer(url: 'client/account/verify/phone', body: event.body);
    if (result.success) {
      result.data['data']['token'] = UserModel.i.token;
      UserModel.i.fromJson(result.data['data']);
      UserModel.i.save();
      emit(state.copyWith(verifyState: RequestState.done, msg: result.msg));
    } else {
      FlashHelper.showToast(result.msg);
      emit(state.copyWith(verifyState: RequestState.error, msg: result.msg, errorType: result.errType));
    }
  }

  // Future<void> _updateMedicalFile(StartUpdateMedicalFileEvent event, Emitter<ProfileState> emit) async {
  //   emit(state.copyWith(updateMedicalFileState: RequestState.loading));
  //   final result = await ServerGate.i.putToServer(url: 'client/profile/medical-file', body: event.body);
  //   if (result.success) {
  //     result.data['data']['token'] = UserModel.i.token;
  //     UserModel.i.fromJson(result.data['data']);
  //     UserModel.i.save();
  //     emit(state.copyWith(updateMedicalFileState: RequestState.done, msg: result.msg));
  //   } else {
  //     FlashHelper.showToast(result.msg);
  //     emit(state.copyWith(updateMedicalFileState: RequestState.error, msg: result.msg, errorType: result.errType));
  //   }
  // }

  // FutureOr<void> _toggleNotification(StartToggleNotificationEvent event, Emitter<ProfileState> emit) async {
  //   emit(state.copyWith(toggleNotificationState: RequestState.loading));
  //   final result = await ServerGate.i.patchToServer(url: 'client/profile/toggle-notification');
  //   if (result.success) {
  //     result.data['data']['token'] = UserModel.i.token;
  //     UserModel.i.fromJson(result.data['data']);
  //     UserModel.i.save();
  //     emit(state.copyWith(toggleNotificationState: RequestState.done, msg: result.msg));
  //   } else {
  //     FlashHelper.showToast(result.msg);
  //     emit(state.copyWith(toggleNotificationState: RequestState.error, msg: result.msg, errorType: result.errType));
  //   }
  // }

  FutureOr<void> _profile(StartProfileEvent event, Emitter<ProfileState> emit) async {
    emit(state.copyWith(profileState: RequestState.loading));
    final result = await ServerGate.i.getFromServer(url: 'client/account');
    if (result.success) {
      result.data['data']['token'] = UserModel.i.token;
      UserModel.i.fromJson(result.data['data']);
      UserModel.i.save();
      emit(state.copyWith(profileState: RequestState.done));
    } else {
      FlashHelper.showToast(result.msg);
      emit(state.copyWith(profileState: RequestState.error, msg: result.msg, errorType: result.errType));
    }
  }
}
