import '../../../core/utils/enums.dart';

class ProfileState {
  final RequestState logoutState, verifyState, updateProfile, resendCodeState, updatePhoneState, profileState;

  final String msg;
  final ErrorType errorType;

  ProfileState({
    this.logoutState = RequestState.initial,
    this.msg = '',
    this.errorType = ErrorType.none,
    this.updateProfile = RequestState.initial,
    this.updatePhoneState = RequestState.initial,
    this.resendCodeState = RequestState.initial,
    this.verifyState = RequestState.initial,
    this.profileState = RequestState.initial,
  });

  ProfileState copyWith({
    RequestState? logoutState,
    String? msg,
    ErrorType? errorType,
    RequestState? updateProfile,
    RequestState? updatePhoneState,
    RequestState? resendCodeState,
    RequestState? verifyState,
    RequestState? profileState,
  }) =>
      ProfileState(
        logoutState: logoutState ?? this.logoutState,
        msg: msg ?? this.msg,
        errorType: errorType ?? this.errorType,
        updateProfile: updateProfile ?? this.updateProfile,
        updatePhoneState: updatePhoneState ?? this.updatePhoneState,
        resendCodeState: resendCodeState ?? this.resendCodeState,
        verifyState: verifyState ?? this.verifyState,
        profileState: profileState ?? this.profileState,
      );
}
