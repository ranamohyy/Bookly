import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:padelgate/core/widgets/successfully_sheet.dart';

import '../../../core/utils/extensions.dart';
import '../../../core/utils/phoneix.dart';
import '../../../core/widgets/app_btn.dart';
import '../../../core/widgets/app_sheet.dart';
import '../../../core/widgets/custom_timer.dart';
import '../../../core/widgets/flash_helper.dart';
import '../../../core/widgets/pin_code.dart';
import '../../../core/widgets/resend_timer_widget.dart';
import '../../../gen/locale_keys.g.dart';
import '../bloc/profile_bloc.dart';
import '../bloc/profile_events.dart';
import '../bloc/profile_states.dart';

class VerifyPhoneSheet extends StatefulWidget {
  final StartUpdatePhoneEvent event;
  const VerifyPhoneSheet({super.key, required this.event});

  @override
  State<VerifyPhoneSheet> createState() => _VerifyPhoneSheetState();
}

class _VerifyPhoneSheetState extends State<VerifyPhoneSheet> {
  final timerController = CustomTimerController(5.seconds);
  late final resendEvent = StartUpdatePhoneEvent()
    ..phone.text = widget.event.phone.text
    ..country = widget.event.country
    ..isResend = true;
  late final event = StartVerifyEmailToUpdateEvent(widget.event.phone.text, widget.event.country);
  final _checkCode = StreamController<bool>();
  @override
  void initState() {
    event.code.addListener(() => _checkCode.add(event.code.text.length == 4));
    super.initState();
  }

  @override
  void dispose() {
    timerController.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CustomAppSheet(
      children: [
        Text(
          LocaleKeys.verify_code.tr(),
          style: context.boldText.copyWith(fontSize: 24.sp, color: context.primaryColorLight),
        ).withPadding(bottom: 8.h),
        RichText(
          text: TextSpan(
            style: context.regularText.copyWith(fontSize: 16.sp, color: context.primaryColorLight),
            children: [
              TextSpan(text: LocaleKeys.verify_part_one.tr()),
              TextSpan(
                text: " +${widget.event.country.phoneCode} ${widget.event.phone.text} ",
                style: context.regularText.copyWith(fontSize: 16.sp, color: context.hoverColor),
              ),
              TextSpan(text: LocaleKeys.verify_part_two.tr()),
            ],
          ),
        ).withPadding(bottom: 24.h),
        CustomPinCode(controller: event.code),
        BlocConsumer<ProfileBloc, ProfileState>(
          listenWhen: (previous, current) => previous.resendCodeState != current.resendCodeState,
          buildWhen: (previous, current) => previous.resendCodeState != current.resendCodeState,
          listener: (context, state) {
            if (state.verifyState.isDone) {
              timerController.setDuration(1.minutes);
              FlashHelper.showToast(state.msg);
            }
          },
          builder: (context, state) {
            return ResendTimerWidget(
              timer: timerController,
              loading: state.resendCodeState.isLoading,
              onTap: () {
                context.read<ProfileBloc>().add(resendEvent);
              },
            ).withPadding(vertical: 16.h);
          },
        ),
        StreamBuilder<bool>(
          stream: _checkCode.stream,
          builder: (context, snapshot) {
            return BlocConsumer<ProfileBloc, ProfileState>(
              listenWhen: (previous, current) => previous.verifyState != current.verifyState,
              buildWhen: (previous, current) => previous.verifyState != current.verifyState,
              listener: (context, state) {
                if (state.verifyState.isDone) {
                  Phoenix.rebirth(context);
                  Navigator.pop(context, true);
                  showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    enableDrag: false,
                    builder: (context) => DoneSheet(
                      title: LocaleKeys.your_phone_was_changed_successfully.tr(),
                    ),
                  );
                }
              },
              builder: (context, state) {
                return AppBtn(
                  loading: state.verifyState.isLoading,
                  enable: snapshot.data ?? false,
                  onPressed: () => context.read<ProfileBloc>().add(event),
                  title: LocaleKeys.confirm.tr(),
                );
              },
            ).withPadding(bottom: 20.h);
          },
        ),
      ],
    );
  }
}
