import 'package:dotted_border/dotted_border.dart';
import 'package:easy_localization/easy_localization.dart' hide TextDirection;
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../core/routes/app_routes_fun.dart';
import '../../../core/routes/routes.dart';
import '../../../core/utils/extensions.dart';
import '../../../core/widgets/custom_image.dart';
import '../../../gen/assets.gen.dart';
import '../../../gen/locale_keys.g.dart';
import '../../../models/user.dart';
import '../bloc/profile_bloc.dart';
import '../bloc/profile_states.dart';

class CustomProfileHeader extends StatelessWidget {
  const CustomProfileHeader({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ProfileBloc, ProfileState>(
      buildWhen: (previous, current) => previous.profileState != current.profileState,
      builder: (context, state) {
        return Stack(
          alignment: AlignmentDirectional.topCenter,
          children: [
            Container(
              width: double.infinity,
              height: 255.h,
              clipBehavior: Clip.hardEdge,
              padding: EdgeInsets.symmetric(horizontal: 16.r),
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                    end: AlignmentDirectional.centerEnd,
                    begin: AlignmentDirectional.centerStart,
                    transform: const GradientRotation(.4),
                    colors: [
                      context.hoverColor.withOpacity(.25),
                      context.primaryColor.withOpacity(.2),
                      context.primaryColor,
                      context.primaryColor,
                    ],
                  ),
                  borderRadius: BorderRadius.only(bottomLeft: Radius.circular(32.r), bottomRight: Radius.circular(32.r))),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    LocaleKeys.profile.tr(),
                    style: context.semiboldText.copyWith(fontSize: 24.sp, color: context.primaryColorLight),
                  ).withPadding(top: 60.h),
                  Row(
                    children: [
                      CustomImage(
                        UserModel.i.image,
                        height: 54.r,
                        width: 54.r,
                        fit: BoxFit.cover,
                        borderRadius: BorderRadius.circular(200.r),
                      ).withPadding(end: 8.w),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              UserModel.i.fullName,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: context.boldText.copyWith(color: context.primaryColorLight),
                            ).withPadding(bottom: 4.h),
                            Text(
                              UserModel.i.gender.tr().toUpperCase(),
                              style: context.regularText.copyWith(color: context.hintColor),
                              textDirection: TextDirection.ltr,
                            )
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: () => push(NamedRoutes.editProfile),
                        child: CustomImage(
                          Assets.svg.editProfile,
                          width: 20.r,
                          color: context.primaryColorLight,
                          height: 20.r,
                          fit: BoxFit.fill,
                        ),
                      )
                    ],
                  ).withPadding(top: 24.h, bottom: 24.h),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              // height: 100.h,
              padding: EdgeInsets.all(10.w),
              margin: EdgeInsetsDirectional.only(top: 200.h),
              decoration: BoxDecoration(
                color: context.primaryColor,
                border: Border.all(color: context.indicatorColor),
                borderRadius: BorderRadius.circular(16.r),
              ),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => push(NamedRoutes.ranking),
                    child: SizedBox(
                      width: 74.r,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          SizedBox(
                            height: 74.r,
                            width: 74.r,
                            child: CircularProgressIndicator(
                              value: UserModel.i.ranking / 100,
                              color: context.focusColor,
                              backgroundColor: context.scaffoldBackgroundColor,
                              strokeWidth: 8.r,
                              strokeCap: StrokeCap.round,
                            ),
                          ),
                          Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SizedBox(
                                width: 60.r,
                                child: Text(
                                  "${UserModel.i.ranking}",
                                  textAlign: TextAlign.center,
                                  style: context.semiboldText.copyWith(color: context.primaryColorLight, fontSize: 20.sp),
                                ),
                              ),
                              Text(
                                LocaleKeys.ranking.tr(),
                                style: context.mediumText.copyWith(color: context.focusColor, fontSize: 8.sp),
                              )
                            ],
                          )
                        ],
                      ),
                    ).withPadding(end: 14.w),
                  ),
                  Expanded(
                    child: DottedBorder(
                        padding: EdgeInsets.all(10.r),
                        color: context.hoverColor,
                        radius: Radius.circular(8.r),
                        borderType: BorderType.RRect,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SizedBox(
                              width: double.infinity,
                              child: Wrap(
                                alignment: WrapAlignment.spaceBetween,
                                // runAlignment: WrapAlignment.spaceBetween,
                                spacing: 10.w,
                                runSpacing: 4.h,
                                children: [
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        LocaleKeys.current_level.tr(),
                                        style: context.regularText.copyWith(fontSize: 12.sp, color: context.hintColor),
                                      ),
                                      Flexible(
                                        child: Text(
                                          UserModel.i.level.badge,
                                          style: context.boldText.copyWith(fontSize: 12.sp, color: context.primaryColorLight),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        LocaleKeys.next_level.tr(),
                                        style: context.regularText.copyWith(fontSize: 12.sp, color: context.hintColor),
                                      ),
                                      Flexible(
                                        child: Text(
                                          UserModel.i.nextLevel.badge,
                                          style: context.boldText.copyWith(fontSize: 12.sp, color: context.primaryColorLight),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: List.generate(
                                7,
                                (index) => CustomImage(
                                  Assets.svg.cup,
                                  width: 24.r,
                                  height: 24.r,
                                  color: (() {
                                    if (6 - index < UserModel.i.losesTimes) {
                                      return context.errorColor;
                                    } else if (index < UserModel.i.winningsTimes) {
                                      return context.hoverColor;
                                    } else {
                                      return context.hintColor;
                                    }
                                  })(),
                                ),
                              ),
                            ).withPadding(vertical: 4.h),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  LocaleKeys.win.tr(namedArgs: {"num": "${UserModel.i.winPercentage}"}),
                                  style: context.mediumText.copyWith(fontSize: 12.sp, color: context.hoverColor),
                                ),
                                Text(
                                  LocaleKeys.lose.tr(namedArgs: {"num": "${UserModel.i.lossPercentage}"}),
                                  style: context.mediumText.copyWith(fontSize: 12.sp, color: context.canvasColor),
                                )
                              ],
                            )
                          ],
                        )),
                  )
                ],
              ),
            ).withPadding(horizontal: 16.w)
          ],
        );
      },
    );
  }
}
