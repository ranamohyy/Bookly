import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../core/utils/extensions.dart';
import '../../../gen/locale_keys.g.dart';
import '../../global/back_widget.dart';

class CustomEditProfileAppBar extends StatelessWidget implements PreferredSizeWidget {
  final Widget image;

  const CustomEditProfileAppBar({Key? key, required this.image}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: Text(LocaleKeys.my_profile.tr(), style: context.boldText.copyWith(fontSize: 24.sp)),
      leading: const BackWidget(),
      leadingWidth: 70.w,
      elevation: 0,
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      flexibleSpace: FlexibleSpaceBar(
        titlePadding: EdgeInsets.only(bottom: 24.h),
        title: image.toBottom,
        background: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              end: AlignmentDirectional.centerEnd,
              begin: AlignmentDirectional.centerStart,
              transform: const GradientRotation(.4),
              colors: [
                context.hoverColor.withOpacity(.25),
                context.hoverColor.withOpacity(.15),
                context.primaryColor.withOpacity(.2),
                context.primaryColor,
                context.primaryColor,
              ],
            ),
            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(32.r), bottomRight: Radius.circular(32.r)),
          ),
        ),
      ),
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(250.h - kTextTabBarHeight);
}
