import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../core/utils/extensions.dart';
import '../../../core/widgets/app_btn.dart';
import '../../../core/widgets/flash_helper.dart';
import '../../../gen/locale_keys.g.dart';
import '../../../main.dart';

class DataOfBirth extends StatefulWidget {
  const DataOfBirth({super.key});

  @override
  State<DataOfBirth> createState() => _DataOfBirthState();
}

class _DataOfBirthState extends State<DataOfBirth> {
  DateTime? date;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          height: 240.h,
          width: double.infinity,
          child: CupertinoTheme(
            data: CupertinoThemeData(
              textTheme: CupertinoTextThemeData(
                textStyle: context.regularText.copyWith(color: context.primaryColorLight),
                dateTimePickerTextStyle: context.regularText.copyWith(color: context.primaryColorLight),
              ),
              brightness: Prefs.getString('theme') == 'ThemeType.dark' ? Brightness.dark : Brightness.light,
              barBackgroundColor: context.primaryColorLight,
            ),
            child: CupertinoDatePicker(
              dateOrder: DatePickerDateOrder.dmy,
              mode: CupertinoDatePickerMode.date,
              initialDateTime: DateTime.now(),
              itemExtent: 80.h,
              maximumDate: DateTime.now(),
              minimumYear: 1920,
              onDateTimeChanged: (DateTime value) {
                date = value;
                setState(() {});
              },
            ),
          ),
        ),
        Row(
          children: [
            Expanded(
              child: AppBtn(
                height: 34.h,
                borderColor: context.hoverColor,
                textColor: context.hoverColor,
                title: LocaleKeys.cancel.tr(),
                onPressed: () => Navigator.pop(context),
                backgroundColor: Colors.transparent,
              ),
            ),
            SizedBox(width: 16.w),
            Expanded(
              child: AppBtn(
                height: 34.h,
                onPressed: () {
                  if (date != null) {
                    Navigator.pop(context, {"data": date});
                  } else {
                    FlashHelper.showToast("${LocaleKeys.date.tr()} ${LocaleKeys.Required.tr()}", type: MessageType.warning);
                  }
                },
                title: LocaleKeys.confirm.tr(),
              ),
            ),
          ],
        ).withPadding(bottom: 20.h),
      ],
    );
  }
}
