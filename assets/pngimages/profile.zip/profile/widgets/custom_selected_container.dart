import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:padelgate/core/utils/extensions.dart';

class CustomSelectedContainer extends StatelessWidget {
  final void Function()? onTap;
  final bool isSelected;
  const CustomSelectedContainer({Key? key, required this.title, this.onTap, this.isSelected = false}) : super(key: key);
  final String title;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 20.h),
        decoration: BoxDecoration(
          color: context.primaryColor,
          borderRadius: BorderRadius.circular(10.r),
          border: isSelected ? Border.all(color: context.hoverColor) : null,
        ),
        child: Text(
          title,
          style: context.semiboldText.copyWith(fontSize: 14.sp, color: context.primaryColorLight),
        ),
      ),
    );
  }
}
