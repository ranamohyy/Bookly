| emoji | aliases | tags |
|:-:|:--|:--|
| 👍 | `:+1:`, `:thumbup:`, `:thumbsup:` | thumbs, up, sign, body, hands, hi, luck, thank, you, diversity, diversity, perfect, perfect, good, good, beautiful, beautiful |
| 👍🏻 | `:+1_tone1:`, `:thumbup_tone1:`, `:thumbsup_tone1:` | thumbs, up, sign, tone, 1 |
| 👍🏼 | `:+1_tone2:`, `:thumbup_tone2:`, `:thumbsup_tone2:` | thumbs, up, sign, tone, 2 |
| 👍🏽 | `:+1_tone3:`, `:thumbup_tone3:`, `:thumbsup_tone3:` | thumbs, up, sign, tone, 3 |
| 👍🏾 | `:+1_tone4:`, `:thumbup_tone4:`, `:thumbsup_tone4:` | thumbs, up, sign, tone, 4 |
| 👍🏿 | `:+1_tone5:`, `:thumbup_tone5:`, `:thumbsup_tone5:` | thumbs, up, sign, tone, 5 |
| 👎 | `:-1:`, `:thumbdown:`, `:thumbsdown:` | thumbs, down, sign, body, hands, diversity, diversity |
| 👎🏻 | `:-1_tone1:`, `:thumbdown_tone1:`, `:thumbsdown_tone1:` | thumbs, down, sign, tone, 1 |
| 👎🏼 | `:-1_tone2:`, `:thumbdown_tone2:`, `:thumbsdown_tone2:` | thumbs, down, sign, tone, 2 |
| 👎🏽 | `:-1_tone3:`, `:thumbdown_tone3:`, `:thumbsdown_tone3:` | thumbs, down, sign, tone, 3 |
| 👎🏾 | `:-1_tone4:`, `:thumbdown_tone4:`, `:thumbsdown_tone4:` | thumbs, down, sign, tone, 4 |
| 👎🏿 | `:-1_tone5:`, `:thumbdown_tone5:`, `:thumbsdown_tone5:` | thumbs, down, sign, tone, 5 |
| 💯 | `:100:` | hundred, points, symbol, symbol, wow, wow, win, win, perfect, perfect, parties, parties |
| 🔢 | `:1234:` | input, symbol, for, numbers, symbol |
| 🎱 | `:8ball:` | billiards, game, ball, sport, billiards, luck, boys, night, boys, night |
| 🅰 | `:a:` | negative, squared, latin, capital, letter, a, symbol |
| 🆎 | `:ab:` | negative, squared, ab, symbol |
| 🔤 | `:abc:` | input, symbol, for, latin, letters, symbol |
| 🔡 | `:abcd:` | input, symbol, for, latin, small, letters, symbol |
| 🇦🇨 | `:ac:`, `:flag_ac:` | ascension, country, flag, flag |
| 🉑 | `:accept:` | circled, ideograph, accept, symbol |
| 🇦🇩 | `:ad:`, `:flag_ad:` | andorra, country, flag, flag |
| 🎟 | `:admission_tickets:`, `:tickets:` | admission, tickets, theatre, movie, parties, parties |
| 🇦🇪 | `:ae:`, `:flag_ae:` | the, united, arab, emirates, country, flag, flag |
| 🚡 | `:aerial_tramway:` | aerial, tramway, transportation, travel, train |
| 🇦🇫 | `:af:`, `:flag_af:` | afghanistan, country, flag, flag |
| 🇦🇬 | `:ag:`, `:flag_ag:` | antigua, and, barbuda, country, flag, flag |
| 🇦🇮 | `:ai:`, `:flag_ai:` | anguilla, country, flag, flag |
| ✈ | `:airplane:` | airplane, transportation, plane, travel, vacation, fly, fly |
| 🛬 | `:airplane_arriving:` | airplane, arriving, transportation, plane, travel, vacation, fly, fly |
| 🛫 | `:airplane_departure:` | airplane, departure, transportation, plane, travel, vacation, fly, fly |
| 🛩 | `:small_airplane:`, `:airplane_small:` | small, airplane, transportation, plane, travel, vacation, fly, fly |
| 🇦🇱 | `:al:`, `:flag_al:` | albania, country, flag, flag |
| ⏰ | `:alarm_clock:` | alarm, clock, object, time |
| ⚗ | `:alembic:` | alembic, object, science |
| 👽 | `:alien:` | extraterrestrial, alien, space, monster, alien, scientology, scientology |
| 🇦🇲 | `:am:`, `:flag_am:` | armenia, country, flag, flag |
| 🚑 | `:ambulance:` | ambulance, transportation, 911, 911 |
| 🏺 | `:amphora:` | amphora, object |
| ⚓ | `:anchor:` | anchor, object, travel, boat, vacation |
| 👼 | `:angel:` | baby, angel, people, diversity, diversity, omg, omg |
| 👼🏻 | `:angel_tone1:` | baby, angel, tone, 1 |
| 👼🏼 | `:angel_tone2:` | baby, angel, tone, 2 |
| 👼🏽 | `:angel_tone3:` | baby, angel, tone, 3 |
| 👼🏾 | `:angel_tone4:` | baby, angel, tone, 4 |
| 👼🏿 | `:angel_tone5:` | baby, angel, tone, 5 |
| 💢 | `:anger:` | anger, symbol, symbol |
| 🗯 | `:right_anger_bubble:`, `:anger_right:` | right, anger, bubble, symbol |
| 😠 | `:angry:` | angry, face, mad, smiley, emotion, emotion |
| 😧 | `:anguished:` | anguished, face, sad, smiley, surprised, emotion, emotion |
| 🐜 | `:ant:` | ant, insects, animal, animal |
| 🇦🇴 | `:ao:`, `:flag_ao:` | angola, country, flag, flag |
| 🍎 | `:apple:` | red, apple, fruit, food, creationism, creationism |
| 🇦🇶 | `:aq:`, `:flag_aq:` | antarctica, country, flag, flag |
| ♒ | `:aquarius:` | aquarius, zodiac, symbol |
| 🇦🇷 | `:ar:`, `:flag_ar:` | argentina, country, flag, flag |
| 🏹 | `:archery:`, `:bow_and_arrow:` | bow, and, arrow, weapon, sport |
| ♈ | `:aries:` | aries, zodiac, symbol |
| ◀ | `:arrow_backward:` | black, left-pointing, triangle, arrow, symbol, triangle, triangle |
| ⏬ | `:arrow_double_down:` | black, down-pointing, double, triangle, arrow, symbol |
| ⏫ | `:arrow_double_up:` | black, up-pointing, double, triangle, arrow, symbol |
| ⬇ | `:arrow_down:` | downwards, black, arrow, arrow, symbol |
| 🔽 | `:arrow_down_small:` | down-pointing, small, red, triangle, arrow, symbol, triangle, triangle |
| ▶ | `:arrow_forward:` | black, right-pointing, triangle, arrow, symbol, triangle, triangle |
| ⤵ | `:arrow_heading_down:` | arrow, pointing, rightwards, then, curving, downwards, arrow, symbol |
| ⤴ | `:arrow_heading_up:` | arrow, pointing, rightwards, then, curving, upwards, arrow, symbol |
| ⬅ | `:arrow_left:` | leftwards, black, arrow, arrow, symbol |
| ↙ | `:arrow_lower_left:` | south, west, arrow, arrow, symbol |
| ↘ | `:arrow_lower_right:` | south, east, arrow, arrow, symbol |
| ➡ | `:arrow_right:` | black, rightwards, arrow, arrow, symbol |
| ↪ | `:arrow_right_hook:` | rightwards, arrow, with, hook, arrow, symbol |
| ⬆ | `:arrow_up:` | upwards, black, arrow, arrow, symbol |
| ↕ | `:arrow_up_down:` | up, down, arrow, arrow, symbol |
| 🔼 | `:arrow_up_small:` | up-pointing, small, red, triangle, arrow, symbol, triangle, triangle |
| ↖ | `:arrow_upper_left:` | north, west, arrow, arrow, symbol |
| ↗ | `:arrow_upper_right:` | north, east, arrow, arrow, symbol |
| 🔃 | `:arrows_clockwise:` | clockwise, downwards, and, upwards, open, circle, arrows, arrow, symbol |
| 🔄 | `:arrows_counterclockwise:` | anticlockwise, downwards, and, upwards, open, circle, arrows, arrow, symbol |
| 🎨 | `:art:` | artist, palette |
| 🚛 | `:articulated_lorry:` | articulated, lorry, transportation, truck |
| 🇦🇸 | `:as:`, `:flag_as:` | american, samoa, country, flag, flag |
| *⃣ | `:keycap_asterisk:`, `:asterisk:` | keycap, asterisk, symbol |
| 😲 | `:astonished:` | astonished, face, smiley, surprised, wow, wow, emotion, emotion, omg, omg |
| 🇦🇹 | `:at:`, `:flag_at:` | austria, country, flag, flag |
| 👟 | `:athletic_shoe:` | athletic, shoe, fashion, shoe, accessories, boys, night, boys, night |
| 🏧 | `:atm:` | automated, teller, machine, electronics, symbol, money, money |
| ⚛ | `:atom_symbol:`, `:atom:` | atom, symbol, symbol, science |
| 🇦🇺 | `:au:`, `:flag_au:` | australia, country, flag, flag |
| 🥑 | `:avocado:` | avocado |
| 🇦🇼 | `:aw:`, `:flag_aw:` | aruba, country, flag, flag |
| 🇦🇽 | `:ax:`, `:flag_ax:` | åland, islands, country, flag, flag |
| 🇦🇿 | `:az:`, `:flag_az:` | azerbaijan, country, flag, flag |
| 🅱 | `:b:` | negative, squared, latin, capital, letter, b, symbol |
| 🇧🇦 | `:ba:`, `:flag_ba:` | bosnia, and, herzegovina, country, flag, flag |
| 👶 | `:baby:` | baby, people, baby, diversity, diversity |
| 🍼 | `:baby_bottle:` | baby, bottle, drink, object, food, baby |
| 🐤 | `:baby_chick:` | baby, chick, animal, animal, chicken, chicken |
| 🚼 | `:baby_symbol:` | baby, symbol, symbol |
| 👶🏻 | `:baby_tone1:` | baby, tone, 1 |
| 👶🏼 | `:baby_tone2:` | baby, tone, 2 |
| 👶🏽 | `:baby_tone3:` | baby, tone, 3 |
| 👶🏾 | `:baby_tone4:` | baby, tone, 4 |
| 👶🏿 | `:baby_tone5:` | baby, tone, 5 |
| 🔙 | `:back:` | back, with, leftwards, arrow, above, arrow, symbol |
| 🤚 | `:back_of_hand:`, `:raised_back_of_hand:` | raised, back, of, hand |
| 🤚🏻 | `:back_of_hand_tone1:`, `:raised_back_of_hand_tone1:` | raised, back, of, hand, tone, 1 |
| 🤚🏼 | `:back_of_hand_tone2:`, `:raised_back_of_hand_tone2:` | raised, back, of, hand, tone, 2 |
| 🤚🏽 | `:back_of_hand_tone3:`, `:raised_back_of_hand_tone3:` | raised, back, of, hand, tone, 3 |
| 🤚🏾 | `:back_of_hand_tone4:`, `:raised_back_of_hand_tone4:` | raised, back, of, hand, tone, 4 |
| 🤚🏿 | `:back_of_hand_tone5:`, `:raised_back_of_hand_tone5:` | raised, back, of, hand, tone, 5 |
| 🥓 | `:bacon:` | bacon, pig |
| 🏸 | `:badminton:` | badminton, racquet, game, sport, badminton |
| 🛄 | `:baggage_claim:` | baggage, claim, symbol |
| 🥖 | `:baguette_bread:`, `:french_bread:` | baguette, bread |
| 🎈 | `:balloon:` | balloon, object, birthday, good, good, parties, parties |
| 🗳 | `:ballot_box_with_ballot:`, `:ballot_box:` | ballot, box, with, ballot, object, office |
| ☑ | `:ballot_box_with_check:` | ballot, box, with, check, symbol |
| 🎍 | `:bamboo:` | pine, decoration, nature, plant |
| 🍌 | `:banana:` | banana, fruit, penis, food |
| ‼ | `:bangbang:` | double, exclamation, mark, symbol, punctuation |
| 🏦 | `:bank:` | bank, places, building |
| 📊 | `:bar_chart:` | bar, chart, work, office |
| 💈 | `:barber:` | barber, pole, object |
| ⚾ | `:baseball:` | baseball, game, ball, sport, baseball |
| 🏀 | `:basketball:` | basketball, and, hoop, game, ball, sport, basketball |
| ⛹ | `:person_with_ball:`, `:basketball_player:` | person, with, ball, men, game, ball, sport, basketball, diversity, diversity |
| ⛹🏻 | `:person_with_ball_tone1:`, `:basketball_player_tone1:` | person, with, ball, tone, 1 |
| ⛹🏼 | `:person_with_ball_tone2:`, `:basketball_player_tone2:` | person, with, ball, tone, 2 |
| ⛹🏽 | `:person_with_ball_tone3:`, `:basketball_player_tone3:` | person, with, ball, tone, 3 |
| ⛹🏾 | `:person_with_ball_tone4:`, `:basketball_player_tone4:` | person, with, ball, tone, 4 |
| ⛹🏿 | `:person_with_ball_tone5:`, `:basketball_player_tone5:` | person, with, ball, tone, 5 |
| 🦇 | `:bat:` | bat |
| 🛀 | `:bath:` | bath, bathroom, tired, diversity, diversity, steam, steam |
| 🛀🏻 | `:bath_tone1:` | bath, tone, 1 |
| 🛀🏼 | `:bath_tone2:` | bath, tone, 2 |
| 🛀🏽 | `:bath_tone3:` | bath, tone, 3 |
| 🛀🏾 | `:bath_tone4:` | bath, tone, 4 |
| 🛀🏿 | `:bath_tone5:` | bath, tone, 5 |
| 🛁 | `:bathtub:` | bathtub, object, bathroom, tired, steam, steam |
| 🔋 | `:battery:` | battery, object |
| 🇧🇧 | `:bb:`, `:flag_bb:` | barbados, country, flag, flag |
| 🇧🇩 | `:bd:`, `:flag_bd:` | bangladesh, country, flag, flag |
| 🇧🇪 | `:be:`, `:flag_be:` | belgium, country, flag, flag |
| 🏖 | `:beach_with_umbrella:`, `:beach:` | beach, with, umbrella, places, travel, vacation, tropical, beach, swim |
| ⛱ | `:umbrella_on_ground:`, `:beach_umbrella:` | umbrella, on, ground, travel, vacation, tropical |
| 🐻 | `:bear:` | bear, face, wildlife, roar, animal, animal |
| 🛏 | `:bed:` | bed, object, tired |
| 🐝 | `:bee:` | honeybee, insects, animal, animal |
| 🍺 | `:beer:` | beer, mug, drink, beer, alcohol, parties, parties |
| 🍻 | `:beers:` | clinking, beer, mugs, drink, cheers, beer, alcohol, thank, you, boys, night, boys, night, parties, parties |
| 🐞 | `:beetle:` | lady, beetle, insects, animal, animal |
| 🔰 | `:beginner:` | japanese, symbol, for, beginner, symbol |
| 🔔 | `:bell:` | bell, object, alarm, symbol |
| 🛎 | `:bellhop_bell:`, `:bellhop:` | bellhop, bell, object |
| 🍱 | `:bento:` | bento, box, object, sushi, japan, food |
| 🇧🇫 | `:bf:`, `:flag_bf:` | burkina, faso, country, flag, flag |
| 🇧🇬 | `:bg:`, `:flag_bg:` | bulgaria, country, flag, flag |
| 🇧🇭 | `:bh:`, `:flag_bh:` | bahrain, country, flag, flag |
| 🇧🇮 | `:bi:`, `:flag_bi:` | burundi, country, flag, flag |
| 🚴 | `:bicyclist:` | bicyclist, men, workout, sport, bike, diversity, diversity |
| 🚴🏻 | `:bicyclist_tone1:` | bicyclist, tone, 1 |
| 🚴🏼 | `:bicyclist_tone2:` | bicyclist, tone, 2 |
| 🚴🏽 | `:bicyclist_tone3:` | bicyclist, tone, 3 |
| 🚴🏾 | `:bicyclist_tone4:` | bicyclist, tone, 4 |
| 🚴🏿 | `:bicyclist_tone5:` | bicyclist, tone, 5 |
| 🚲 | `:bike:` | bicycle, transportation, travel, bike |
| 👙 | `:bikini:` | bikini, women, fashion, sexy, vacation, tropical, swim |
| ☣ | `:biohazard_sign:`, `:biohazard:` | biohazard, sign, symbol, science |
| 🐦 | `:bird:` | bird, wildlife, animal, animal |
| 🎂 | `:birthday:` | birthday, cake, birthday, food, parties, parties |
| 🇧🇯 | `:bj:`, `:flag_bj:` | benin, country, flag, flag |
| 🇧🇱 | `:bl:`, `:flag_bl:` | saint, barthélemy, country, flag, flag |
| ⚫ | `:black_circle:` | medium, black, circle, shapes, symbol, circle, circle |
| 🖤 | `:black_heart:` | black, heart |
| 🃏 | `:black_joker:` | playing, card, black, joker, object, symbol, game |
| ⬛ | `:black_large_square:` | black, large, square, shapes, symbol, square, square |
| ◾ | `:black_medium_small_square:` | black, medium, small, square, shapes, symbol, square, square |
| ◼ | `:black_medium_square:` | black, medium, square, shapes, symbol, square, square |
| ✒ | `:black_nib:` | black, nib, object, office, write |
| ▪ | `:black_small_square:` | black, small, square, shapes, symbol, square, square |
| 🔲 | `:black_square_button:` | black, square, button, shapes, symbol, square, square |
| 🌼 | `:blossom:` | blossom, nature, flower, plant |
| 🐡 | `:blowfish:` | blowfish, wildlife, animal, animal |
| 📘 | `:blue_book:` | blue, book, object, office, write, book |
| 🚙 | `:blue_car:` | recreational, vehicle, transportation, car, travel |
| 💙 | `:blue_heart:` | blue, heart, love, symbol |
| 😊 | `:blush:` | smiling, face, with, smiling, eyes, happy, smiley, emotion, emotion, good, good, beautiful, beautiful |
| 🇧🇲 | `:bm:`, `:flag_bm:` | bermuda, country, flag, flag |
| 🇧🇳 | `:bn:`, `:flag_bn:` | brunei, country, flag, flag |
| 🇧🇴 | `:bo:`, `:flag_bo:` | bolivia, country, flag, flag |
| 🐗 | `:boar:` | boar, wildlife, animal, animal |
| 💣 | `:bomb:` | bomb, object, weapon, dead, blast, blast |
| 📖 | `:book:` | open, book, object, office, write, book |
| 🔖 | `:bookmark:` | bookmark, object, book |
| 📑 | `:bookmark_tabs:` | bookmark, tabs, office, write |
| 📚 | `:books:` | books, object, office, write, book |
| 💥 | `:boom:` | collision, symbol, symbol, blast, blast |
| 👢 | `:boot:` | womans, boots, women, fashion, shoe, sexy, accessories |
| 🍾 | `:bottle_with_popping_cork:`, `:champagne:` | bottle, with, popping, cork, drink, cheers, alcohol, parties, parties |
| 💐 | `:bouquet:` | bouquet, nature, flower, plant, rip, rip, condolence, condolence |
| 🙇 | `:bow:` | person, bowing, deeply, people, pray, pray, diversity, diversity |
| 🙇🏻 | `:bow_tone1:` | person, bowing, deeply, tone, 1 |
| 🙇🏼 | `:bow_tone2:` | person, bowing, deeply, tone, 2 |
| 🙇🏽 | `:bow_tone3:` | person, bowing, deeply, tone, 3 |
| 🙇🏾 | `:bow_tone4:` | person, bowing, deeply, tone, 4 |
| 🙇🏿 | `:bow_tone5:` | person, bowing, deeply, tone, 5 |
| 🎳 | `:bowling:` | bowling, game, ball, sport, boys, night, boys, night |
| 🥊 | `:boxing_gloves:`, `:boxing_glove:` | boxing, glove |
| 👦 | `:boy:` | boy, people, baby, diversity, diversity |
| 👦🏻 | `:boy_tone1:` | boy, tone, 1 |
| 👦🏼 | `:boy_tone2:` | boy, tone, 2 |
| 👦🏽 | `:boy_tone3:` | boy, tone, 3 |
| 👦🏾 | `:boy_tone4:` | boy, tone, 4 |
| 👦🏿 | `:boy_tone5:` | boy, tone, 5 |
| 🇧🇶 | `:bq:`, `:flag_bq:` | caribbean, netherlands, country, flag, flag |
| 🇧🇷 | `:br:`, `:flag_br:` | brazil, country, flag, flag |
| 🍞 | `:bread:` | bread, food |
| 👰 | `:bride_with_veil:` | bride, with, veil, people, wedding, women, diversity, diversity |
| 👰🏻 | `:bride_with_veil_tone1:` | bride, with, veil, tone, 1 |
| 👰🏼 | `:bride_with_veil_tone2:` | bride, with, veil, tone, 2 |
| 👰🏽 | `:bride_with_veil_tone3:` | bride, with, veil, tone, 3 |
| 👰🏾 | `:bride_with_veil_tone4:` | bride, with, veil, tone, 4 |
| 👰🏿 | `:bride_with_veil_tone5:` | bride, with, veil, tone, 5 |
| 🌉 | `:bridge_at_night:` | bridge, at, night, places, travel, vacation, goodnight, goodnight |
| 💼 | `:briefcase:` | briefcase, bag, work, accessories, nutcase, nutcase, job, job |
| 💔 | `:broken_heart:` | broken, heart, love, symbol, heartbreak, heartbreak |
| 🇧🇸 | `:bs:`, `:flag_bs:` | the, bahamas, country, flag, flag |
| 🇧🇹 | `:bt:`, `:flag_bt:` | bhutan, country, flag, flag |
| 🐛 | `:bug:` | bug, insects, animal, animal |
| 🏗 | `:building_construction:`, `:construction_site:` | building, construction, building, crane |
| 💡 | `:bulb:` | electric, light, bulb, object, science |
| 🚅 | `:bullettrain_front:` | high-speed, train, with, bullet, nose, transportation, travel, train |
| 🚄 | `:bullettrain_side:` | high-speed, train, transportation, travel, train |
| 🌯 | `:burrito:` | burrito, food, mexican |
| 🚌 | `:bus:` | bus, transportation, bus, office |
| 🚏 | `:busstop:` | bus, stop, object |
| 👤 | `:bust_in_silhouette:` | bust, in, silhouette, people |
| 👥 | `:busts_in_silhouette:` | busts, in, silhouette, people |
| 🦋 | `:butterfly:` | butterfly |
| 🇧🇻 | `:bv:`, `:flag_bv:` | bouvet, island, country, flag, flag |
| 🇧🇼 | `:bw:`, `:flag_bw:` | botswana, country, flag, flag |
| 🇧🇾 | `:by:`, `:flag_by:` | belarus, country, flag, flag |
| 🇧🇿 | `:bz:`, `:flag_bz:` | belize, country, flag, flag |
| 🇨🇦 | `:ca:`, `:flag_ca:` | canada, country, flag, flag |
| 🌵 | `:cactus:` | cactus, nature, plant, trees, trees |
| 🍰 | `:cake:` | shortcake, food |
| 📆 | `:calendar:` | tear-off, calendar, object, office |
| 🗓 | `:spiral_calendar_pad:`, `:calendar_spiral:` | spiral, calendar, pad, object, office |
| 🤙 | `:call_me_hand:`, `:call_me:` | call, me, hand |
| 🤙🏻 | `:call_me_hand_tone1:`, `:call_me_tone1:` | call, me, hand, tone, 1 |
| 🤙🏼 | `:call_me_hand_tone2:`, `:call_me_tone2:` | call, me, hand, tone, 2 |
| 🤙🏽 | `:call_me_hand_tone3:`, `:call_me_tone3:` | call, me, hand, tone, 3 |
| 🤙🏾 | `:call_me_hand_tone4:`, `:call_me_tone4:` | call, me, hand, tone, 4 |
| 🤙🏿 | `:call_me_hand_tone5:`, `:call_me_tone5:` | call, me, hand, tone, 5 |
| 📲 | `:calling:` | mobile, phone, with, rightwards, arrow, at, left, electronics, phone, selfie, selfie |
| 🐫 | `:camel:` | bactrian, camel, wildlife, animal, animal, hump, day, hump, day |
| 📷 | `:camera:` | camera, electronics, camera, selfie, selfie |
| 📸 | `:camera_with_flash:` | camera, with, flash, electronics, camera |
| 🏕 | `:camping:` | camping, places, travel, vacation, camp |
| ♋ | `:cancer:` | cancer, zodiac, symbol |
| 🕯 | `:candle:` | candle, object |
| 🍬 | `:candy:` | candy, food, halloween |
| 🛶 | `:kayak:`, `:canoe:` | canoe |
| 🔠 | `:capital_abcd:` | input, symbol, for, latin, capital, letters, symbol |
| ♑ | `:capricorn:` | capricorn, zodiac, symbol |
| 🗃 | `:card_file_box:`, `:card_box:` | card, file, box, object, work, office |
| 📇 | `:card_index:` | card, index, object, work, office |
| 🗂 | `:card_index_dividers:`, `:dividers:` | card, index, dividers, work, office |
| 🎠 | `:carousel_horse:` | carousel, horse, places, object, vacation, roller, coaster, carousel |
| 🥕 | `:carrot:` | carrot |
| 🤸 | `:person_doing_cartwheel:`, `:cartwheel:` | person, doing, cartwheel |
| 🤸🏻 | `:person_doing_cartwheel_tone1:`, `:cartwheel_tone1:` | person, doing, cartwheel, tone, 1 |
| 🤸🏼 | `:person_doing_cartwheel_tone2:`, `:cartwheel_tone2:` | person, doing, cartwheel, tone, 2 |
| 🤸🏽 | `:person_doing_cartwheel_tone3:`, `:cartwheel_tone3:` | person, doing, cartwheel, tone, 3 |
| 🤸🏾 | `:person_doing_cartwheel_tone4:`, `:cartwheel_tone4:` | person, doing, cartwheel, tone, 4 |
| 🤸🏿 | `:person_doing_cartwheel_tone5:`, `:cartwheel_tone5:` | person, doing, cartwheel, tone, 5 |
| 🐱 | `:cat:` | cat, face, halloween, vagina, cat, cat, animal, animal |
| 🐈 | `:cat2:` | cat, halloween, cat, cat, animal, animal |
| 🇨🇨 | `:cc:`, `:flag_cc:` | cocos, (keeling), islands, country, flag, flag |
| 💿 | `:cd:` | optical, disc, electronics |
| 🇨🇫 | `:cf:`, `:flag_cf:` | central, african, republic, country, flag, flag |
| 🇨🇬 | `:cg:`, `:flag_cg:` | the, republic, of, the, congo, country, flag, flag |
| 🇨🇭 | `:ch:`, `:flag_ch:` | switzerland, country, neutral, flag, flag |
| ⛓ | `:chains:` | chains, object, tool |
| 🥂 | `:clinking_glass:`, `:champagne_glass:` | clinking, glasses |
| 💹 | `:chart:` | chart, with, upwards, trend, and, yen, sign, symbol, money, money |
| 📉 | `:chart_with_downwards_trend:` | chart, with, downwards, trend, work, office |
| 📈 | `:chart_with_upwards_trend:` | chart, with, upwards, trend, work, office |
| 🏁 | `:checkered_flag:` | chequered, flag, object |
| 🧀 | `:cheese_wedge:`, `:cheese:` | cheese, wedge, food |
| 🍒 | `:cherries:` | cherries, fruit, food |
| 🌸 | `:cherry_blossom:` | cherry, blossom, nature, flower, plant, tropical |
| 🌰 | `:chestnut:` | chestnut, nature, plant |
| 🐔 | `:chicken:` | chicken, animal, animal, chicken, chicken |
| 🚸 | `:children_crossing:` | children, crossing, symbol |
| 🇨🇱 | `:chile:`, `:flag_cl:` | chile, country, flag, flag |
| 🐿 | `:chipmunk:` | chipmunk, wildlife, animal, animal |
| 🍫 | `:chocolate_bar:` | chocolate, bar, food, halloween |
| 🎄 | `:christmas_tree:` | christmas, tree, plant, holidays, christmas, trees, trees |
| ⛪ | `:church:` | church, places, wedding, religion, building, condolence, condolence |
| 🇨🇮 | `:ci:`, `:flag_ci:` | côte, d’ivoire, country, flag, flag |
| 🎦 | `:cinema:` | cinema, symbol, camera, movie |
| 🎪 | `:circus_tent:` | circus, tent, circus, tent |
| 🌆 | `:city_dusk:` | cityscape, at, dusk, places, building |
| 🌇 | `:city_sunrise:`, `:city_sunset:` | sunset, over, buildings, places, building, sky, vacation |
| 🏙 | `:cityscape:` | cityscape, places, building, vacation |
| 🇨🇰 | `:ck:`, `:flag_ck:` | cook, islands, country, flag, flag |
| 🆑 | `:cl:` | squared, cl, symbol |
| 👏 | `:clap:` | clapping, hands, sign, body, hands, win, win, diversity, diversity, good, good, beautiful, beautiful |
| 👏🏻 | `:clap_tone1:` | clapping, hands, sign, tone, 1 |
| 👏🏼 | `:clap_tone2:` | clapping, hands, sign, tone, 2 |
| 👏🏽 | `:clap_tone3:` | clapping, hands, sign, tone, 3 |
| 👏🏾 | `:clap_tone4:` | clapping, hands, sign, tone, 4 |
| 👏🏿 | `:clap_tone5:` | clapping, hands, sign, tone, 5 |
| 🎬 | `:clapper:` | clapper, board, movie |
| 🏛 | `:classical_building:` | classical, building, places, building, travel, vacation |
| 📋 | `:clipboard:` | clipboard, object, work, office, write |
| 🕰 | `:mantlepiece_clock:`, `:clock:` | mantlepiece, clock, object, time |
| 🕐 | `:clock1:` | clock, face, one, oclock, symbol, time |
| 🕙 | `:clock10:` | clock, face, ten, oclock, symbol, time |
| 🕥 | `:clock1030:` | clock, face, ten-thirty, symbol, time |
| 🕚 | `:clock11:` | clock, face, eleven, oclock, symbol, time |
| 🕦 | `:clock1130:` | clock, face, eleven-thirty, symbol, time |
| 🕛 | `:clock12:` | clock, face, twelve, oclock, symbol, time |
| 🕧 | `:clock1230:` | clock, face, twelve-thirty, symbol, time |
| 🕜 | `:clock130:` | clock, face, one-thirty, symbol, time |
| 🕑 | `:clock2:` | clock, face, two, oclock, symbol, time |
| 🕝 | `:clock230:` | clock, face, two-thirty, symbol, time |
| 🕒 | `:clock3:` | clock, face, three, oclock, symbol, time |
| 🕞 | `:clock330:` | clock, face, three-thirty, symbol, time |
| 🕓 | `:clock4:` | clock, face, four, oclock, symbol, time |
| 🕟 | `:clock430:` | clock, face, four-thirty, symbol, time |
| 🕔 | `:clock5:` | clock, face, five, oclock, symbol, time |
| 🕠 | `:clock530:` | clock, face, five-thirty, symbol, time |
| 🕕 | `:clock6:` | clock, face, six, oclock, symbol, time |
| 🕡 | `:clock630:` | clock, face, six-thirty, symbol, time |
| 🕖 | `:clock7:` | clock, face, seven, oclock, symbol, time |
| 🕢 | `:clock730:` | clock, face, seven-thirty, symbol, time |
| 🕗 | `:clock8:` | clock, face, eight, oclock, symbol, time |
| 🕣 | `:clock830:` | clock, face, eight-thirty, symbol, time |
| 🕘 | `:clock9:` | clock, face, nine, oclock, symbol, time |
| 🕤 | `:clock930:` | clock, face, nine-thirty, symbol, time |
| 📕 | `:closed_book:` | closed, book, object, office, write, book |
| 🔐 | `:closed_lock_with_key:` | closed, lock, with, key, object, lock |
| 🌂 | `:closed_umbrella:` | closed, umbrella, object, sky, rain, accessories |
| ☁ | `:cloud:` | cloud, weather, sky, cloud, cold, rain |
| 🌩 | `:cloud_with_lightning:`, `:cloud_lightning:` | cloud, with, lightning, weather, sky, cloud, cold, rain |
| 🌧 | `:cloud_with_rain:`, `:cloud_rain:` | cloud, with, rain, weather, winter, sky, cloud, cold, rain |
| 🌨 | `:cloud_with_snow:`, `:cloud_snow:` | cloud, with, snow, weather, winter, sky, cloud, cold, snow, snow |
| 🌪 | `:cloud_with_tornado:`, `:cloud_tornado:` | cloud, with, tornado, weather, sky, cold |
| 🤡 | `:clown_face:`, `:clown:` | clown, face |
| ♣ | `:clubs:` | black, club, suit, symbol, game |
| 🇨🇲 | `:cm:`, `:flag_cm:` | cameroon, country, flag, flag |
| 🇨🇳 | `:cn:`, `:flag_cn:` | china, country, flag, flag |
| 🇨🇴 | `:co:`, `:flag_co:` | colombia, country, flag, flag |
| 🍸 | `:cocktail:` | cocktail, glass, drink, cocktail, alcohol, girls, night, girls, night, parties, parties |
| ☕ | `:coffee:` | hot, beverage, drink, caffeine, steam, steam, morning, morning |
| ⚰ | `:coffin:` | coffin, object, dead, rip, rip |
| 😰 | `:cold_sweat:` | face, with, open, mouth, and, cold, sweat, smiley, sweat, emotion, emotion |
| ☄ | `:comet:` | comet, space, sky |
| 🗜 | `:compression:` | compression |
| 💻 | `:computer:` | personal, computer, electronics, work, office |
| 🎊 | `:confetti_ball:` | confetti, ball, object, birthday, holidays, cheers, girls, night, girls, night, boys, night, boys, night, parties, parties |
| 😖 | `:confounded:` | confounded, face, sad, smiley, angry, emotion, emotion |
| 😕 | `:confused:` | confused, face, smiley, surprised, emotion, emotion |
| 🇨🇩 | `:congo:`, `:flag_cd:` | the, democratic, republic, of, the, congo, country, flag, flag |
| ㊗ | `:congratulations:` | circled, ideograph, congratulation, japan, symbol |
| 🚧 | `:construction:` | construction, sign, object |
| 👷 | `:construction_worker:` | construction, worker, people, hat, men, diversity, diversity, job, job |
| 👷🏻 | `:construction_worker_tone1:` | construction, worker, tone, 1 |
| 👷🏼 | `:construction_worker_tone2:` | construction, worker, tone, 2 |
| 👷🏽 | `:construction_worker_tone3:` | construction, worker, tone, 3 |
| 👷🏾 | `:construction_worker_tone4:` | construction, worker, tone, 4 |
| 👷🏿 | `:construction_worker_tone5:` | construction, worker, tone, 5 |
| 🎛 | `:control_knobs:` | control, knobs, time |
| 🏪 | `:convenience_store:` | convenience, store, places, building |
| 🍪 | `:cookie:` | cookie, food, vagina |
| 🍳 | `:cooking:` | cooking, food |
| 🆒 | `:cool:` | squared, cool, symbol |
| 👮 | `:cop:` | police, officer, people, hat, men, diversity, diversity, job, job, police, police, 911, 911 |
| 👮🏻 | `:cop_tone1:` | police, officer, tone, 1 |
| 👮🏼 | `:cop_tone2:` | police, officer, tone, 2 |
| 👮🏽 | `:cop_tone3:` | police, officer, tone, 3 |
| 👮🏾 | `:cop_tone4:` | police, officer, tone, 4 |
| 👮🏿 | `:cop_tone5:` | police, officer, tone, 5 |
| © | `:copyright:` | copyright, sign, symbol |
| 🌽 | `:corn:` | ear, of, maize, vegetables, food |
| 🛋 | `:couch_and_lamp:`, `:couch:` | couch, and, lamp, object |
| 👫 | `:couple:` | man, and, woman, holding, hands, people, sex, creationism, creationism |
| 👨❤👨 | `:couple_with_heart_mm:`, `:couple_mm:` | couple, (man,man), people, gay, men, love, sex, lgbt, lgbt |
| 💑 | `:couple_with_heart:` | couple, with, heart, people, love, sex |
| 👩❤👩 | `:couple_with_heart_ww:`, `:couple_ww:` | couple, (woman,woman), people, women, love, sex, lgbt, lgbt |
| 💏 | `:couplekiss:` | kiss, people, love, sex |
| 👨❤💋👨 | `:couplekiss_mm:`, `:kiss_mm:` | kiss, (man,man), people, gay, men, love, sex, lgbt, lgbt |
| 👩❤💋👩 | `:couplekiss_ww:`, `:kiss_ww:` | kiss, (woman,woman), people, women, love, sex, lgbt, lgbt, lesbian, lesbian |
| 🐮 | `:cow:` | cow, face, animal, animal |
| 🐄 | `:cow2:` | cow, animal, animal |
| 🤠 | `:face_with_cowboy_hat:`, `:cowboy:` | face, with, cowboy, hat |
| 🇨🇵 | `:cp:`, `:flag_cp:` | clipperton, island, country, flag, flag |
| 🇨🇷 | `:cr:`, `:flag_cr:` | costa, rica, country, flag, flag |
| 🦀 | `:crab:` | crab, tropical, animal, animal |
| 🖍 | `:lower_left_crayon:`, `:crayon:` | lower, left, crayon, object, office, write |
| 💳 | `:credit_card:` | credit, card, object, money, money, boys, night, boys, night |
| 🌙 | `:crescent_moon:` | crescent, moon, space, sky, goodnight, goodnight, moon, moon |
| 🏏 | `:cricket_bat_ball:`, `:cricket:` | cricket, bat, and, ball, ball, sport, cricket |
| 🐊 | `:crocodile:` | crocodile, wildlife, reptile, reptile, animal, animal |
| 🥐 | `:croissant:` | croissant |
| ✝ | `:latin_cross:`, `:cross:` | latin, cross, religion, symbol |
| 🎌 | `:crossed_flags:` | crossed, flags, object, japan |
| ⚔ | `:crossed_swords:` | crossed, swords, object, weapon |
| 👑 | `:crown:` | crown, object, gem, accessories |
| 🛳 | `:passenger_ship:`, `:cruise_ship:` | passenger, ship, transportation, travel, boat, vacation |
| 😢 | `:cry:` | crying, face, sad, smiley, cry, emotion, emotion, rip, rip, heartbreak, heartbreak |
| 😿 | `:crying_cat_face:` | crying, cat, face, cry, cat, cat, animal, animal |
| 🔮 | `:crystal_ball:` | crystal, ball, object, ball |
| 🇨🇺 | `:cu:`, `:flag_cu:` | cuba, country, flag, flag |
| 🥒 | `:cucumber:` | cucumber |
| 💘 | `:cupid:` | heart, with, arrow, love, symbol |
| ➰ | `:curly_loop:` | curly, loop, symbol |
| 💱 | `:currency_exchange:` | currency, exchange, symbol, money, money |
| 🍛 | `:curry:` | curry, and, rice, food |
| 🍮 | `:pudding:`, `:flan:`, `:custard:` | custard, food |
| 🛃 | `:customs:` | customs, symbol |
| 🇨🇻 | `:cv:`, `:flag_cv:` | cape, verde, country, flag, flag |
| 🇨🇼 | `:cw:`, `:flag_cw:` | curaçao, country, flag, flag |
| 🇨🇽 | `:cx:`, `:flag_cx:` | christmas, island, country, flag, flag |
| 🇨🇾 | `:cy:`, `:flag_cy:` | cyprus, country, flag, flag |
| 🌀 | `:cyclone:` | cyclone, symbol, drugs, drugs |
| 🇨🇿 | `:cz:`, `:flag_cz:` | the, czech, republic, country, flag, flag |
| 🗡 | `:dagger_knife:`, `:dagger:` | dagger, knife, object, weapon |
| 💃 | `:dancer:` | dancer, people, women, sexy, diversity, diversity, girls, night, girls, night, dance, dance |
| 💃🏻 | `:dancer_tone1:` | dancer, tone, 1 |
| 💃🏼 | `:dancer_tone2:` | dancer, tone, 2 |
| 💃🏽 | `:dancer_tone3:` | dancer, tone, 3 |
| 💃🏾 | `:dancer_tone4:` | dancer, tone, 4 |
| 💃🏿 | `:dancer_tone5:` | dancer, tone, 5 |
| 👯 | `:dancers:` | woman, with, bunny, ears, people, women, sexy, girls, night, girls, night, boys, night, boys, night, parties, parties, dance, dance |
| 🍡 | `:dango:` | dango, food |
| 🕶 | `:dark_sunglasses:` | dark, sunglasses, fashion, glasses, accessories |
| 🎯 | `:dart:` | direct, hit, game, sport, boys, night, boys, night |
| 💨 | `:dash:` | dash, symbol, cloud, cold, smoking, smoking |
| 📅 | `:date:` | calendar, object, office |
| 🇩🇪 | `:de:`, `:flag_de:` | germany, country, flag, flag |
| 🌳 | `:deciduous_tree:` | deciduous, tree, nature, plant, camp, trees, trees |
| 🦌 | `:deer:` | deer |
| 🏬 | `:department_store:` | department, store, places, building |
| 🏚 | `:derelict_house_building:`, `:house_abandoned:` | derelict, house, building, places, building, house |
| 🏜 | `:desert:` | desert, places, travel, vacation, hot, hot |
| 🏝 | `:desert_island:`, `:island:` | desert, island, places, travel, vacation, tropical, beach, swim |
| 🖥 | `:desktop_computer:`, `:desktop:` | desktop, computer, electronics, work |
| 🇩🇬 | `:dg:`, `:flag_dg:` | diego, garcia, country, flag, flag |
| 💠 | `:diamond_shape_with_a_dot_inside:` | diamond, shape, with, a, dot, inside, symbol |
| ♦ | `:diamonds:` | black, diamond, suit, shapes, symbol, game |
| 😞 | `:disappointed:` | disappointed, face, sad, smiley, tired, emotion, emotion |
| 😥 | `:disappointed_relieved:` | disappointed, but, relieved, face, sad, smiley, stressed, sweat, cry, emotion, emotion |
| 💫 | `:dizzy:` | dizzy, symbol, star, symbol |
| 😵 | `:dizzy_face:` | dizzy, face, smiley, surprised, dead, wow, wow, emotion, emotion, omg, omg |
| 🇩🇯 | `:dj:`, `:flag_dj:` | djibouti, country, flag, flag |
| 🇩🇰 | `:dk:`, `:flag_dk:` | denmark, country, flag, flag |
| 🇩🇲 | `:dm:`, `:flag_dm:` | dominica, country, flag, flag |
| 🇩🇴 | `:do:`, `:flag_do:` | the, dominican, republic, country, flag, flag |
| 🚯 | `:do_not_litter:` | do, not, litter, symbol, symbol |
| 🐶 | `:dog:` | dog, face, dog, dog, pug, pug, animal, animal |
| 🐕 | `:dog2:` | dog, dog, dog, pug, pug, animal, animal |
| 💵 | `:dollar:` | banknote, with, dollar, sign, money, money |
| 🎎 | `:dolls:` | japanese, dolls, people, japan |
| 🐬 | `:dolphin:` | dolphin, wildlife, tropical, animal, animal |
| 🚪 | `:door:` | door, object |
| ⏸ | `:double_vertical_bar:`, `:pause_button:` | double, vertical, bar, symbol |
| 🍩 | `:doughnut:` | doughnut, food |
| 🕊 | `:dove_of_peace:`, `:dove:` | dove, of, peace, animal, animal |
| 🐉 | `:dragon:` | dragon, roar, reptile, reptile, animal, animal |
| 🐲 | `:dragon_face:` | dragon, face, roar, monster, reptile, reptile, animal, animal |
| 👗 | `:dress:` | dress, women, fashion, sexy, girls, night, girls, night |
| 🐪 | `:dromedary_camel:` | dromedary, camel, wildlife, animal, animal |
| 🤤 | `:drool:`, `:drooling_face:` | drooling, face |
| 💧 | `:droplet:` | droplet, weather, sky, rain |
| 🥁 | `:drum_with_drumsticks:`, `:drum:` | drum, with, drumsticks |
| 🦆 | `:duck:` | duck |
| 📀 | `:dvd:` | dvd, electronics |
| 🇩🇿 | `:dz:`, `:flag_dz:` | algeria, country, flag, flag |
| 📧 | `:email:`, `:e-mail:` | e-mail, symbol, office |
| 🇪🇦 | `:ea:`, `:flag_ea:` | ceuta,, melilla, country, flag, flag |
| 🦅 | `:eagle:` | eagle |
| 👂 | `:ear:` | ear, body, diversity, diversity |
| 🌾 | `:ear_of_rice:` | ear, of, rice, nature, plant, leaf, leaf |
| 👂🏻 | `:ear_tone1:` | ear, tone, 1 |
| 👂🏼 | `:ear_tone2:` | ear, tone, 2 |
| 👂🏽 | `:ear_tone3:` | ear, tone, 3 |
| 👂🏾 | `:ear_tone4:` | ear, tone, 4 |
| 👂🏿 | `:ear_tone5:` | ear, tone, 5 |
| 🌍 | `:earth_africa:` | earth, globe, europe-africa, map, vacation, globe, globe |
| 🌎 | `:earth_americas:` | earth, globe, americas, map, vacation, globe, globe |
| 🌏 | `:earth_asia:` | earth, globe, asia-australia, map, vacation, globe, globe |
| 🇪🇨 | `:ec:`, `:flag_ec:` | ecuador, country, flag, flag |
| 🇪🇪 | `:ee:`, `:flag_ee:` | estonia, country, flag, flag |
| 🇪🇬 | `:eg:`, `:flag_eg:` | egypt, country, flag, flag |
| 🥚 | `:egg:` | egg |
| 🍆 | `:eggplant:` | aubergine, vegetables, penis, food |
| 🇪🇭 | `:eh:`, `:flag_eh:` | western, sahara, country, flag, flag |
| 8⃣ | `:eight:` | keycap, digit, eight, number, math, symbol |
| ✴ | `:eight_pointed_black_star:` | eight, pointed, black, star, symbol |
| ✳ | `:eight_spoked_asterisk:` | eight, spoked, asterisk, symbol |
| ⏏ | `:eject_symbol:`, `:eject:` | eject, symbol |
| 🔌 | `:electric_plug:` | electric, plug, electronics |
| 🐘 | `:elephant:` | elephant, wildlife, animal, animal |
| 🔚 | `:end:` | end, with, leftwards, arrow, above, arrow, symbol |
| ✉ | `:envelope:` | envelope, object, office, write |
| 📩 | `:envelope_with_arrow:` | envelope, with, downwards, arrow, above, object, office |
| 🇪🇷 | `:er:`, `:flag_er:` | eritrea, country, flag, flag |
| 🇪🇸 | `:es:`, `:flag_es:` | spain, country, flag, flag |
| 🇪🇹 | `:et:`, `:flag_et:` | ethiopia, country, flag, flag |
| 🇪🇺 | `:eu:`, `:flag_eu:` | european, union, country, flag, flag |
| 💶 | `:euro:` | banknote, with, euro, sign, money, money |
| 🏰 | `:european_castle:` | european, castle, places, building, travel, vacation |
| 🏤 | `:european_post_office:` | european, post, office, places, building, post, office |
| 🌲 | `:evergreen_tree:` | evergreen, tree, nature, plant, holidays, christmas, camp, trees, trees |
| ❗ | `:exclamation:` | heavy, exclamation, mark, symbol, symbol, punctuation |
| 🤰 | `:expecting_woman:`, `:pregnant_woman:` | pregnant, woman |
| 🤰🏻 | `:expecting_woman_tone1:`, `:pregnant_woman_tone1:` | pregnant, woman, tone, 1 |
| 🤰🏼 | `:expecting_woman_tone2:`, `:pregnant_woman_tone2:` | pregnant, woman, tone, 2 |
| 🤰🏽 | `:expecting_woman_tone3:`, `:pregnant_woman_tone3:` | pregnant, woman, tone, 3 |
| 🤰🏾 | `:expecting_woman_tone4:`, `:pregnant_woman_tone4:` | pregnant, woman, tone, 4 |
| 🤰🏿 | `:expecting_woman_tone5:`, `:pregnant_woman_tone5:` | pregnant, woman, tone, 5 |
| 😑 | `:expressionless:` | expressionless, face, mad, smiley, neutral, emotion, emotion |
| 👁 | `:eye:` | eye, body, eyes |
| 👁🗨 | `:eye_in_speech_bubble:` | eye, in, speech, bubble, object, symbol, eyes, talk |
| 👓 | `:eyeglasses:` | eyeglasses, fashion, glasses, accessories |
| 👀 | `:eyes:` | eyes, body, eyes |
| 🤦 | `:facepalm:`, `:face_palm:` | face, palm |
| 🤦🏻 | `:facepalm_tone1:`, `:face_palm_tone1:` | face, palm, tone, 1 |
| 🤦🏼 | `:facepalm_tone2:`, `:face_palm_tone2:` | face, palm, tone, 2 |
| 🤦🏽 | `:facepalm_tone3:`, `:face_palm_tone3:` | face, palm, tone, 3 |
| 🤦🏾 | `:facepalm_tone4:`, `:face_palm_tone4:` | face, palm, tone, 4 |
| 🤦🏿 | `:facepalm_tone5:`, `:face_palm_tone5:` | face, palm, tone, 5 |
| 🤕 | `:face_with_head_bandage:`, `:head_bandage:` | face, with, head-bandage, smiley, health, sick, emotion, emotion |
| 🙄 | `:face_with_rolling_eyes:`, `:rolling_eyes:` | face, with, rolling, eyes, mad, smiley, rolling, eyes, emotion, emotion, sarcastic, sarcastic |
| 🤒 | `:face_with_thermometer:`, `:thermometer_face:` | face, with, thermometer, smiley, health, sick, emotion, emotion |
| 🏭 | `:factory:` | factory, places, building, travel, steam, steam |
| 🍂 | `:fallen_leaf:` | fallen, leaf, nature, plant, leaf, leaf |
| 👪 | `:family:` | family, people, family, baby |
| 👨👨👦 | `:family_mmb:` | family, (man,man,boy), people, gay, family, men, baby, lgbt, lgbt |
| 👨👨👦👦 | `:family_mmbb:` | family, (man,man,boy,boy), people, gay, family, men, baby, lgbt, lgbt |
| 👨👨👧 | `:family_mmg:` | family, (man,man,girl), people, gay, family, men, baby, lgbt, lgbt |
| 👨👨👧👦 | `:family_mmgb:` | family, (man,man,girl,boy), people, gay, family, men, baby, lgbt, lgbt |
| 👨👨👧👧 | `:family_mmgg:` | family, (man,man,girl,girl), people, gay, family, men, baby, lgbt, lgbt |
| 👨👩👦👦 | `:family_mwbb:` | family, (man,woman,boy,boy), people, family, baby |
| 👨👩👧 | `:family_mwg:` | family, (man,woman,girl), people, family, baby |
| 👨👩👧👦 | `:family_mwgb:` | family, (man,woman,girl,boy), people, family, baby |
| 👨👩👧👧 | `:family_mwgg:` | family, (man,woman,girl,girl), people, family, baby |
| 👩👩👦 | `:family_wwb:` | family, (woman,woman,boy), people, family, women, baby, lgbt, lgbt, lesbian, lesbian |
| 👩👩👦👦 | `:family_wwbb:` | family, (woman,woman,boy,boy), people, family, women, baby, lgbt, lgbt, lesbian, lesbian |
| 👩👩👧 | `:family_wwg:` | family, (woman,woman,girl), people, family, women, baby, lgbt, lgbt, lesbian, lesbian |
| 👩👩👧👦 | `:family_wwgb:` | family, (woman,woman,girl,boy), people, family, women, baby, lgbt, lgbt, lesbian, lesbian |
| 👩👩👧👧 | `:family_wwgg:` | family, (woman,woman,girl,girl), people, family, women, baby, lgbt, lgbt, lesbian, lesbian |
| ⏩ | `:fast_forward:` | black, right-pointing, double, triangle, arrow, symbol |
| 📠 | `:fax:` | fax, machine, electronics, work, office |
| 😨 | `:fearful:` | fearful, face, smiley, surprised, emotion, emotion |
| 🐾 | `:paw_prints:`, `:feet:` | paw, prints, animal, animal |
| 🤺 | `:fencing:`, `:fencer:` | fencer |
| 🎡 | `:ferris_wheel:` | ferris, wheel, places, vacation, ferris, wheel |
| ⛴ | `:ferry:` | ferry, transportation, travel, boat, vacation |
| 🇫🇮 | `:fi:`, `:flag_fi:` | finland, country, flag, flag |
| 🏑 | `:field_hockey:` | field, hockey, stick, and, ball, ball, sport, hockey |
| 🗄 | `:file_cabinet:` | file, cabinet, object, work, office |
| 📁 | `:file_folder:` | file, folder, work, office |
| 🎞 | `:film_frames:` | film, frames, object, camera, movie |
| 📽 | `:film_projector:`, `:projector:` | film, projector, object, camera, movie |
| 🤞 | `:hand_with_index_and_middle_finger_crossed:`, `:fingers_crossed:` | hand, with, first, and, index, finger, crossed |
| 🤞🏻 | `:hand_with_index_and_middle_fingers_crossed_tone1:`, `:fingers_crossed_tone1:` | hand, with, index, and, middle, fingers, crossed, tone, 1 |
| 🤞🏼 | `:hand_with_index_and_middle_fingers_crossed_tone2:`, `:fingers_crossed_tone2:` | hand, with, index, and, middle, fingers, crossed, tone, 2 |
| 🤞🏽 | `:hand_with_index_and_middle_fingers_crossed_tone3:`, `:fingers_crossed_tone3:` | hand, with, index, and, middle, fingers, crossed, tone, 3 |
| 🤞🏾 | `:hand_with_index_and_middle_fingers_crossed_tone4:`, `:fingers_crossed_tone4:` | hand, with, index, and, middle, fingers, crossed, tone, 4 |
| 🤞🏿 | `:hand_with_index_and_middle_fingers_crossed_tone5:`, `:fingers_crossed_tone5:` | hand, with, index, and, middle, fingers, crossed, tone, 5 |
| 🔥 | `:flame:`, `:fire:` | fire, wth, wth, hot, hot |
| 🚒 | `:fire_engine:` | fire, engine, transportation, truck, 911, 911 |
| 🎆 | `:fireworks:` | fireworks, parties, parties |
| 🥇 | `:first_place_medal:`, `:first_place:` | first, place, medal |
| 🌓 | `:first_quarter_moon:` | first, quarter, moon, symbol, space, sky, moon, moon |
| 🌛 | `:first_quarter_moon_with_face:` | first, quarter, moon, with, face, space, sky, moon, moon |
| 🐟 | `:fish:` | fish, wildlife, animal, animal |
| 🍥 | `:fish_cake:` | fish, cake, with, swirl, design, sushi, food |
| 🎣 | `:fishing_pole_and_fish:` | fishing, pole, and, fish, vacation, sport, fishing |
| ✊ | `:fist:` | raised, fist, body, hands, hi, fist, bump, diversity, diversity, condolence, condolence |
| ✊🏻 | `:fist_tone1:` | raised, fist, tone, 1 |
| ✊🏼 | `:fist_tone2:` | raised, fist, tone, 2 |
| ✊🏽 | `:fist_tone3:` | raised, fist, tone, 3 |
| ✊🏾 | `:fist_tone4:` | raised, fist, tone, 4 |
| ✊🏿 | `:fist_tone5:` | raised, fist, tone, 5 |
| 5⃣ | `:five:` | keycap, digit, five, number, math, symbol |
| 🇫🇯 | `:fj:`, `:flag_fj:` | fiji, country, flag, flag |
| 🇫🇰 | `:fk:`, `:flag_fk:` | falkland, islands, country, flag, flag |
| 🏴 | `:waving_black_flag:`, `:flag_black:` | waving, black, flag, object |
| 🇫🇲 | `:fm:`, `:flag_fm:` | micronesia, country, flag, flag |
| 🇫🇴 | `:fo:`, `:flag_fo:` | faroe, islands, country, flag, flag |
| 🇫🇷 | `:fr:`, `:flag_fr:` | france, country, flag, flag |
| 🇬🇦 | `:ga:`, `:flag_ga:` | gabon, country, flag, flag |
| 🇬🇧 | `:gb:`, `:flag_gb:` | great, britain, country, flag, flag |
| 🇬🇩 | `:gd:`, `:flag_gd:` | grenada, country, flag, flag |
| 🇬🇪 | `:ge:`, `:flag_ge:` | georgia, country, flag, flag |
| 🇬🇫 | `:gf:`, `:flag_gf:` | french, guiana, country, flag, flag |
| 🇬🇬 | `:gg:`, `:flag_gg:` | guernsey, country, flag, flag |
| 🇬🇭 | `:gh:`, `:flag_gh:` | ghana, country, flag, flag |
| 🇬🇮 | `:gi:`, `:flag_gi:` | gibraltar, country, flag, flag |
| 🇬🇱 | `:gl:`, `:flag_gl:` | greenland, country, flag, flag |
| 🇬🇲 | `:gm:`, `:flag_gm:` | the, gambia, country, flag, flag |
| 🇬🇳 | `:gn:`, `:flag_gn:` | guinea, country, flag, flag |
| 🇬🇵 | `:gp:`, `:flag_gp:` | guadeloupe, country, flag, flag |
| 🇬🇶 | `:gq:`, `:flag_gq:` | equatorial, guinea, country, flag, flag |
| 🇬🇷 | `:gr:`, `:flag_gr:` | greece, country, flag, flag |
| 🇬🇸 | `:gs:`, `:flag_gs:` | south, georgia, country, flag, flag |
| 🇬🇹 | `:gt:`, `:flag_gt:` | guatemala, country, flag, flag |
| 🇬🇺 | `:gu:`, `:flag_gu:` | guam, country, flag, flag |
| 🇬🇼 | `:gw:`, `:flag_gw:` | guinea-bissau, country, flag, flag |
| 🇬🇾 | `:gy:`, `:flag_gy:` | guyana, country, flag, flag |
| 🇭🇰 | `:hk:`, `:flag_hk:` | hong, kong, country, flag, flag |
| 🇭🇲 | `:hm:`, `:flag_hm:` | heard, island, and, mcdonald, islands, country, flag, flag |
| 🇭🇳 | `:hn:`, `:flag_hn:` | honduras, country, flag, flag |
| 🇭🇷 | `:hr:`, `:flag_hr:` | croatia, country, flag, flag |
| 🇭🇹 | `:ht:`, `:flag_ht:` | haiti, country, flag, flag |
| 🇭🇺 | `:hu:`, `:flag_hu:` | hungary, country, flag, flag |
| 🇮🇨 | `:ic:`, `:flag_ic:` | canary, islands, country, flag, flag |
| 🇮🇩 | `:indonesia:`, `:flag_id:` | indonesia, country, flag, flag |
| 🇮🇪 | `:ie:`, `:flag_ie:` | ireland, country, flag, flag |
| 🇮🇱 | `:il:`, `:flag_il:` | israel, jew, country, flag, flag |
| 🇮🇲 | `:im:`, `:flag_im:` | isle, of, man, country, flag, flag |
| 🇮🇳 | `:in:`, `:flag_in:` | india, country, flag, flag |
| 🇮🇴 | `:io:`, `:flag_io:` | british, indian, ocean, territory, country, flag, flag |
| 🇮🇶 | `:iq:`, `:flag_iq:` | iraq, country, flag, flag |
| 🇮🇷 | `:ir:`, `:flag_ir:` | iran, country, flag, flag |
| 🇮🇸 | `:is:`, `:flag_is:` | iceland, country, flag, flag |
| 🇮🇹 | `:it:`, `:flag_it:` | italy, italian, country, flag, flag |
| 🇯🇪 | `:je:`, `:flag_je:` | jersey, country, flag, flag |
| 🇯🇲 | `:jm:`, `:flag_jm:` | jamaica, country, flag, flag |
| 🇯🇴 | `:jo:`, `:flag_jo:` | jordan, country, flag, flag |
| 🇯🇵 | `:jp:`, `:flag_jp:` | japan, japan, country, flag, flag |
| 🇰🇪 | `:ke:`, `:flag_ke:` | kenya, country, flag, flag |
| 🇰🇬 | `:kg:`, `:flag_kg:` | kyrgyzstan, country, flag, flag |
| 🇰🇭 | `:kh:`, `:flag_kh:` | cambodia, country, flag, flag |
| 🇰🇮 | `:ki:`, `:flag_ki:` | kiribati, country, flag, flag |
| 🇰🇲 | `:km:`, `:flag_km:` | the, comoros, country, flag, flag |
| 🇰🇳 | `:kn:`, `:flag_kn:` | saint, kitts, and, nevis, country, flag, flag |
| 🇰🇵 | `:kp:`, `:flag_kp:` | north, korea, country, flag, flag |
| 🇰🇷 | `:kr:`, `:flag_kr:` | korea, country, flag, flag |
| 🇰🇼 | `:kw:`, `:flag_kw:` | kuwait, country, flag, flag |
| 🇰🇾 | `:ky:`, `:flag_ky:` | cayman, islands, country, flag, flag |
| 🇰🇿 | `:kz:`, `:flag_kz:` | kazakhstan, country, flag, flag |
| 🇱🇦 | `:la:`, `:flag_la:` | laos, country, flag, flag |
| 🇱🇧 | `:lb:`, `:flag_lb:` | lebanon, country, flag, flag |
| 🇱🇨 | `:lc:`, `:flag_lc:` | saint, lucia, country, flag, flag |
| 🇱🇮 | `:li:`, `:flag_li:` | liechtenstein, country, flag, flag |
| 🇱🇰 | `:lk:`, `:flag_lk:` | sri, lanka, country, flag, flag |
| 🇱🇷 | `:lr:`, `:flag_lr:` | liberia, country, flag, flag |
| 🇱🇸 | `:ls:`, `:flag_ls:` | lesotho, country, flag, flag |
| 🇱🇹 | `:lt:`, `:flag_lt:` | lithuania, country, flag, flag |
| 🇱🇺 | `:lu:`, `:flag_lu:` | luxembourg, country, flag, flag |
| 🇱🇻 | `:lv:`, `:flag_lv:` | latvia, country, flag, flag |
| 🇱🇾 | `:ly:`, `:flag_ly:` | libya, country, flag, flag |
| 🇲🇦 | `:ma:`, `:flag_ma:` | morocco, country, flag, flag |
| 🇲🇨 | `:mc:`, `:flag_mc:` | monaco, country, flag, flag |
| 🇲🇩 | `:md:`, `:flag_md:` | moldova, country, flag, flag |
| 🇲🇪 | `:me:`, `:flag_me:` | montenegro, country, flag, flag |
| 🇲🇫 | `:mf:`, `:flag_mf:` | saint, martin, country, flag, flag |
| 🇲🇬 | `:mg:`, `:flag_mg:` | madagascar, country, flag, flag |
| 🇲🇭 | `:mh:`, `:flag_mh:` | the, marshall, islands, country, flag, flag |
| 🇲🇰 | `:mk:`, `:flag_mk:` | macedonia, country, flag, flag |
| 🇲🇱 | `:ml:`, `:flag_ml:` | mali, country, flag, flag |
| 🇲🇲 | `:mm:`, `:flag_mm:` | myanmar, country, flag, flag |
| 🇲🇳 | `:mn:`, `:flag_mn:` | mongolia, country, flag, flag |
| 🇲🇴 | `:mo:`, `:flag_mo:` | macau, country, flag, flag |
| 🇲🇵 | `:mp:`, `:flag_mp:` | northern, mariana, islands, country, flag, flag |
| 🇲🇶 | `:mq:`, `:flag_mq:` | martinique, country, flag, flag |
| 🇲🇷 | `:mr:`, `:flag_mr:` | mauritania, country, flag, flag |
| 🇲🇸 | `:ms:`, `:flag_ms:` | montserrat, country, flag, flag |
| 🇲🇹 | `:mt:`, `:flag_mt:` | malta, country, flag, flag |
| 🇲🇺 | `:mu:`, `:flag_mu:` | mauritius, country, flag, flag |
| 🇲🇻 | `:mv:`, `:flag_mv:` | maldives, country, flag, flag |
| 🇲🇼 | `:mw:`, `:flag_mw:` | malawi, country, flag, flag |
| 🇲🇽 | `:mx:`, `:flag_mx:` | mexico, country, mexican, flag, flag |
| 🇲🇾 | `:my:`, `:flag_my:` | malaysia, country, flag, flag |
| 🇲🇿 | `:mz:`, `:flag_mz:` | mozambique, country, flag, flag |
| 🇳🇦 | `:na:`, `:flag_na:` | namibia, country, flag, flag |
| 🇳🇨 | `:nc:`, `:flag_nc:` | new, caledonia, country, flag, flag |
| 🇳🇪 | `:ne:`, `:flag_ne:` | niger, country, flag, flag |
| 🇳🇫 | `:nf:`, `:flag_nf:` | norfolk, island, country, flag, flag |
| 🇳🇬 | `:nigeria:`, `:flag_ng:` | nigeria, country, flag, flag |
| 🇳🇮 | `:ni:`, `:flag_ni:` | nicaragua, country, flag, flag |
| 🇳🇱 | `:nl:`, `:flag_nl:` | the, netherlands, country, flag, flag |
| 🇳🇴 | `:no:`, `:flag_no:` | norway, country, flag, flag |
| 🇳🇵 | `:np:`, `:flag_np:` | nepal, country, flag, flag |
| 🇳🇷 | `:nr:`, `:flag_nr:` | nauru, country, flag, flag |
| 🇳🇺 | `:nu:`, `:flag_nu:` | niue, country, flag, flag |
| 🇳🇿 | `:nz:`, `:flag_nz:` | new, zealand, country, flag, flag |
| 🇴🇲 | `:om:`, `:flag_om:` | oman, country, flag, flag |
| 🇵🇦 | `:pa:`, `:flag_pa:` | panama, country, flag, flag |
| 🇵🇪 | `:pe:`, `:flag_pe:` | peru, country, flag, flag |
| 🇵🇫 | `:pf:`, `:flag_pf:` | french, polynesia, country, flag, flag |
| 🇵🇬 | `:pg:`, `:flag_pg:` | papua, new, guinea, country, flag, flag |
| 🇵🇭 | `:ph:`, `:flag_ph:` | the, philippines, country, flag, flag |
| 🇵🇰 | `:pk:`, `:flag_pk:` | pakistan, country, flag, flag |
| 🇵🇱 | `:pl:`, `:flag_pl:` | poland, country, flag, flag |
| 🇵🇲 | `:pm:`, `:flag_pm:` | saint, pierre, and, miquelon, country, flag, flag |
| 🇵🇳 | `:pn:`, `:flag_pn:` | pitcairn, country, flag, flag |
| 🇵🇷 | `:pr:`, `:flag_pr:` | puerto, rico, country, flag, flag |
| 🇵🇸 | `:ps:`, `:flag_ps:` | palestinian, authority, country, flag, flag |
| 🇵🇹 | `:pt:`, `:flag_pt:` | portugal, country, flag, flag |
| 🇵🇼 | `:pw:`, `:flag_pw:` | palau, country, flag, flag |
| 🇵🇾 | `:py:`, `:flag_py:` | paraguay, country, flag, flag |
| 🇶🇦 | `:qa:`, `:flag_qa:` | qatar, country, flag, flag |
| 🇷🇪 | `:re:`, `:flag_re:` | réunion, country, flag, flag |
| 🇷🇴 | `:ro:`, `:flag_ro:` | romania, country, flag, flag |
| 🇷🇸 | `:rs:`, `:flag_rs:` | serbia, country, flag, flag |
| 🇷🇺 | `:ru:`, `:flag_ru:` | russia, country, flag, flag |
| 🇷🇼 | `:rw:`, `:flag_rw:` | rwanda, country, flag, flag |
| 🇸🇦 | `:saudiarabia:`, `:saudi:`, `:flag_sa:` | saudi, arabia, country, flag, flag |
| 🇸🇧 | `:sb:`, `:flag_sb:` | the, solomon, islands, country, flag, flag |
| 🇸🇨 | `:sc:`, `:flag_sc:` | the, seychelles, country, flag, flag |
| 🇸🇩 | `:sd:`, `:flag_sd:` | sudan, country, flag, flag |
| 🇸🇪 | `:se:`, `:flag_se:` | sweden, country, flag, flag |
| 🇸🇬 | `:sg:`, `:flag_sg:` | singapore, country, flag, flag |
| 🇸🇭 | `:sh:`, `:flag_sh:` | saint, helena, country, flag, flag |
| 🇸🇮 | `:si:`, `:flag_si:` | slovenia, country, flag, flag |
| 🇸🇯 | `:sj:`, `:flag_sj:` | svalbard, and, jan, mayen, country, flag, flag |
| 🇸🇰 | `:sk:`, `:flag_sk:` | slovakia, country, flag, flag |
| 🇸🇱 | `:sl:`, `:flag_sl:` | sierra, leone, country, flag, flag |
| 🇸🇲 | `:sm:`, `:flag_sm:` | san, marino, country, flag, flag |
| 🇸🇳 | `:sn:`, `:flag_sn:` | senegal, country, flag, flag |
| 🇸🇴 | `:so:`, `:flag_so:` | somalia, country, flag, flag |
| 🇸🇷 | `:sr:`, `:flag_sr:` | suriname, country, flag, flag |
| 🇸🇸 | `:ss:`, `:flag_ss:` | south, sudan, country, flag, flag |
| 🇸🇹 | `:st:`, `:flag_st:` | são, tomé, and, príncipe, country, flag, flag |
| 🇸🇻 | `:sv:`, `:flag_sv:` | el, salvador, country, flag, flag |
| 🇸🇽 | `:sx:`, `:flag_sx:` | sint, maarten, country, flag, flag |
| 🇸🇾 | `:sy:`, `:flag_sy:` | syria, country, flag, flag |
| 🇸🇿 | `:sz:`, `:flag_sz:` | swaziland, country, flag, flag |
| 🇹🇦 | `:ta:`, `:flag_ta:` | tristan, da, cunha, country, flag, flag |
| 🇹🇨 | `:tc:`, `:flag_tc:` | turks, and, caicos, islands, country, flag, flag |
| 🇹🇩 | `:td:`, `:flag_td:` | chad, country, flag, flag |
| 🇹🇫 | `:tf:`, `:flag_tf:` | french, southern, territories, country, flag, flag |
| 🇹🇬 | `:tg:`, `:flag_tg:` | togo, country, flag, flag |
| 🇹🇭 | `:th:`, `:flag_th:` | thailand, country, flag, flag |
| 🇹🇯 | `:tj:`, `:flag_tj:` | tajikistan, country, flag, flag |
| 🇹🇰 | `:tk:`, `:flag_tk:` | tokelau, country, flag, flag |
| 🇹🇱 | `:tl:`, `:flag_tl:` | timor-leste, country, flag, flag |
| 🇹🇲 | `:turkmenistan:`, `:flag_tm:` | turkmenistan, country, flag, flag |
| 🇹🇳 | `:tn:`, `:flag_tn:` | tunisia, country, flag, flag |
| 🇹🇴 | `:to:`, `:flag_to:` | tonga, country, flag, flag |
| 🇹🇷 | `:tr:`, `:flag_tr:` | turkey, country, flag, flag |
| 🇹🇹 | `:tt:`, `:flag_tt:` | trinidad, and, tobago, country, flag, flag |
| 🇹🇻 | `:tuvalu:`, `:flag_tv:` | tuvalu, country, flag, flag |
| 🇹🇼 | `:tw:`, `:flag_tw:` | the, republic, of, china, country, flag, flag |
| 🇹🇿 | `:tz:`, `:flag_tz:` | tanzania, country, flag, flag |
| 🇺🇦 | `:ua:`, `:flag_ua:` | ukraine, country, flag, flag |
| 🇺🇬 | `:ug:`, `:flag_ug:` | uganda, country, flag, flag |
| 🇺🇲 | `:um:`, `:flag_um:` | united, states, minor, outlying, islands, country, flag, flag |
| 🇺🇸 | `:us:`, `:flag_us:` | united, states, america, country, flag, flag |
| 🇺🇾 | `:uy:`, `:flag_uy:` | uruguay, country, flag, flag |
| 🇺🇿 | `:uz:`, `:flag_uz:` | uzbekistan, country, flag, flag |
| 🇻🇦 | `:va:`, `:flag_va:` | the, vatican, city, country, flag, flag |
| 🇻🇨 | `:vc:`, `:flag_vc:` | saint, vincent, and, the, grenadines, country, flag, flag |
| 🇻🇪 | `:ve:`, `:flag_ve:` | venezuela, country, flag, flag |
| 🇻🇬 | `:vg:`, `:flag_vg:` | british, virgin, islands, country, flag, flag |
| 🇻🇮 | `:vi:`, `:flag_vi:` | u.s., virgin, islands, country, flag, flag |
| 🇻🇳 | `:vn:`, `:flag_vn:` | vietnam, country, flag, flag |
| 🇻🇺 | `:vu:`, `:flag_vu:` | vanuatu, country, flag, flag |
| 🇼🇫 | `:wf:`, `:flag_wf:` | wallis, and, futuna, country, flag, flag |
| 🏳 | `:waving_white_flag:`, `:flag_white:` | waving, white, flag, object |
| 🇼🇸 | `:ws:`, `:flag_ws:` | samoa, country, flag, flag |
| 🇽🇰 | `:xk:`, `:flag_xk:` | kosovo, country, flag, flag |
| 🇾🇪 | `:ye:`, `:flag_ye:` | yemen, country, flag, flag |
| 🇾🇹 | `:yt:`, `:flag_yt:` | mayotte, country, flag, flag |
| 🇿🇦 | `:za:`, `:flag_za:` | south, africa, country, flag, flag |
| 🇿🇲 | `:zm:`, `:flag_zm:` | zambia, country, flag, flag |
| 🇿🇼 | `:zw:`, `:flag_zw:` | zimbabwe, country, flag, flag |
| 🎏 | `:flags:` | carp, streamer, object, japan |
| 🔦 | `:flashlight:` | electric, torch, electronics, object |
| ⚜ | `:fleur-de-lis:` | fleur-de-lis, object, symbol |
| 💾 | `:floppy_disk:` | floppy, disk, electronics, office |
| 🎴 | `:flower_playing_cards:` | flower, playing, cards, object, symbol |
| 😳 | `:flushed:` | flushed, face, smiley, emotion, emotion, omg, omg |
| 🌫 | `:fog:` | fog, weather, sky, cold |
| 🌁 | `:foggy:` | foggy, places, building, sky, travel, vacation |
| 🏈 | `:football:` | american, football, america, game, ball, sport, football |
| 👣 | `:footprints:` | footprints |
| 🍴 | `:fork_and_knife:` | fork, and, knife, object, weapon, food |
| 🍽 | `:fork_and_knife_with_plate:`, `:fork_knife_plate:` | fork, and, knife, with, plate, object, food |
| ⛲ | `:fountain:` | fountain, travel, vacation |
| 4⃣ | `:four:` | keycap, digit, four, number, math, symbol |
| 🍀 | `:four_leaf_clover:` | four, leaf, clover, nature, plant, luck, leaf, leaf, sol, sol |
| 🦊 | `:fox_face:`, `:fox:` | fox, face |
| 🖼 | `:frame_with_picture:`, `:frame_photo:` | frame, with, picture, travel, vacation |
| 🆓 | `:free:` | squared, free, symbol |
| 🍤 | `:fried_shrimp:` | fried, shrimp, food |
| 🍟 | `:fries:` | french, fries, america, food |
| 🐸 | `:frog:` | frog, face, wildlife, animal, animal |
| 😦 | `:frowning:` | frowning, face, with, open, mouth, sad, smiley, surprised, emotion, emotion |
| ☹ | `:white_frowning_face:`, `:frowning2:` | white, frowning, face, sad, smiley, emotion, emotion |
| ⛽ | `:fuelpump:` | fuel, pump, object, gas, pump |
| 🌕 | `:full_moon:` | full, moon, symbol, space, sky, moon, moon |
| 🌝 | `:full_moon_with_face:` | full, moon, with, face, space, sky, goodnight, goodnight, moon, moon |
| ⚱ | `:funeral_urn:`, `:urn:` | funeral, urn, object, dead, rip, rip |
| 🎲 | `:game_die:` | game, die, object, game, boys, night, boys, night |
| 🏳🌈 | `:rainbow_flag:`, `:gay_pride_flag:` | gay_pride_flag |
| ⚙ | `:gear:` | gear, object, tool |
| 💎 | `:gem:` | gem, stone, object, gem |
| ♊ | `:gemini:` | gemini, zodiac, symbol |
| 👻 | `:ghost:` | ghost, holidays, halloween, monster |
| 🎁 | `:gift:` | wrapped, present, object, gift, birthday, holidays, christmas, parties, parties |
| 💝 | `:gift_heart:` | heart, with, ribbon, love, symbol, condolence, condolence |
| 👧 | `:girl:` | girl, people, women, baby, diversity, diversity |
| 👧🏻 | `:girl_tone1:` | girl, tone, 1 |
| 👧🏼 | `:girl_tone2:` | girl, tone, 2 |
| 👧🏽 | `:girl_tone3:` | girl, tone, 3 |
| 👧🏾 | `:girl_tone4:` | girl, tone, 4 |
| 👧🏿 | `:girl_tone5:` | girl, tone, 5 |
| 🥛 | `:glass_of_milk:`, `:milk:` | glass, of, milk |
| 🌐 | `:globe_with_meridians:` | globe, with, meridians, symbol, globe, globe |
| 🥅 | `:goal_net:`, `:goal:` | goal, net |
| 🐐 | `:goat:` | goat, animal, animal |
| ⛳ | `:golf:` | flag, in, hole, game, ball, vacation, sport, golf, golf |
| 🏌 | `:golfer:` | golfer, men, game, ball, vacation, sport, golf, golf |
| 🦍 | `:gorilla:` | gorilla |
| 👵 | `:grandma:`, `:older_woman:` | older, woman, people, old, people, diversity, diversity |
| 👵🏻 | `:grandma_tone1:`, `:older_woman_tone1:` | older, woman, tone, 1 |
| 👵🏼 | `:grandma_tone2:`, `:older_woman_tone2:` | older, woman, tone, 2 |
| 👵🏽 | `:grandma_tone3:`, `:older_woman_tone3:` | older, woman, tone, 3 |
| 👵🏾 | `:grandma_tone4:`, `:older_woman_tone4:` | older, woman, tone, 4 |
| 👵🏿 | `:grandma_tone5:`, `:older_woman_tone5:` | older, woman, tone, 5 |
| 🍇 | `:grapes:` | grapes, fruit, food |
| 🍏 | `:green_apple:` | green, apple, fruit, food |
| 📗 | `:green_book:` | green, book, object, office, book |
| 💚 | `:green_heart:` | green, heart, love, symbol |
| 🥗 | `:green_salad:`, `:salad:` | green, salad |
| ❕ | `:grey_exclamation:` | white, exclamation, mark, ornament, symbol, punctuation |
| ❔ | `:grey_question:` | white, question, mark, ornament, symbol, punctuation |
| 😬 | `:grimacing:` | grimacing, face, silly, smiley, emotion, emotion, selfie, selfie |
| 😁 | `:grin:` | grinning, face, with, smiling, eyes, happy, silly, smiley, emotion, emotion, good, good, selfie, selfie |
| 😀 | `:grinning:` | grinning, face, happy, smiley, emotion, emotion |
| 💂 | `:guardsman:` | guardsman, people, hat, men, diversity, diversity, job, job |
| 💂🏻 | `:guardsman_tone1:` | guardsman, tone, 1 |
| 💂🏼 | `:guardsman_tone2:` | guardsman, tone, 2 |
| 💂🏽 | `:guardsman_tone3:` | guardsman, tone, 3 |
| 💂🏾 | `:guardsman_tone4:` | guardsman, tone, 4 |
| 💂🏿 | `:guardsman_tone5:` | guardsman, tone, 5 |
| 🎸 | `:guitar:` | guitar, instruments |
| 🔫 | `:gun:` | pistol, object, weapon, dead, gun, sarcastic, sarcastic |
| 💇 | `:haircut:` | haircut, people, women, diversity, diversity |
| 💇🏻 | `:haircut_tone1:` | haircut, tone, 1 |
| 💇🏼 | `:haircut_tone2:` | haircut, tone, 2 |
| 💇🏽 | `:haircut_tone3:` | haircut, tone, 3 |
| 💇🏾 | `:haircut_tone4:` | haircut, tone, 4 |
| 💇🏿 | `:haircut_tone5:` | haircut, tone, 5 |
| 🍔 | `:hamburger:` | hamburger, america, food |
| 🔨 | `:hammer:` | hammer, object, tool, weapon |
| ⚒ | `:hammer_and_pick:`, `:hammer_pick:` | hammer, and, pick, object, tool, weapon |
| 🛠 | `:hammer_and_wrench:`, `:tools:` | hammer, and, wrench, object, tool |
| 🐹 | `:hamster:` | hamster, face, animal, animal |
| 🖐 | `:raised_hand_with_fingers_splayed:`, `:hand_splayed:` | raised, hand, with, fingers, splayed, body, hands, hi, diversity, diversity |
| 🖐🏻 | `:raised_hand_with_fingers_splayed_tone1:`, `:hand_splayed_tone1:` | raised, hand, with, fingers, splayed, tone, 1 |
| 🖐🏼 | `:raised_hand_with_fingers_splayed_tone2:`, `:hand_splayed_tone2:` | raised, hand, with, fingers, splayed, tone, 2 |
| 🖐🏽 | `:raised_hand_with_fingers_splayed_tone3:`, `:hand_splayed_tone3:` | raised, hand, with, fingers, splayed, tone, 3 |
| 🖐🏾 | `:raised_hand_with_fingers_splayed_tone4:`, `:hand_splayed_tone4:` | raised, hand, with, fingers, splayed, tone, 4 |
| 🖐🏿 | `:raised_hand_with_fingers_splayed_tone5:`, `:hand_splayed_tone5:` | raised, hand, with, fingers, splayed, tone, 5 |
| 👜 | `:handbag:` | handbag, bag, women, fashion, vacation, accessories |
| 🤾 | `:handball:` | handball |
| 🤾🏻 | `:handball_tone1:` | handball, tone, 1 |
| 🤾🏼 | `:handball_tone2:` | handball, tone, 2 |
| 🤾🏽 | `:handball_tone3:` | handball, tone, 3 |
| 🤾🏾 | `:handball_tone4:` | handball, tone, 4 |
| 🤾🏿 | `:handball_tone5:` | handball, tone, 5 |
| 🤝 | `:shaking_hands:`, `:handshake:` | handshake |
| 🤝🏻 | `:shaking_hands_tone1:`, `:handshake_tone1:` | handshake, tone, 1 |
| 🤝🏼 | `:shaking_hands_tone2:`, `:handshake_tone2:` | handshake, tone, 2 |
| 🤝🏽 | `:shaking_hands_tone3:`, `:handshake_tone3:` | handshake, tone, 3 |
| 🤝🏾 | `:shaking_hands_tone4:`, `:handshake_tone4:` | handshake, tone, 4 |
| 🤝🏿 | `:shaking_hands_tone5:`, `:handshake_tone5:` | handshake, tone, 5 |
| 💩 | `:shit:`, `:hankey:`, `:poo:`, `:poop:` | pile, of, poo, bathroom, shit, sol, sol, diarrhea, diarrhea |
| #⃣ | `:hash:` | keycap, number, sign, number, symbol |
| 🐥 | `:hatched_chick:` | front-facing, baby, chick, animal, animal, chicken, chicken |
| 🐣 | `:hatching_chick:` | hatching, chick, animal, animal, chicken, chicken |
| 🎧 | `:headphones:` | headphone, instruments |
| 🙉 | `:hear_no_evil:` | hear-no-evil, monkey, animal, animal |
| ❤ | `:heart:` | heavy, black, heart, love, symbol, parties, parties |
| 💟 | `:heart_decoration:` | heart, decoration, love, symbol |
| ❣ | `:heavy_heart_exclamation_mark_ornament:`, `:heart_exclamation:` | heavy, heart, exclamation, mark, ornament, love, symbol |
| 😍 | `:heart_eyes:` | smiling, face, with, heart-shaped, eyes, happy, smiley, love, sex, heart, eyes, emotion, emotion, beautiful, beautiful |
| 😻 | `:heart_eyes_cat:` | smiling, cat, face, with, heart-shaped, eyes, heart, eyes, cat, cat, animal, animal, beautiful, beautiful |
| 💓 | `:heartbeat:` | beating, heart, love, symbol |
| 💗 | `:heartpulse:` | growing, heart, love, symbol |
| ♥ | `:hearts:` | black, heart, suit, love, symbol, game |
| ✔ | `:heavy_check_mark:` | heavy, check, mark, symbol |
| ➗ | `:heavy_division_sign:` | heavy, division, sign, math, symbol |
| 💲 | `:heavy_dollar_sign:` | heavy, dollar, sign, math, symbol, money, money |
| ➖ | `:heavy_minus_sign:` | heavy, minus, sign, math, symbol |
| ✖ | `:heavy_multiplication_x:` | heavy, multiplication, x, math, symbol |
| ➕ | `:heavy_plus_sign:` | heavy, plus, sign, math, symbol |
| 🚁 | `:helicopter:` | helicopter, transportation, plane, travel, fly, fly |
| ⛑ | `:helmet_with_white_cross:`, `:helmet_with_cross:` | helmet, with, white, cross, object, hat, accessories, job, job |
| 🌿 | `:herb:` | herb, nature, plant, leaf, leaf |
| 🌺 | `:hibiscus:` | hibiscus, nature, flower, plant, tropical |
| 🔆 | `:high_brightness:` | high, brightness, symbol, symbol, sun |
| 👠 | `:high_heel:` | high-heeled, shoe, women, fashion, shoe, sexy, accessories, girls, night, girls, night |
| 🏒 | `:hockey:` | ice, hockey, stick, and, puck, game, sport, hockey |
| 🕳 | `:hole:` | hole, object |
| 🏘 | `:house_buildings:`, `:homes:` | house, buildings, places, building, house |
| 🍯 | `:honey_pot:` | honey, pot, food, vagina |
| 🐴 | `:horse:` | horse, face, wildlife, animal, animal |
| 🏇 | `:horse_racing:` | horse, racing, men, sport, horse, racing |
| 🏇🏻 | `:horse_racing_tone1:` | horse, racing, tone, 1 |
| 🏇🏼 | `:horse_racing_tone2:` | horse, racing, tone, 2 |
| 🏇🏽 | `:horse_racing_tone3:` | horse, racing, tone, 3 |
| 🏇🏾 | `:horse_racing_tone4:` | horse, racing, tone, 4 |
| 🏇🏿 | `:horse_racing_tone5:` | horse, racing, tone, 5 |
| 🏥 | `:hospital:` | hospital, places, building, health, 911, 911 |
| 🌭 | `:hot_dog:`, `:hotdog:` | hot, dog, america, food |
| 🌶 | `:hot_pepper:` | hot, pepper, vegetables, food |
| 🏨 | `:hotel:` | hotel, places, building, vacation |
| ♨ | `:hotsprings:` | hot, springs, symbol |
| ⌛ | `:hourglass:` | hourglass, object, time |
| ⏳ | `:hourglass_flowing_sand:` | hourglass, with, flowing, sand, object, time |
| 🏠 | `:house:` | house, building, places, building, house |
| 🏡 | `:house_with_garden:` | house, with, garden, places, building, house |
| 🤗 | `:hugging_face:`, `:hugging:` | hugging, face, smiley, hug, thank, you |
| 😯 | `:hushed:` | hushed, face, smiley, surprised, wow, wow |
| 🍨 | `:ice_cream:` | ice, cream, food |
| ⛸ | `:ice_skate:` | ice, skate, cold, sport, ice, skating |
| 🍦 | `:icecream:` | soft, ice, cream, food |
| 🆔 | `:id:` | squared, id, symbol |
| 🉐 | `:ideograph_advantage:` | circled, ideograph, advantage, japan, symbol |
| 👿 | `:imp:` | imp, smiley, monster, devil, devil, wth, wth |
| 📥 | `:inbox_tray:` | inbox, tray, work, office |
| 📨 | `:incoming_envelope:` | incoming, envelope, object |
| 💁 | `:information_desk_person:` | information, desk, person, people, women, diversity, diversity |
| 💁🏻 | `:information_desk_person_tone1:` | information, desk, person, tone, 1 |
| 💁🏼 | `:information_desk_person_tone2:` | information, desk, person, tone, 2 |
| 💁🏽 | `:information_desk_person_tone3:` | information, desk, person, tone, 3 |
| 💁🏾 | `:information_desk_person_tone4:` | information, desk, person, tone, 4 |
| 💁🏿 | `:information_desk_person_tone5:` | information, desk, person, tone, 5 |
| ℹ | `:information_source:` | information, source, symbol |
| 😇 | `:innocent:` | smiling, face, with, halo, smiley, emotion, emotion |
| ⁉ | `:interrobang:` | exclamation, question, mark, symbol, punctuation |
| 📱 | `:iphone:` | mobile, phone, electronics, phone, selfie, selfie |
| 🏮 | `:izakaya_lantern:` | izakaya, lantern, object, japan |
| 🎃 | `:jack_o_lantern:` | jack-o-lantern, holidays, halloween |
| 🗾 | `:japan:` | silhouette, of, japan, places, travel, map, vacation, tropical |
| 🏯 | `:japanese_castle:` | japanese, castle, places, building, travel, vacation |
| 👺 | `:japanese_goblin:` | japanese, goblin, angry, monster |
| 👹 | `:japanese_ogre:` | japanese, ogre, monster |
| 👖 | `:jeans:` | jeans, fashion |
| 😂 | `:joy:` | face, with, tears, of, joy, happy, silly, smiley, cry, laugh, laugh, emotion, emotion, sarcastic, sarcastic |
| 😹 | `:joy_cat:` | cat, face, with, tears, of, joy, happy, silly, cry, laugh, laugh, cat, cat, animal, animal, sarcastic, sarcastic |
| 🕹 | `:joystick:` | joystick, electronics, game, boys, night, boys, night |
| 🤹 | `:juggler:`, `:juggling:` | juggling |
| 🤹🏻 | `:juggler_tone1:`, `:juggling_tone1:` | juggling, tone, 1 |
| 🤹🏼 | `:juggler_tone2:`, `:juggling_tone2:` | juggling, tone, 2 |
| 🤹🏽 | `:juggler_tone3:`, `:juggling_tone3:` | juggling, tone, 3 |
| 🤹🏾 | `:juggler_tone4:`, `:juggling_tone4:` | juggling, tone, 4 |
| 🤹🏿 | `:juggler_tone5:`, `:juggling_tone5:` | juggling, tone, 5 |
| 🕋 | `:kaaba:` | kaaba, places, religion, building, condolence, condolence |
| 🥋 | `:karate_uniform:`, `:martial_arts_uniform:` | martial, arts, uniform |
| 🔑 | `:key:` | key, object, lock |
| 🗝 | `:old_key:`, `:key2:` | old, key, object, lock |
| ⌨ | `:keyboard:` | keyboard, electronics, work, office |
| 🔟 | `:keycap_ten:` | keycap, ten, number, math, symbol |
| 👘 | `:kimono:` | kimono, fashion |
| 💋 | `:kiss:` | kiss, mark, women, love, sexy, lip, beautiful, beautiful, girls, night, girls, night |
| 😗 | `:kissing:` | kissing, face, smiley, sexy |
| 😽 | `:kissing_cat:` | kissing, cat, face, with, closed, eyes, cat, cat, animal, animal |
| 😚 | `:kissing_closed_eyes:` | kissing, face, with, closed, eyes, smiley, sexy |
| 😘 | `:kissing_heart:` | face, throwing, a, kiss, smiley, love, sexy |
| 😙 | `:kissing_smiling_eyes:` | kissing, face, with, smiling, eyes, smiley, sexy |
| 🥝 | `:kiwifruit:`, `:kiwi:` | kiwifruit |
| 🔪 | `:knife:` | hocho, object, weapon |
| 🐨 | `:koala:` | koala, wildlife, animal, animal |
| 🈁 | `:koko:` | squared, katakana, koko, symbol |
| 🏷 | `:label:` | label, object |
| 🔵 | `:large_blue_circle:` | large, blue, circle, shapes, symbol, circle, circle |
| 🔷 | `:large_blue_diamond:` | large, blue, diamond, shapes, symbol |
| 🔶 | `:large_orange_diamond:` | large, orange, diamond, shapes, symbol |
| 🌗 | `:last_quarter_moon:` | last, quarter, moon, symbol, space, sky, moon, moon |
| 🌜 | `:last_quarter_moon_with_face:` | last, quarter, moon, with, face, space, sky, moon, moon |
| 😆 | `:satisfied:`, `:laughing:` | smiling, face, with, open, mouth, and, tightly-closed, eyes, happy, smiley, laugh, laugh, emotion, emotion |
| 🍃 | `:leaves:` | leaf, fluttering, in, wind, nature, plant, leaf, leaf |
| 📒 | `:ledger:` | ledger, object, office, write |
| 🤛 | `:left_fist:`, `:left_facing_fist:` | left-facing, fist |
| 🤛🏻 | `:left_fist_tone1:`, `:left_facing_fist_tone1:` | left, facing, fist, tone, 1 |
| 🤛🏼 | `:left_fist_tone2:`, `:left_facing_fist_tone2:` | left, facing, fist, tone, 2 |
| 🤛🏽 | `:left_fist_tone3:`, `:left_facing_fist_tone3:` | left, facing, fist, tone, 3 |
| 🤛🏾 | `:left_fist_tone4:`, `:left_facing_fist_tone4:` | left, facing, fist, tone, 4 |
| 🤛🏿 | `:left_fist_tone5:`, `:left_facing_fist_tone5:` | left, facing, fist, tone, 5 |
| 🛅 | `:left_luggage:` | left, luggage, symbol |
| ↔ | `:left_right_arrow:` | left, right, arrow, arrow, symbol |
| 🗨 | `:left_speech_bubble:`, `:speech_left:` | left, speech, bubble |
| ↩ | `:leftwards_arrow_with_hook:` | leftwards, arrow, with, hook, arrow, symbol |
| 🍋 | `:lemon:` | lemon, fruit, food |
| ♌ | `:leo:` | leo, zodiac, symbol |
| 🐆 | `:leopard:` | leopard, wildlife, roar, animal, animal |
| 🎚 | `:level_slider:` | level, slider |
| 🕴 | `:man_in_business_suit_levitating:`, `:levitate:` | man, in, business, suit, levitating, men, job, job |
| 🤥 | `:liar:`, `:lying_face:` | lying, face |
| ♎ | `:libra:` | libra, zodiac, symbol |
| 🏋 | `:weight_lifter:`, `:lifter:` | weight, lifter, men, workout, flex, sport, weight, lifting, win, win, diversity, diversity |
| 🏋🏻 | `:weight_lifter_tone1:`, `:lifter_tone1:` | weight, lifter, tone, 1 |
| 🏋🏼 | `:weight_lifter_tone2:`, `:lifter_tone2:` | weight, lifter, tone, 2 |
| 🏋🏽 | `:weight_lifter_tone3:`, `:lifter_tone3:` | weight, lifter, tone, 3 |
| 🏋🏾 | `:weight_lifter_tone4:`, `:lifter_tone4:` | weight, lifter, tone, 4 |
| 🏋🏿 | `:weight_lifter_tone5:`, `:lifter_tone5:` | weight, lifter, tone, 5 |
| 🚈 | `:light_rail:` | light, rail, transportation, travel, train |
| 🔗 | `:link:` | link, symbol, symbol, office |
| 🖇 | `:linked_paperclips:`, `:paperclips:` | linked, paperclips, object, work, office |
| 🦁 | `:lion:`, `:lion_face:` | lion, face, wildlife, roar, cat, cat, animal, animal |
| 👄 | `:lips:` | mouth, women, body, sexy, lip |
| 💄 | `:lipstick:` | lipstick, object, women, fashion, sexy, lip |
| 🦎 | `:lizard:` | lizard |
| 🔒 | `:lock:` | lock, object, lock |
| 🔏 | `:lock_with_ink_pen:` | lock, with, ink, pen, object, lock |
| 🍭 | `:lollipop:` | lollipop, food, halloween |
| ➿ | `:loop:` | double, curly, loop, symbol |
| 🔊 | `:loud_sound:` | speaker, with, three, sound, waves, alarm, symbol |
| 📢 | `:loudspeaker:` | public, address, loudspeaker, object, alarm, symbol |
| 🏩 | `:love_hotel:` | love, hotel, places, building, love |
| 💌 | `:love_letter:` | love, letter, object |
| 🔅 | `:low_brightness:` | low, brightness, symbol, symbol, sun |
| 🖊 | `:lower_left_ballpoint_pen:`, `:pen_ballpoint:` | lower, left, ballpoint, pen, object, office, write |
| 🖋 | `:lower_left_fountain_pen:`, `:pen_fountain:` | lower, left, fountain, pen, object, office, write |
| 🖌 | `:lower_left_paintbrush:`, `:paintbrush:` | lower, left, paintbrush, object, office, write |
| Ⓜ | `:m:` | circled, latin, capital, letter, m, symbol |
| 🔍 | `:mag:` | left-pointing, magnifying, glass, object |
| 🔎 | `:mag_right:` | right-pointing, magnifying, glass, object |
| 🀄 | `:mahjong:` | mahjong, tile, red, dragon, object, symbol, game |
| 📫 | `:mailbox:` | closed, mailbox, with, raised, flag, object |
| 📪 | `:mailbox_closed:` | closed, mailbox, with, lowered, flag, object, office |
| 📬 | `:mailbox_with_mail:` | open, mailbox, with, raised, flag, object |
| 📭 | `:mailbox_with_no_mail:` | open, mailbox, with, lowered, flag, object |
| 🕺 | `:male_dancer:`, `:man_dancing:` | man, dancing |
| 🕺🏻 | `:male_dancer_tone1:`, `:man_dancing_tone1:` | man, dancing, tone, 1 |
| 🕺🏼 | `:male_dancer_tone2:`, `:man_dancing_tone2:` | man, dancing, tone, 2 |
| 🕺🏽 | `:male_dancer_tone3:`, `:man_dancing_tone3:` | man, dancing, tone, 3 |
| 🕺🏾 | `:male_dancer_tone4:`, `:man_dancing_tone4:` | man, dancing, tone, 4 |
| 🕺🏿 | `:male_dancer_tone5:`, `:man_dancing_tone5:` | man, dancing, tone, 5 |
| 👨 | `:man:` | man, people, men, sex, diversity, diversity, selfie, selfie, boys, night, boys, night |
| 🤵 | `:man_in_tuxedo:` | man, in, tuxedo |
| 🤵🏻 | `:tuxedo_tone1:`, `:man_in_tuxedo_tone1:` | man, in, tuxedo, tone, 1 |
| 🤵🏼 | `:tuxedo_tone2:`, `:man_in_tuxedo_tone2:` | man, in, tuxedo, tone, 2 |
| 🤵🏽 | `:tuxedo_tone3:`, `:man_in_tuxedo_tone3:` | man, in, tuxedo, tone, 3 |
| 🤵🏾 | `:tuxedo_tone4:`, `:man_in_tuxedo_tone4:` | man, in, tuxedo, tone, 4 |
| 🤵🏿 | `:tuxedo_tone5:`, `:man_in_tuxedo_tone5:` | man, in, tuxedo, tone, 5 |
| 👨🏻 | `:man_tone1:` | man, tone, 1 |
| 👨🏼 | `:man_tone2:` | man, tone, 2 |
| 👨🏽 | `:man_tone3:` | man, tone, 3 |
| 👨🏾 | `:man_tone4:` | man, tone, 4 |
| 👨🏿 | `:man_tone5:` | man, tone, 5 |
| 👲 | `:man_with_gua_pi_mao:` | man, with, gua, pi, mao, people, hat, men, diversity, diversity |
| 👲🏻 | `:man_with_gua_pi_mao_tone1:` | man, with, gua, pi, mao, tone, 1 |
| 👲🏼 | `:man_with_gua_pi_mao_tone2:` | man, with, gua, pi, mao, tone, 2 |
| 👲🏽 | `:man_with_gua_pi_mao_tone3:` | man, with, gua, pi, mao, tone, 3 |
| 👲🏾 | `:man_with_gua_pi_mao_tone4:` | man, with, gua, pi, mao, tone, 4 |
| 👲🏿 | `:man_with_gua_pi_mao_tone5:` | man, with, gua, pi, mao, tone, 5 |
| 👳 | `:man_with_turban:` | man, with, turban, people, hat, diversity, diversity |
| 👳🏻 | `:man_with_turban_tone1:` | man, with, turban, tone, 1 |
| 👳🏼 | `:man_with_turban_tone2:` | man, with, turban, tone, 2 |
| 👳🏽 | `:man_with_turban_tone3:` | man, with, turban, tone, 3 |
| 👳🏾 | `:man_with_turban_tone4:` | man, with, turban, tone, 4 |
| 👳🏿 | `:man_with_turban_tone5:` | man, with, turban, tone, 5 |
| 👞 | `:mans_shoe:` | mans, shoe, fashion, shoe, accessories |
| 🗺 | `:world_map:`, `:map:` | world, map, travel, map, vacation |
| 🍁 | `:maple_leaf:` | maple, leaf, nature, plant, leaf, leaf |
| 😷 | `:mask:` | face, with, medical, mask, smiley, dead, health, sick |
| 💆 | `:massage:` | face, massage, people, women, diversity, diversity |
| 💆🏻 | `:massage_tone1:` | face, massage, tone, 1 |
| 💆🏼 | `:massage_tone2:` | face, massage, tone, 2 |
| 💆🏽 | `:massage_tone3:` | face, massage, tone, 3 |
| 💆🏾 | `:massage_tone4:` | face, massage, tone, 4 |
| 💆🏿 | `:massage_tone5:` | face, massage, tone, 5 |
| 🍖 | `:meat_on_bone:` | meat, on, bone, food |
| 🏅 | `:sports_medal:`, `:medal:` | sports, medal, object, award, sport, win, win, perfect, perfect |
| 📣 | `:mega:` | cheering, megaphone, object, sport |
| 🍈 | `:melon:` | melon, fruit, boobs, food |
| 🕎 | `:menorah:` | menorah, with, nine, branches, religion, object, jew, symbol, holidays |
| 🚹 | `:mens:` | mens, symbol, symbol |
| 🤘 | `:sign_of_the_horns:`, `:metal:` | sign, of, the, horns, body, hands, hi, diversity, diversity, boys, night, boys, night, parties, parties |
| 🤘🏻 | `:sign_of_the_horns_tone1:`, `:metal_tone1:` | sign, of, the, horns, tone, 1 |
| 🤘🏼 | `:sign_of_the_horns_tone2:`, `:metal_tone2:` | sign, of, the, horns, tone, 2 |
| 🤘🏽 | `:sign_of_the_horns_tone3:`, `:metal_tone3:` | sign, of, the, horns, tone, 3 |
| 🤘🏾 | `:sign_of_the_horns_tone4:`, `:metal_tone4:` | sign, of, the, horns, tone, 4 |
| 🤘🏿 | `:sign_of_the_horns_tone5:`, `:metal_tone5:` | sign, of, the, horns, tone, 5 |
| 🚇 | `:metro:` | metro, transportation, travel, train |
| 🎤 | `:microphone:` | microphone, instruments |
| 🎙 | `:studio_microphone:`, `:microphone2:` | studio, microphone, electronics, object |
| 🔬 | `:microscope:` | microscope, object, science |
| 🖕 | `:reversed_hand_with_middle_finger_extended:`, `:middle_finger:` | reversed, hand, with, middle, finger, extended, body, hands, middle, finger, diversity, diversity |
| 🖕🏻 | `:reversed_hand_with_middle_finger_extended_tone1:`, `:middle_finger_tone1:` | reversed, hand, with, middle, finger, extended, tone, 1 |
| 🖕🏼 | `:reversed_hand_with_middle_finger_extended_tone2:`, `:middle_finger_tone2:` | reversed, hand, with, middle, finger, extended, tone, 2 |
| 🖕🏽 | `:reversed_hand_with_middle_finger_extended_tone3:`, `:middle_finger_tone3:` | reversed, hand, with, middle, finger, extended, tone, 3 |
| 🖕🏾 | `:reversed_hand_with_middle_finger_extended_tone4:`, `:middle_finger_tone4:` | reversed, hand, with, middle, finger, extended, tone, 4 |
| 🖕🏿 | `:reversed_hand_with_middle_finger_extended_tone5:`, `:middle_finger_tone5:` | reversed, hand, with, middle, finger, extended, tone, 5 |
| 🎖 | `:military_medal:` | military, medal, object, award, win, win |
| 🌌 | `:milky_way:` | milky, way, places, space, sky, travel, vacation |
| 🚐 | `:minibus:` | minibus, transportation, bus |
| 💽 | `:minidisc:` | minidisc, electronics |
| 📴 | `:mobile_phone_off:` | mobile, phone, off, symbol |
| 🤑 | `:money_mouth_face:`, `:money_mouth:` | money-mouth, face, smiley, win, win, money, money, emotion, emotion, boys, night, boys, night |
| 💸 | `:money_with_wings:` | money, with, wings, money, money, boys, night, boys, night |
| 💰 | `:moneybag:` | money, bag, bag, award, money, money |
| 🐒 | `:monkey:` | monkey, wildlife, animal, animal |
| 🐵 | `:monkey_face:` | monkey, face, animal, animal |
| 🚝 | `:monorail:` | monorail, transportation, travel, train, vacation |
| 🎓 | `:mortar_board:` | graduation, cap, hat, office, accessories |
| 🕌 | `:mosque:` | mosque, places, religion, building, vacation, condolence, condolence |
| 🤶 | `:mother_christmas:`, `:mrs_claus:` | mother, christmas |
| 🤶🏻 | `:mother_christmas_tone1:`, `:mrs_claus_tone1:` | mother, christmas, tone, 1 |
| 🤶🏼 | `:mother_christmas_tone2:`, `:mrs_claus_tone2:` | mother, christmas, tone, 2 |
| 🤶🏽 | `:mother_christmas_tone3:`, `:mrs_claus_tone3:` | mother, christmas, tone, 3 |
| 🤶🏾 | `:mother_christmas_tone4:`, `:mrs_claus_tone4:` | mother, christmas, tone, 4 |
| 🤶🏿 | `:mother_christmas_tone5:`, `:mrs_claus_tone5:` | mother, christmas, tone, 5 |
| 🛵 | `:motorbike:`, `:motor_scooter:` | motor, scooter, moped |
| 🛥 | `:motorboat:` | motorboat, transportation, travel, boat |
| 🏍 | `:racing_motorcycle:`, `:motorcycle:` | racing, motorcycle, transportation, travel, bike |
| 🛣 | `:motorway:` | motorway, travel, vacation, camp |
| 🗻 | `:mount_fuji:` | mount, fuji, places, travel, vacation, cold, camp |
| ⛰ | `:mountain:` | mountain, places, travel, vacation, camp |
| 🚵 | `:mountain_bicyclist:` | mountain, bicyclist, men, sport, bike, diversity, diversity |
| 🚵🏻 | `:mountain_bicyclist_tone1:` | mountain, bicyclist, tone, 1 |
| 🚵🏼 | `:mountain_bicyclist_tone2:` | mountain, bicyclist, tone, 2 |
| 🚵🏽 | `:mountain_bicyclist_tone3:` | mountain, bicyclist, tone, 3 |
| 🚵🏾 | `:mountain_bicyclist_tone4:` | mountain, bicyclist, tone, 4 |
| 🚵🏿 | `:mountain_bicyclist_tone5:` | mountain, bicyclist, tone, 5 |
| 🚠 | `:mountain_cableway:` | mountain, cableway, transportation, travel, train |
| 🚞 | `:mountain_railway:` | mountain, railway, transportation, travel, train |
| 🏔 | `:snow_capped_mountain:`, `:mountain_snow:` | snow, capped, mountain, places, travel, vacation, cold, camp |
| 🐭 | `:mouse:` | mouse, face, animal, animal |
| 🐁 | `:mouse2:` | mouse, animal, animal |
| 🖱 | `:three_button_mouse:`, `:mouse_three_button:` | three, button, mouse, electronics, work, game, office |
| 🎥 | `:movie_camera:` | movie, camera, object, camera, movie |
| 🗿 | `:moyai:` | moyai, travel, vacation |
| 💪 | `:muscle:` | flexed, biceps, body, hands, workout, flex, win, win, diversity, diversity, feminist, feminist, boys, night, boys, night |
| 💪🏻 | `:muscle_tone1:` | flexed, biceps, tone, 1 |
| 💪🏼 | `:muscle_tone2:` | flexed, biceps, tone, 2 |
| 💪🏽 | `:muscle_tone3:` | flexed, biceps, tone, 3 |
| 💪🏾 | `:muscle_tone4:` | flexed, biceps, tone, 4 |
| 💪🏿 | `:muscle_tone5:` | flexed, biceps, tone, 5 |
| 🍄 | `:mushroom:` | mushroom, nature, plant, drugs, drugs |
| 🎹 | `:musical_keyboard:` | musical, keyboard, instruments |
| 🎵 | `:musical_note:` | musical, note, instruments, symbol |
| 🎼 | `:musical_score:` | musical, score, instruments |
| 🔇 | `:mute:` | speaker, with, cancellation, stroke, alarm, symbol |
| 💅 | `:nail_care:` | nail, polish, women, body, hands, nailpolish, diversity, diversity, girls, night, girls, night |
| 💅🏻 | `:nail_care_tone1:` | nail, polish, tone, 1 |
| 💅🏼 | `:nail_care_tone2:` | nail, polish, tone, 2 |
| 💅🏽 | `:nail_care_tone3:` | nail, polish, tone, 3 |
| 💅🏾 | `:nail_care_tone4:` | nail, polish, tone, 4 |
| 💅🏿 | `:nail_care_tone5:` | nail, polish, tone, 5 |
| 📛 | `:name_badge:` | name, badge, work |
| 🏞 | `:national_park:`, `:park:` | national, park, travel, vacation, park, camp |
| 🤢 | `:sick:`, `:nauseated_face:` | nauseated, face |
| 👔 | `:necktie:` | necktie, fashion |
| ❎ | `:negative_squared_cross_mark:` | negative, squared, cross, mark, symbol |
| 🤓 | `:nerd_face:`, `:nerd:` | nerd, face, smiley, glasses |
| 😐 | `:neutral_face:` | neutral, face, mad, smiley, shrug, neutral, emotion, emotion |
| 🆕 | `:new:` | squared, new, symbol |
| 🌑 | `:new_moon:` | new, moon, symbol, space, sky, moon, moon |
| 🌚 | `:new_moon_with_face:` | new, moon, with, face, space, sky, goodnight, goodnight, moon, moon |
| 📰 | `:newspaper:` | newspaper, office, write |
| 🗞 | `:rolled_up_newspaper:`, `:newspaper2:` | rolled-up, newspaper, office, write |
| ⏭ | `:next_track:`, `:track_next:` | black, right-pointing, double, triangle, with, vertical, bar, arrow, symbol |
| 🆖 | `:ng:` | squared, ng, symbol |
| 🌃 | `:night_with_stars:` | night, with, stars, places, building, sky, vacation, goodnight, goodnight |
| 9⃣ | `:nine:` | keycap, digit, nine, number, math, symbol |
| 🔕 | `:no_bell:` | bell, with, cancellation, stroke, alarm, symbol |
| 🚳 | `:no_bicycles:` | no, bicycles, symbol |
| ⛔ | `:no_entry:` | no, entry, symbol, circle, circle |
| 🚫 | `:no_entry_sign:` | no, entry, sign, symbol, circle, circle |
| 🙅 | `:no_good:` | face, with, no, good, gesture, people, women, diversity, diversity, girls, night, girls, night |
| 🙅🏻 | `:no_good_tone1:` | face, with, no, good, gesture, tone, 1 |
| 🙅🏼 | `:no_good_tone2:` | face, with, no, good, gesture, tone, 2 |
| 🙅🏽 | `:no_good_tone3:` | face, with, no, good, gesture, tone, 3 |
| 🙅🏾 | `:no_good_tone4:` | face, with, no, good, gesture, tone, 4 |
| 🙅🏿 | `:no_good_tone5:` | face, with, no, good, gesture, tone, 5 |
| 📵 | `:no_mobile_phones:` | no, mobile, phones, symbol, phone |
| 😶 | `:no_mouth:` | face, without, mouth, mad, smiley, neutral, emotion, emotion |
| 🚷 | `:no_pedestrians:` | no, pedestrians, symbol |
| 🚭 | `:no_smoking:` | no, smoking, symbol, symbol, smoking, smoking |
| 🚱 | `:non-potable_water:` | non-potable, water, symbol, symbol |
| 👃 | `:nose:` | nose, body, diversity, diversity |
| 👃🏻 | `:nose_tone1:` | nose, tone, 1 |
| 👃🏼 | `:nose_tone2:` | nose, tone, 2 |
| 👃🏽 | `:nose_tone3:` | nose, tone, 3 |
| 👃🏾 | `:nose_tone4:` | nose, tone, 4 |
| 👃🏿 | `:nose_tone5:` | nose, tone, 5 |
| 📓 | `:notebook:` | notebook, object, office, write |
| 📔 | `:notebook_with_decorative_cover:` | notebook, with, decorative, cover, object, office, write |
| 🗒 | `:spiral_note_pad:`, `:notepad_spiral:` | spiral, note, pad, work, office, write |
| 🎶 | `:notes:` | multiple, musical, notes, instruments, symbol |
| 🔩 | `:nut_and_bolt:` | nut, and, bolt, object, tool, nutcase, nutcase |
| ⭕ | `:o:` | heavy, large, circle, symbol, circle, circle |
| 🅾 | `:o2:` | negative, squared, latin, capital, letter, o, symbol |
| 🌊 | `:ocean:` | water, wave, weather, boat, tropical, swim |
| 🛑 | `:stop_sign:`, `:octagonal_sign:` | octagonal, sign |
| 🐙 | `:octopus:` | octopus, wildlife, animal, animal |
| 🍢 | `:oden:` | oden, food |
| 🏢 | `:office:` | office, building, places, building, work |
| 🛢 | `:oil_drum:`, `:oil:` | oil, drum, object |
| 🆗 | `:ok:` | squared, ok, symbol |
| 👌 | `:ok_hand:` | ok, hand, sign, body, hands, hi, diversity, diversity, perfect, perfect, good, good, beautiful, beautiful |
| 👌🏻 | `:ok_hand_tone1:` | ok, hand, sign, tone, 1 |
| 👌🏼 | `:ok_hand_tone2:` | ok, hand, sign, tone, 2 |
| 👌🏽 | `:ok_hand_tone3:` | ok, hand, sign, tone, 3 |
| 👌🏾 | `:ok_hand_tone4:` | ok, hand, sign, tone, 4 |
| 👌🏿 | `:ok_hand_tone5:` | ok, hand, sign, tone, 5 |
| 🙆 | `:ok_woman:` | face, with, ok, gesture, people, women, diversity, diversity |
| 🙆🏻 | `:ok_woman_tone1:` | face, with, ok, gesture, tone1 |
| 🙆🏼 | `:ok_woman_tone2:` | face, with, ok, gesture, tone2 |
| 🙆🏽 | `:ok_woman_tone3:` | face, with, ok, gesture, tone3 |
| 🙆🏾 | `:ok_woman_tone4:` | face, with, ok, gesture, tone4 |
| 🙆🏿 | `:ok_woman_tone5:` | face, with, ok, gesture, tone5 |
| 👴 | `:older_man:` | older, man, people, men, old, people, diversity, diversity |
| 👴🏻 | `:older_man_tone1:` | older, man, tone, 1 |
| 👴🏼 | `:older_man_tone2:` | older, man, tone, 2 |
| 👴🏽 | `:older_man_tone3:` | older, man, tone, 3 |
| 👴🏾 | `:older_man_tone4:` | older, man, tone, 4 |
| 👴🏿 | `:older_man_tone5:` | older, man, tone, 5 |
| 🕉 | `:om_symbol:` | om, symbol, religion, symbol |
| 🔛 | `:on:` | on, with, exclamation, mark, with, left, right, arrow, abo, arrow, symbol |
| 🚘 | `:oncoming_automobile:` | oncoming, automobile, transportation, car, travel |
| 🚍 | `:oncoming_bus:` | oncoming, bus, transportation, bus, travel |
| 🚔 | `:oncoming_police_car:` | oncoming, police, car, transportation, car, police, police, 911, 911 |
| 🚖 | `:oncoming_taxi:` | oncoming, taxi, transportation, car, travel |
| 1⃣ | `:one:` | keycap, digit, one, number, math, symbol |
| 📂 | `:open_file_folder:` | open, file, folder, work, office |
| 👐 | `:open_hands:` | open, hands, sign, body, hands, diversity, diversity, condolence, condolence |
| 👐🏻 | `:open_hands_tone1:` | open, hands, sign, tone, 1 |
| 👐🏼 | `:open_hands_tone2:` | open, hands, sign, tone, 2 |
| 👐🏽 | `:open_hands_tone3:` | open, hands, sign, tone, 3 |
| 👐🏾 | `:open_hands_tone4:` | open, hands, sign, tone, 4 |
| 👐🏿 | `:open_hands_tone5:` | open, hands, sign, tone, 5 |
| 😮 | `:open_mouth:` | face, with, open, mouth, smiley, surprised, wow, wow, emotion, emotion |
| ⛎ | `:ophiuchus:` | ophiuchus, symbol |
| 📙 | `:orange_book:` | orange, book, object, office, write, book |
| ☦ | `:orthodox_cross:` | orthodox, cross, religion, symbol |
| 📤 | `:outbox_tray:` | outbox, tray, work, office |
| 🦉 | `:owl:` | owl |
| 🐂 | `:ox:` | ox, animal, animal |
| 📦 | `:package:` | package, object, gift, office |
| 🥘 | `:paella:`, `:shallow_pan_of_food:` | shallow, pan, of, food, pan, of, food |
| 📄 | `:page_facing_up:` | page, facing, up, work, office, write |
| 📃 | `:page_with_curl:` | page, with, curl, office, write |
| 📟 | `:pager:` | pager, electronics, work |
| 🌴 | `:palm_tree:` | palm, tree, nature, plant, tropical, trees, trees |
| 🥞 | `:pancakes:` | pancakes |
| 🐼 | `:panda_face:` | panda, face, wildlife, roar, animal, animal |
| 📎 | `:paperclip:` | paperclip, object, work, office |
| 🅿 | `:parking:` | negative, squared, latin, capital, letter, p, symbol |
| 〽 | `:part_alternation_mark:` | part, alternation, mark, symbol |
| ⛅ | `:partly_sunny:` | sun, behind, cloud, weather, sky, cloud, sun |
| 🛂 | `:passport_control:` | passport, control, symbol |
| ☮ | `:peace_symbol:`, `:peace:` | peace, symbol, symbol, peace, peace, drugs, drugs |
| 🍑 | `:peach:` | peach, fruit, butt, food |
| 🥜 | `:shelled_peanut:`, `:peanuts:` | peanuts |
| 🍐 | `:pear:` | pear, fruit, food |
| 📝 | `:pencil:` | memo, work, office, write |
| ✏ | `:pencil2:` | pencil, object, office, write |
| 🐧 | `:penguin:` | penguin, wildlife, animal, animal |
| 😔 | `:pensive:` | pensive, face, sad, smiley, emotion, emotion, rip, rip |
| 🎭 | `:performing_arts:` | performing, arts, theatre, movie |
| 😣 | `:persevere:` | persevering, face, sad, smiley, angry, emotion, emotion |
| 🙍 | `:person_frowning:` | person, frowning, people, women, diversity, diversity |
| 🙍🏻 | `:person_frowning_tone1:` | person, frowning, tone, 1 |
| 🙍🏼 | `:person_frowning_tone2:` | person, frowning, tone, 2 |
| 🙍🏽 | `:person_frowning_tone3:` | person, frowning, tone, 3 |
| 🙍🏾 | `:person_frowning_tone4:` | person, frowning, tone, 4 |
| 🙍🏿 | `:person_frowning_tone5:` | person, frowning, tone, 5 |
| 👱 | `:person_with_blond_hair:` | person, with, blond, hair, people, men, diversity, diversity |
| 👱🏻 | `:person_with_blond_hair_tone1:` | person, with, blond, hair, tone, 1 |
| 👱🏼 | `:person_with_blond_hair_tone2:` | person, with, blond, hair, tone, 2 |
| 👱🏽 | `:person_with_blond_hair_tone3:` | person, with, blond, hair, tone, 3 |
| 👱🏾 | `:person_with_blond_hair_tone4:` | person, with, blond, hair, tone, 4 |
| 👱🏿 | `:person_with_blond_hair_tone5:` | person, with, blond, hair, tone, 5 |
| 🙎 | `:person_with_pouting_face:` | person, with, pouting, face, people, women, diversity, diversity |
| 🙎🏻 | `:person_with_pouting_face_tone1:` | person, with, pouting, face, tone1 |
| 🙎🏼 | `:person_with_pouting_face_tone2:` | person, with, pouting, face, tone2 |
| 🙎🏽 | `:person_with_pouting_face_tone3:` | person, with, pouting, face, tone3 |
| 🙎🏾 | `:person_with_pouting_face_tone4:` | person, with, pouting, face, tone4 |
| 🙎🏿 | `:person_with_pouting_face_tone5:` | person, with, pouting, face, tone5 |
| ⛏ | `:pick:` | pick, object, tool, weapon |
| 🐷 | `:pig:` | pig, face, animal, animal |
| 🐖 | `:pig2:` | pig, animal, animal |
| 🐽 | `:pig_nose:` | pig, nose, animal, animal |
| 💊 | `:pill:` | pill, object, health, drugs, drugs |
| 🍍 | `:pineapple:` | pineapple, fruit, food, tropical |
| 🏓 | `:table_tennis:`, `:ping_pong:` | table, tennis, paddle, and, ball, game, ball, sport, ping, pong |
| ♓ | `:pisces:` | pisces, zodiac, symbol |
| 🍕 | `:pizza:` | slice, of, pizza, italian, food, boys, night, boys, night |
| 🛐 | `:worship_symbol:`, `:place_of_worship:` | place, of, worship, religion, symbol, pray, pray |
| ⏯ | `:play_pause:` | black, right-pointing, double, triangle, with, double, vertical, bar, arrow, symbol |
| 👇 | `:point_down:` | white, down, pointing, backhand, index, body, hands, diversity, diversity |
| 👇🏻 | `:point_down_tone1:` | white, down, pointing, backhand, index, tone, 1 |
| 👇🏼 | `:point_down_tone2:` | white, down, pointing, backhand, index, tone, 2 |
| 👇🏽 | `:point_down_tone3:` | white, down, pointing, backhand, index, tone, 3 |
| 👇🏾 | `:point_down_tone4:` | white, down, pointing, backhand, index, tone, 4 |
| 👇🏿 | `:point_down_tone5:` | white, down, pointing, backhand, index, tone, 5 |
| 👈 | `:point_left:` | white, left, pointing, backhand, index, body, hands, hi, diversity, diversity |
| 👈🏻 | `:point_left_tone1:` | white, left, pointing, backhand, index, tone, 1 |
| 👈🏼 | `:point_left_tone2:` | white, left, pointing, backhand, index, tone, 2 |
| 👈🏽 | `:point_left_tone3:` | white, left, pointing, backhand, index, tone, 3 |
| 👈🏾 | `:point_left_tone4:` | white, left, pointing, backhand, index, tone, 4 |
| 👈🏿 | `:point_left_tone5:` | white, left, pointing, backhand, index, tone, 5 |
| 👉 | `:point_right:` | white, right, pointing, backhand, index, body, hands, hi, diversity, diversity |
| 👉🏻 | `:point_right_tone1:` | white, right, pointing, backhand, index, tone, 1 |
| 👉🏼 | `:point_right_tone2:` | white, right, pointing, backhand, index, tone, 2 |
| 👉🏽 | `:point_right_tone3:` | white, right, pointing, backhand, index, tone, 3 |
| 👉🏾 | `:point_right_tone4:` | white, right, pointing, backhand, index, tone, 4 |
| 👉🏿 | `:point_right_tone5:` | white, right, pointing, backhand, index, tone, 5 |
| ☝ | `:point_up:` | white, up, pointing, index, body, hands, emojione, diversity, diversity |
| 👆 | `:point_up_2:` | white, up, pointing, backhand, index, body, hands, diversity, diversity |
| 👆🏻 | `:point_up_2_tone1:` | white, up, pointing, backhand, index, tone, 1 |
| 👆🏼 | `:point_up_2_tone2:` | white, up, pointing, backhand, index, tone, 2 |
| 👆🏽 | `:point_up_2_tone3:` | white, up, pointing, backhand, index, tone, 3 |
| 👆🏾 | `:point_up_2_tone4:` | white, up, pointing, backhand, index, tone, 4 |
| 👆🏿 | `:point_up_2_tone5:` | white, up, pointing, backhand, index, tone, 5 |
| ☝🏻 | `:point_up_tone1:` | white, up, pointing, index, tone, 1 |
| ☝🏼 | `:point_up_tone2:` | white, up, pointing, index, tone, 2 |
| ☝🏽 | `:point_up_tone3:` | white, up, pointing, index, tone, 3 |
| ☝🏾 | `:point_up_tone4:` | white, up, pointing, index, tone, 4 |
| ☝🏿 | `:point_up_tone5:` | white, up, pointing, index, tone, 5 |
| 🚓 | `:police_car:` | police, car, transportation, car, police, police, 911, 911 |
| 🐩 | `:poodle:` | poodle, dog, dog, animal, animal |
| 🍿 | `:popcorn:` | popcorn, food, parties, parties |
| 🏣 | `:post_office:` | japanese, post, office, places, building, post, office |
| 📯 | `:postal_horn:` | postal, horn, object |
| 📮 | `:postbox:` | postbox, object |
| 🚰 | `:potable_water:` | potable, water, symbol, symbol |
| 🥔 | `:potato:` | potato |
| 👝 | `:pouch:` | pouch, bag, women, fashion, accessories |
| 🍗 | `:poultry_leg:` | poultry, leg, food, holidays |
| 💷 | `:pound:` | banknote, with, pound, sign, money, money |
| 😾 | `:pouting_cat:` | pouting, cat, face, cat, cat, animal, animal |
| 🙏 | `:pray:` | person, with, folded, hands, body, hands, hi, luck, thank, you, pray, pray, diversity, diversity, scientology, scientology |
| 🙏🏻 | `:pray_tone1:` | person, with, folded, hands, tone, 1 |
| 🙏🏼 | `:pray_tone2:` | person, with, folded, hands, tone, 2 |
| 🙏🏽 | `:pray_tone3:` | person, with, folded, hands, tone, 3 |
| 🙏🏾 | `:pray_tone4:` | person, with, folded, hands, tone, 4 |
| 🙏🏿 | `:pray_tone5:` | person, with, folded, hands, tone, 5 |
| 📿 | `:prayer_beads:` | prayer, beads, object, rosary |
| ⏮ | `:previous_track:`, `:track_previous:` | black, left-pointing, double, triangle, with, vertical, bar, arrow, symbol |
| 🤴 | `:prince:` | prince |
| 🤴🏻 | `:prince_tone1:` | prince, tone, 1 |
| 🤴🏼 | `:prince_tone2:` | prince, tone, 2 |
| 🤴🏽 | `:prince_tone3:` | prince, tone, 3 |
| 🤴🏾 | `:prince_tone4:` | prince, tone, 4 |
| 🤴🏿 | `:prince_tone5:` | prince, tone, 5 |
| 👸 | `:princess:` | princess, people, women, diversity, diversity, beautiful, beautiful, girls, night, girls, night |
| 👸🏻 | `:princess_tone1:` | princess, tone, 1 |
| 👸🏼 | `:princess_tone2:` | princess, tone, 2 |
| 👸🏽 | `:princess_tone3:` | princess, tone, 3 |
| 👸🏾 | `:princess_tone4:` | princess, tone, 4 |
| 👸🏿 | `:princess_tone5:` | princess, tone, 5 |
| 🖨 | `:printer:` | printer, electronics, work, office |
| 👊 | `:punch:` | fisted, hand, sign, body, hands, hi, fist, bump, diversity, diversity, boys, night, boys, night |
| 👊🏻 | `:punch_tone1:` | fisted, hand, sign, tone, 1 |
| 👊🏼 | `:punch_tone2:` | fisted, hand, sign, tone, 2 |
| 👊🏽 | `:punch_tone3:` | fisted, hand, sign, tone, 3 |
| 👊🏾 | `:punch_tone4:` | fisted, hand, sign, tone, 4 |
| 👊🏿 | `:punch_tone5:` | fisted, hand, sign, tone, 5 |
| 💜 | `:purple_heart:` | purple, heart, love, symbol |
| 👛 | `:purse:` | purse, bag, women, fashion, accessories, money, money |
| 📌 | `:pushpin:` | pushpin, object, office |
| 🚮 | `:put_litter_in_its_place:` | put, litter, in, its, place, symbol, symbol |
| ❓ | `:question:` | black, question, mark, ornament, symbol, punctuation, wth, wth |
| 🐰 | `:rabbit:` | rabbit, face, wildlife, animal, animal |
| 🐇 | `:rabbit2:` | rabbit, wildlife, animal, animal |
| 🏎 | `:racing_car:`, `:race_car:` | racing, car, transportation, car |
| 🐎 | `:racehorse:` | horse, wildlife, animal, animal |
| 📻 | `:radio:` | radio, electronics |
| 🔘 | `:radio_button:` | radio, button, symbol, circle, circle |
| ☢ | `:radioactive_sign:`, `:radioactive:` | radioactive, sign, symbol, science |
| 😡 | `:rage:` | pouting, face, mad, smiley, angry, emotion, emotion |
| 🛤 | `:railroad_track:`, `:railway_track:` | railway, track, travel, train, vacation |
| 🚃 | `:railway_car:` | railway, car, transportation, travel, train |
| 🌈 | `:rainbow:` | rainbow, weather, gay, sky, rain |
| ✋ | `:raised_hand:` | raised, hand, body, hands, hi, diversity, diversity, girls, night, girls, night |
| ✋🏻 | `:raised_hand_tone1:` | raised, hand, tone, 1 |
| ✋🏼 | `:raised_hand_tone2:` | raised, hand, tone, 2 |
| ✋🏽 | `:raised_hand_tone3:` | raised, hand, tone, 3 |
| ✋🏾 | `:raised_hand_tone4:` | raised, hand, tone, 4 |
| ✋🏿 | `:raised_hand_tone5:` | raised, hand, tone, 5 |
| 🖖 | `:raised_hand_with_part_between_middle_and_ring_fingers:`, `:vulcan:` | raised, hand, with, part, between, middle, and, ring, fingers, body, hands, hi, diversity, diversity |
| 🖖🏻 | `:raised_hand_with_part_between_middle_and_ring_fingers_tone1:`, `:vulcan_tone1:` | raised, hand, with, part, between, middle, and, ring, fingers, tone, 1 |
| 🖖🏼 | `:raised_hand_with_part_between_middle_and_ring_fingers_tone2:`, `:vulcan_tone2:` | raised, hand, with, part, between, middle, and, ring, fingers, tone, 2 |
| 🖖🏽 | `:raised_hand_with_part_between_middle_and_ring_fingers_tone3:`, `:vulcan_tone3:` | raised, hand, with, part, between, middle, and, ring, fingers, tone, 3 |
| 🖖🏾 | `:raised_hand_with_part_between_middle_and_ring_fingers_tone4:`, `:vulcan_tone4:` | raised, hand, with, part, between, middle, and, ring, fingers, tone, 4 |
| 🖖🏿 | `:raised_hand_with_part_between_middle_and_ring_fingers_tone5:`, `:vulcan_tone5:` | raised, hand, with, part, between, middle, and, ring, fingers, tone, 5 |
| 🙌 | `:raised_hands:` | person, raising, both, hands, in, celebration, body, hands, diversity, diversity, perfect, perfect, good, good, parties, parties |
| 🙌🏻 | `:raised_hands_tone1:` | person, raising, both, hands, in, celebration, tone, 1 |
| 🙌🏼 | `:raised_hands_tone2:` | person, raising, both, hands, in, celebration, tone, 2 |
| 🙌🏽 | `:raised_hands_tone3:` | person, raising, both, hands, in, celebration, tone, 3 |
| 🙌🏾 | `:raised_hands_tone4:` | person, raising, both, hands, in, celebration, tone, 4 |
| 🙌🏿 | `:raised_hands_tone5:` | person, raising, both, hands, in, celebration, tone, 5 |
| 🙋 | `:raising_hand:` | happy, person, raising, one, hand, people, women, diversity, diversity |
| 🙋🏻 | `:raising_hand_tone1:` | happy, person, raising, one, hand, tone1 |
| 🙋🏼 | `:raising_hand_tone2:` | happy, person, raising, one, hand, tone2 |
| 🙋🏽 | `:raising_hand_tone3:` | happy, person, raising, one, hand, tone3 |
| 🙋🏾 | `:raising_hand_tone4:` | happy, person, raising, one, hand, tone4 |
| 🙋🏿 | `:raising_hand_tone5:` | happy, person, raising, one, hand, tone5 |
| 🐏 | `:ram:` | ram, wildlife, animal, animal |
| 🍜 | `:ramen:` | steaming, bowl, noodles, ramen, japan, food |
| 🐀 | `:rat:` | rat, animal, animal |
| ⏺ | `:record_button:` | black, circle, for, record, symbol, circle, circle |
| ♻ | `:recycle:` | black, universal, recycling, symbol, symbol |
| 🚗 | `:red_car:` | automobile, transportation, car, travel |
| 🔴 | `:red_circle:` | large, red, circle, shapes, symbol, circle, circle |
| 🇦 | `:regional_indicator_a:` | regional, indicator, symbol, letter, a |
| 🇧 | `:regional_indicator_b:` | regional, indicator, symbol, letter, b |
| 🇨 | `:regional_indicator_c:` | regional, indicator, symbol, letter, c |
| 🇩 | `:regional_indicator_d:` | regional, indicator, symbol, letter, d |
| 🇪 | `:regional_indicator_e:` | regional, indicator, symbol, letter, e |
| 🇫 | `:regional_indicator_f:` | regional, indicator, symbol, letter, f |
| 🇬 | `:regional_indicator_g:` | regional, indicator, symbol, letter, g |
| 🇭 | `:regional_indicator_h:` | regional, indicator, symbol, letter, h |
| 🇮 | `:regional_indicator_i:` | regional, indicator, symbol, letter, i |
| 🇯 | `:regional_indicator_j:` | regional, indicator, symbol, letter, j |
| 🇰 | `:regional_indicator_k:` | regional, indicator, symbol, letter, k |
| 🇱 | `:regional_indicator_l:` | regional, indicator, symbol, letter, l |
| 🇲 | `:regional_indicator_m:` | regional, indicator, symbol, letter, m |
| 🇳 | `:regional_indicator_n:` | regional, indicator, symbol, letter, n |
| 🇴 | `:regional_indicator_o:` | regional, indicator, symbol, letter, o |
| 🇵 | `:regional_indicator_p:` | regional, indicator, symbol, letter, p |
| 🇶 | `:regional_indicator_q:` | regional, indicator, symbol, letter, q |
| 🇷 | `:regional_indicator_r:` | regional, indicator, symbol, letter, r |
| 🇸 | `:regional_indicator_s:` | regional, indicator, symbol, letter, s |
| 🇹 | `:regional_indicator_t:` | regional, indicator, symbol, letter, t |
| 🇺 | `:regional_indicator_u:` | regional, indicator, symbol, letter, u |
| 🇻 | `:regional_indicator_v:` | regional, indicator, symbol, letter, v |
| 🇼 | `:regional_indicator_w:` | regional, indicator, symbol, letter, w |
| 🇽 | `:regional_indicator_x:` | regional, indicator, symbol, letter, x |
| 🇾 | `:regional_indicator_y:` | regional, indicator, symbol, letter, y |
| 🇿 | `:regional_indicator_z:` | regional, indicator, symbol, letter, z |
| ® | `:registered:` | registered, sign, symbol |
| ☺ | `:relaxed:` | white, smiling, face, happy, smiley |
| 😌 | `:relieved:` | relieved, face, smiley, emotion, emotion |
| 🎗 | `:reminder_ribbon:` | reminder, ribbon, award |
| 🔁 | `:repeat:` | clockwise, rightwards, and, leftwards, open, circle, arrows, arrow, symbol |
| 🔂 | `:repeat_one:` | clockwise, rightwards, and, leftwards, open, circle, arrows, with, circled, one, overlay, arrow, symbol |
| 🚻 | `:restroom:` | restroom, symbol |
| 💞 | `:revolving_hearts:` | revolving, hearts, love, symbol |
| ⏪ | `:rewind:` | black, left-pointing, double, triangle, arrow, symbol |
| 🦏 | `:rhinoceros:`, `:rhino:` | rhinoceros |
| 🎀 | `:ribbon:` | ribbon, object, gift, birthday |
| 🍚 | `:rice:` | cooked, rice, sushi, japan, food |
| 🍙 | `:rice_ball:` | rice, ball, sushi, japan, food |
| 🍘 | `:rice_cracker:` | rice, cracker, sushi, food |
| 🎑 | `:rice_scene:` | moon, viewing, ceremony, places, space, sky, travel |
| 🤜 | `:right_fist:`, `:right_facing_fist:` | right-facing, fist |
| 🤜🏻 | `:right_fist_tone1:`, `:right_facing_fist_tone1:` | right, facing, fist, tone, 1 |
| 🤜🏼 | `:right_fist_tone2:`, `:right_facing_fist_tone2:` | right, facing, fist, tone, 2 |
| 🤜🏽 | `:right_fist_tone3:`, `:right_facing_fist_tone3:` | right, facing, fist, tone, 3 |
| 🤜🏾 | `:right_fist_tone4:`, `:right_facing_fist_tone4:` | right, facing, fist, tone, 4 |
| 🤜🏿 | `:right_fist_tone5:`, `:right_facing_fist_tone5:` | right, facing, fist, tone, 5 |
| 💍 | `:ring:` | ring, wedding, object, fashion, gem, accessories |
| 🤖 | `:robot_face:`, `:robot:` | robot, face, monster, robot |
| 🚀 | `:rocket:` | rocket, transportation, object, space, fly, fly, blast, blast |
| 🤣 | `:rolling_on_the_floor_laughing:`, `:rofl:` | rolling, on, the, floor, laughing |
| 🎢 | `:roller_coaster:` | roller, coaster, places, vacation, roller, coaster |
| 🐓 | `:rooster:` | rooster, animal, animal |
| 🌹 | `:rose:` | rose, nature, flower, plant, rip, rip, condolence, condolence, beautiful, beautiful |
| 🏵 | `:rosette:` | rosette, tropical |
| 🚨 | `:rotating_light:` | police, cars, revolving, light, transportation, object, police, police, 911, 911 |
| 📍 | `:round_pushpin:` | round, pushpin, object, office |
| 🚣 | `:rowboat:` | rowboat, men, workout, sport, rowing, diversity, diversity |
| 🚣🏻 | `:rowboat_tone1:` | rowboat, tone, 1 |
| 🚣🏼 | `:rowboat_tone2:` | rowboat, tone, 2 |
| 🚣🏽 | `:rowboat_tone3:` | rowboat, tone, 3 |
| 🚣🏾 | `:rowboat_tone4:` | rowboat, tone, 4 |
| 🚣🏿 | `:rowboat_tone5:` | rowboat, tone, 5 |
| 🏉 | `:rugby_football:` | rugby, football, game, sport, football |
| 🏃 | `:runner:` | runner, people, men, diversity, diversity, boys, night, boys, night, run, run |
| 🏃🏻 | `:runner_tone1:` | runner, tone, 1 |
| 🏃🏼 | `:runner_tone2:` | runner, tone, 2 |
| 🏃🏽 | `:runner_tone3:` | runner, tone, 3 |
| 🏃🏾 | `:runner_tone4:` | runner, tone, 4 |
| 🏃🏿 | `:runner_tone5:` | runner, tone, 5 |
| 🎽 | `:running_shirt_with_sash:` | running, shirt, with, sash, award |
| 🈂 | `:sa:` | squared, katakana, sa, symbol |
| ♐ | `:sagittarius:` | sagittarius, zodiac, symbol |
| ⛵ | `:sailboat:` | sailboat, transportation, travel, boat, vacation |
| 🍶 | `:sake:` | sake, bottle, and, cup, drink, japan, sake, alcohol, girls, night, girls, night |
| 👡 | `:sandal:` | womans, sandal, fashion, shoe, accessories |
| 🎅 | `:santa:` | father, christmas, people, hat, winter, holidays, christmas, diversity, diversity, santa, santa |
| 🎅🏻 | `:santa_tone1:` | father, christmas, tone, 1 |
| 🎅🏼 | `:santa_tone2:` | father, christmas, tone, 2 |
| 🎅🏽 | `:santa_tone3:` | father, christmas, tone, 3 |
| 🎅🏾 | `:santa_tone4:` | father, christmas, tone, 4 |
| 🎅🏿 | `:santa_tone5:` | father, christmas, tone, 5 |
| 📡 | `:satellite:` | satellite, antenna, object |
| 🛰 | `:satellite_orbital:` | satellite, object |
| 🎷 | `:saxophone:` | saxophone, instruments |
| ⚖ | `:scales:` | scales, object |
| 🏫 | `:school:` | school, places, building |
| 🎒 | `:school_satchel:` | school, satchel, bag, fashion, office, vacation, accessories |
| ✂ | `:scissors:` | black, scissors, object, tool, weapon, office |
| 🛴 | `:scooter:` | scooter |
| 🦂 | `:scorpion:` | scorpion, insects, reptile, reptile, animal, animal |
| ♏ | `:scorpius:` | scorpius, zodiac, symbol |
| 😱 | `:scream:` | face, screaming, in, fear, smiley, surprised, wow, wow, emotion, emotion, omg, omg |
| 🙀 | `:scream_cat:` | weary, cat, face, cat, cat, animal, animal |
| 📜 | `:scroll:` | scroll, object, office |
| 💺 | `:seat:` | seat, transportation, object, travel, vacation |
| 🥈 | `:second_place_medal:`, `:second_place:` | second, place, medal |
| ㊙ | `:secret:` | circled, ideograph, secret, japan, symbol |
| 🙈 | `:see_no_evil:` | see-no-evil, monkey, animal, animal |
| 🌱 | `:seedling:` | seedling, nature, plant, leaf, leaf |
| 🤳 | `:selfie:` | selfie |
| 🤳🏻 | `:selfie_tone1:` | selfie, tone, 1 |
| 🤳🏼 | `:selfie_tone2:` | selfie, tone, 2 |
| 🤳🏽 | `:selfie_tone3:` | selfie, tone, 3 |
| 🤳🏾 | `:selfie_tone4:` | selfie, tone, 4 |
| 🤳🏿 | `:selfie_tone5:` | selfie, tone, 5 |
| 7⃣ | `:seven:` | keycap, digit, seven, number, math, symbol |
| ☘ | `:shamrock:` | shamrock, nature, plant, luck, leaf, leaf |
| 🦈 | `:shark:` | shark |
| 🍧 | `:shaved_ice:` | shaved, ice, food |
| 🐑 | `:sheep:` | sheep, animal, animal |
| 🐚 | `:shell:` | spiral, shell |
| 🛡 | `:shield:` | shield, object |
| ⛩ | `:shinto_shrine:` | shinto, shrine, places, building, travel, vacation |
| 🚢 | `:ship:` | ship, transportation, travel, boat, vacation |
| 👕 | `:shirt:` | t-shirt, fashion |
| 🛍 | `:shopping_bags:` | shopping, bags, object, birthday, parties, parties |
| 🛒 | `:shopping_trolley:`, `:shopping_cart:` | shopping, trolley |
| 🚿 | `:shower:` | shower, object, bathroom |
| 🦐 | `:shrimp:` | shrimp |
| 🤷 | `:shrug:` | shrug |
| 🤷🏻 | `:shrug_tone1:` | shrug, tone, 1 |
| 🤷🏼 | `:shrug_tone2:` | shrug, tone, 2 |
| 🤷🏽 | `:shrug_tone3:` | shrug, tone, 3 |
| 🤷🏾 | `:shrug_tone4:` | shrug, tone, 4 |
| 🤷🏿 | `:shrug_tone5:` | shrug, tone, 5 |
| 📶 | `:signal_strength:` | antenna, with, bars, symbol |
| 6⃣ | `:six:` | keycap, digit, six, number, math, symbol |
| 🔯 | `:six_pointed_star:` | six, pointed, star, with, middle, dot, religion, jew, star, symbol |
| 💀 | `:skeleton:`, `:skull:` | skull, dead, halloween, skull |
| 🎿 | `:ski:` | ski, and, ski, boot, cold, sport, skiing |
| ⛷ | `:skier:` | skier, hat, vacation, cold, sport, skiing |
| ☠ | `:skull_and_crossbones:`, `:skull_crossbones:` | skull, and, crossbones, symbol, dead, skull |
| 😴 | `:sleeping:` | sleeping, face, smiley, tired, emotion, emotion, goodnight, goodnight |
| 🛌 | `:sleeping_accommodation:` | sleeping, accommodation, tired |
| 😪 | `:sleepy:` | sleepy, face, smiley, sick, emotion, emotion |
| 🕵 | `:sleuth_or_spy:`, `:spy:` | sleuth, or, spy, people, hat, men, glasses, diversity, diversity, job, job |
| 🕵🏻 | `:sleuth_or_spy_tone1:`, `:spy_tone1:` | sleuth, or, spy, tone, 1 |
| 🕵🏼 | `:sleuth_or_spy_tone2:`, `:spy_tone2:` | sleuth, or, spy, tone, 2 |
| 🕵🏽 | `:sleuth_or_spy_tone3:`, `:spy_tone3:` | sleuth, or, spy, tone, 3 |
| 🕵🏾 | `:sleuth_or_spy_tone4:`, `:spy_tone4:` | sleuth, or, spy, tone, 4 |
| 🕵🏿 | `:sleuth_or_spy_tone5:`, `:spy_tone5:` | sleuth, or, spy, tone, 5 |
| 🙁 | `:slightly_frowning_face:`, `:slight_frown:` | slightly, frowning, face, sad, smiley, emotion, emotion |
| 🙂 | `:slightly_smiling_face:`, `:slight_smile:` | slightly, smiling, face, happy, smiley |
| 🎰 | `:slot_machine:` | slot, machine, game, boys, night, boys, night |
| 🔹 | `:small_blue_diamond:` | small, blue, diamond, shapes, symbol |
| 🔸 | `:small_orange_diamond:` | small, orange, diamond, shapes, symbol |
| 🔺 | `:small_red_triangle:` | up-pointing, red, triangle, shapes, symbol, triangle, triangle |
| 🔻 | `:small_red_triangle_down:` | down-pointing, red, triangle, shapes, symbol, triangle, triangle |
| 😄 | `:smile:` | smiling, face, with, open, mouth, and, smiling, eyes, happy, smiley, emotion, emotion |
| 😸 | `:smile_cat:` | grinning, cat, face, with, smiling, eyes, happy, cat, cat, animal, animal |
| 😃 | `:smiley:` | smiling, face, with, open, mouth, happy, smiley, emotion, emotion, good, good |
| 😺 | `:smiley_cat:` | smiling, cat, face, with, open, mouth, happy, cat, cat, animal, animal |
| 😈 | `:smiling_imp:` | smiling, face, with, horns, silly, smiley, angry, monster, devil, devil, boys, night, boys, night |
| 😏 | `:smirk:` | smirking, face, silly, smiley, sexy, sarcastic, sarcastic |
| 😼 | `:smirk_cat:` | cat, face, with, wry, smile, cat, cat, animal, animal |
| 🚬 | `:smoking:` | smoking, symbol, symbol, drugs, drugs, smoking, smoking |
| 🐌 | `:snail:` | snail, insects, animal, animal |
| 🐍 | `:snake:` | snake, wildlife, reptile, reptile, animal, animal, creationism, creationism |
| 🤧 | `:sneeze:`, `:sneezing_face:` | sneezing, face |
| 🏂 | `:snowboarder:` | snowboarder, hat, vacation, cold, sport, snowboarding |
| ❄ | `:snowflake:` | snowflake, weather, winter, sky, holidays, cold, snow, snow |
| ⛄ | `:snowman:` | snowman, without, snow, weather, winter, holidays, cold, snow, snow |
| ☃ | `:snowman2:` | snowman, weather, winter, holidays, christmas, cold, snow, snow |
| 😭 | `:sob:` | loudly, crying, face, sad, smiley, cry, emotion, emotion, heartbreak, heartbreak |
| ⚽ | `:soccer:` | soccer, ball, game, ball, sport, soccer, football |
| 🔜 | `:soon:` | soon, with, rightwards, arrow, above, arrow, symbol |
| 🆘 | `:sos:` | squared, sos, symbol |
| 🔉 | `:sound:` | speaker, with, one, sound, wave, alarm, symbol |
| 👾 | `:space_invader:` | alien, monster, monster, alien |
| ♠ | `:spades:` | black, spade, suit, symbol, game |
| 🍝 | `:spaghetti:` | spaghetti, noodles, pasta, italian, food |
| ❇ | `:sparkle:` | sparkle, symbol |
| 🎇 | `:sparkler:` | firework, sparkler, parties, parties |
| ✨ | `:sparkles:` | sparkles, star, girls, night, girls, night |
| 💖 | `:sparkling_heart:` | sparkling, heart, love, symbol, girls, night, girls, night |
| 🙊 | `:speak_no_evil:` | speak-no-evil, monkey, animal, animal |
| 🔈 | `:speaker:` | speaker, alarm, symbol |
| 🗣 | `:speaking_head_in_silhouette:`, `:speaking_head:` | speaking, head, in, silhouette, people, talk |
| 💬 | `:speech_balloon:` | speech, balloon, symbol, free, speech, free, speech |
| 🚤 | `:speedboat:` | speedboat, transportation, travel, boat, vacation, tropical |
| 🕷 | `:spider:` | spider, insects, halloween, animal, animal |
| 🕸 | `:spider_web:` | spider, web, halloween |
| 🥄 | `:spoon:` | spoon |
| 🦑 | `:squid:` | squid |
| 🏟 | `:stadium:` | stadium, places, building, travel, vacation, boys, night, boys, night |
| ⭐ | `:star:` | white, medium, star, space, sky, star |
| 🌟 | `:star2:` | glowing, star, space, sky, star |
| ☪ | `:star_and_crescent:` | star, and, crescent, religion, symbol |
| ✡ | `:star_of_david:` | star, of, david, religion, jew, star, symbol |
| 🌠 | `:stars:` | shooting, star, space |
| 🚉 | `:station:` | station, transportation, travel, train |
| 🗽 | `:statue_of_liberty:` | statue, of, liberty, places, america, travel, vacation, statue, of, liberty, free, speech, free, speech |
| 🚂 | `:steam_locomotive:` | steam, locomotive, transportation, travel, train, steam, steam |
| 🍲 | `:stew:` | pot, of, food, food, steam, steam |
| ⏹ | `:stop_button:` | black, square, for, stop, symbol, square, square |
| ⏱ | `:stopwatch:` | stopwatch, electronics, time |
| 📏 | `:straight_ruler:` | straight, ruler, object, tool, office |
| 🍓 | `:strawberry:` | strawberry, fruit, food |
| 😛 | `:stuck_out_tongue:` | face, with, stuck-out, tongue, smiley, sex, emotion, emotion |
| 😝 | `:stuck_out_tongue_closed_eyes:` | face, with, stuck-out, tongue, and, tightly-closed, eyes, happy, smiley, emotion, emotion |
| 😜 | `:stuck_out_tongue_winking_eye:` | face, with, stuck-out, tongue, and, winking, eye, happy, smiley, emotion, emotion, parties, parties |
| 🥙 | `:stuffed_pita:`, `:stuffed_flatbread:` | stuffed, flatbread |
| 🌞 | `:sun_with_face:` | sun, with, face, sky, day, sun, hump, day, hump, day, morning, morning |
| 🌻 | `:sunflower:` | sunflower, nature, flower, plant |
| 😎 | `:sunglasses:` | smiling, face, with, sunglasses, silly, smiley, emojione, glasses, boys, night, boys, night |
| ☀ | `:sunny:` | black, sun, with, rays, weather, sky, day, sun, hot, hot, morning, morning |
| 🌅 | `:sunrise:` | sunrise, places, sky, travel, vacation, tropical, day, sun, hump, day, hump, day, morning, morning |
| 🌄 | `:sunrise_over_mountains:` | sunrise, over, mountains, places, sky, travel, vacation, day, sun, camp, morning, morning |
| 🏄 | `:surfer:` | surfer, men, vacation, tropical, sport, diversity, diversity |
| 🏄🏻 | `:surfer_tone1:` | surfer, tone, 1 |
| 🏄🏼 | `:surfer_tone2:` | surfer, tone, 2 |
| 🏄🏽 | `:surfer_tone3:` | surfer, tone, 3 |
| 🏄🏾 | `:surfer_tone4:` | surfer, tone, 4 |
| 🏄🏿 | `:surfer_tone5:` | surfer, tone, 5 |
| 🍣 | `:sushi:` | sushi, sushi, japan, food |
| 🚟 | `:suspension_railway:` | suspension, railway, transportation, travel, train |
| 😓 | `:sweat:` | face, with, cold, sweat, sad, smiley, stressed, sweat, emotion, emotion |
| 💦 | `:sweat_drops:` | splashing, sweat, symbol, rain, stressed, sweat |
| 😅 | `:sweat_smile:` | smiling, face, with, open, mouth, and, cold, sweat, smiley, workout, sweat, emotion, emotion |
| 🍠 | `:sweet_potato:` | roasted, sweet, potato, vegetables, food |
| 🏊 | `:swimmer:` | swimmer, workout, sport, swim, diversity, diversity |
| 🏊🏻 | `:swimmer_tone1:` | swimmer, tone, 1 |
| 🏊🏼 | `:swimmer_tone2:` | swimmer, tone, 2 |
| 🏊🏽 | `:swimmer_tone3:` | swimmer, tone, 3 |
| 🏊🏾 | `:swimmer_tone4:` | swimmer, tone, 4 |
| 🏊🏿 | `:swimmer_tone5:` | swimmer, tone, 5 |
| 🔣 | `:symbols:` | input, symbol, for, symbols, symbol |
| 🕍 | `:synagogue:` | synagogue, places, religion, building, travel, vacation, condolence, condolence |
| 💉 | `:syringe:` | syringe, object, weapon, health, drugs, drugs |
| 🌮 | `:taco:` | taco, food, mexican, vagina |
| 🎉 | `:tada:` | party, popper, object, birthday, holidays, cheers, good, good, girls, night, girls, night, boys, night, boys, night, parties, parties |
| 🎋 | `:tanabata_tree:` | tanabata, tree, nature, plant, trees, trees |
| 🍊 | `:tangerine:` | tangerine, fruit, food |
| ♉ | `:taurus:` | taurus, zodiac, symbol |
| 🚕 | `:taxi:` | taxi, transportation, car, travel |
| 🍵 | `:tea:` | teacup, without, handle, drink, japan, caffeine, steam, steam, morning, morning |
| ☎ | `:telephone:` | black, telephone, electronics, phone |
| 📞 | `:telephone_receiver:` | telephone, receiver, electronics, phone |
| 🔭 | `:telescope:` | telescope, object, space, science |
| 🎾 | `:tennis:` | tennis, racquet, and, ball, game, ball, sport, tennis |
| ⛺ | `:tent:` | tent, places, travel, vacation, camp |
| 🌡 | `:thermometer:` | thermometer, object, science, health, hot, hot |
| 🤔 | `:thinking_face:`, `:thinking:` | thinking, face, smiley, thinking, boys, night, boys, night |
| 🥉 | `:third_place_medal:`, `:third_place:` | third, place, medal |
| 💭 | `:thought_balloon:` | thought, balloon, symbol |
| 3⃣ | `:three:` | keycap, digit, three, number, math, symbol |
| ⛈ | `:thunder_cloud_and_rain:`, `:thunder_cloud_rain:` | thunder, cloud, and, rain, weather, sky, cloud, cold, rain |
| 🎫 | `:ticket:` | ticket, theatre, movie, parties, parties |
| 🐯 | `:tiger:` | tiger, face, wildlife, roar, cat, cat, animal, animal |
| 🐅 | `:tiger2:` | tiger, wildlife, roar, animal, animal |
| ⏲ | `:timer_clock:`, `:timer:` | timer, clock, object, time |
| 😫 | `:tired_face:` | tired, face, sad, smiley, tired, emotion, emotion |
| ™ | `:tm:` | trade, mark, sign, symbol |
| 🚽 | `:toilet:` | toilet, object, bathroom |
| 🗼 | `:tokyo_tower:` | tokyo, tower, places, travel, vacation, eiffel, tower |
| 🍅 | `:tomato:` | tomato, fruit, vegetables, food |
| 🏻 | `:tone1:` | emoji, modifier, Fitzpatrick, type-1-2 |
| 🏼 | `:tone2:` | emoji, modifier, Fitzpatrick, type-3 |
| 🏽 | `:tone3:` | emoji, modifier, Fitzpatrick, type-4 |
| 🏾 | `:tone4:` | emoji, modifier, Fitzpatrick, type-5 |
| 🏿 | `:tone5:` | emoji, modifier, Fitzpatrick, type-6 |
| 👅 | `:tongue:` | tongue, body, sexy, lip |
| 🔝 | `:top:` | top, with, upwards, arrow, above, arrow, symbol |
| 🎩 | `:tophat:` | top, hat, hat, fashion, accessories |
| 🖲 | `:trackball:` | trackball, electronics, work, game, office |
| 🚜 | `:tractor:` | tractor, transportation |
| 🚥 | `:traffic_light:` | horizontal, traffic, light, object, stop, light |
| 🚋 | `:train:` | tram, car, transportation, travel, train |
| 🚆 | `:train2:` | train, transportation, travel, train |
| 🚊 | `:tram:` | tram, transportation, travel, train |
| 🚩 | `:triangular_flag_on_post:` | triangular, flag, on, post, object |
| 📐 | `:triangular_ruler:` | triangular, ruler, object, tool, office |
| 🔱 | `:trident:` | trident, emblem, object, symbol |
| 😤 | `:triumph:` | face, with, look, of, triumph, mad, smiley, angry, emotion, emotion, steam, steam |
| 🚎 | `:trolleybus:` | trolleybus, transportation, bus, travel |
| 🏆 | `:trophy:` | trophy, object, game, award, win, win, perfect, perfect, parties, parties |
| 🍹 | `:tropical_drink:` | tropical, drink, drink, cocktail, tropical, alcohol |
| 🐠 | `:tropical_fish:` | tropical, fish, wildlife, animal, animal |
| 🚚 | `:truck:` | delivery, truck, transportation, truck |
| 🎺 | `:trumpet:` | trumpet, instruments |
| 🌷 | `:tulip:` | tulip, nature, flower, plant, vagina, girls, night, girls, night |
| 🥃 | `:whisky:`, `:tumbler_glass:` | tumbler, glass, booze |
| 🦃 | `:turkey:` | turkey, wildlife, animal, animal |
| 🐢 | `:turtle:` | turtle, wildlife, reptile, reptile, animal, animal |
| 📺 | `:tv:` | television, electronics |
| 🔀 | `:twisted_rightwards_arrows:` | twisted, rightwards, arrows, arrow, symbol |
| 2⃣ | `:two:` | keycap, digit, two, number, math, symbol |
| 💕 | `:two_hearts:` | two, hearts, love, symbol |
| 👬 | `:two_men_holding_hands:` | two, men, holding, hands, people, gay, men, sex, lgbt, lgbt |
| 👭 | `:two_women_holding_hands:` | two, women, holding, hands, people, women, sex, lgbt, lgbt, lesbian, lesbian, girls, night, girls, night |
| 🈹 | `:u5272:` | squared, cjk, unified, ideograph-5272, symbol |
| 🈴 | `:u5408:` | squared, cjk, unified, ideograph-5408, japan, symbol |
| 🈺 | `:u55b6:` | squared, cjk, unified, ideograph-55b6, symbol |
| 🈯 | `:u6307:` | squared, cjk, unified, ideograph-6307, symbol |
| 🈷 | `:u6708:` | squared, cjk, unified, ideograph-6708, symbol |
| 🈶 | `:u6709:` | squared, cjk, unified, ideograph-6709, symbol |
| 🈵 | `:u6e80:` | squared, cjk, unified, ideograph-6e80, japan, symbol |
| 🈚 | `:u7121:` | squared, cjk, unified, ideograph-7121, symbol |
| 🈸 | `:u7533:` | squared, cjk, unified, ideograph-7533, symbol |
| 🈲 | `:u7981:` | squared, cjk, unified, ideograph-7981, japan, symbol |
| 🈳 | `:u7a7a:` | squared, cjk, unified, ideograph-7a7a, symbol |
| ☔ | `:umbrella:` | umbrella, with, rain, drops, weather, sky, cold, rain |
| ☂ | `:umbrella2:` | umbrella, weather, object, sky, cold |
| 😒 | `:unamused:` | unamused, face, sad, mad, smiley, tired, emotion, emotion |
| 🔞 | `:underage:` | no, one, under, eighteen, symbol, symbol |
| 🦄 | `:unicorn_face:`, `:unicorn:` | unicorn, face, animal, animal |
| 🔓 | `:unlock:` | open, lock, object, lock |
| 🆙 | `:up:` | squared, up, with, exclamation, mark, symbol |
| 🙃 | `:upside_down_face:`, `:upside_down:` | upside-down, face, silly, smiley, sarcastic, sarcastic |
| ✌ | `:v:` | victory, hand, body, hands, hi, thank, you, peace, peace, diversity, diversity, girls, night, girls, night |
| ✌🏻 | `:v_tone1:` | victory, hand, tone, 1 |
| ✌🏼 | `:v_tone2:` | victory, hand, tone, 2 |
| ✌🏽 | `:v_tone3:` | victory, hand, tone, 3 |
| ✌🏾 | `:v_tone4:` | victory, hand, tone, 4 |
| ✌🏿 | `:v_tone5:` | victory, hand, tone, 5 |
| 🚦 | `:vertical_traffic_light:` | vertical, traffic, light, object, stop, light |
| 📼 | `:vhs:` | videocassette, electronics |
| 📳 | `:vibration_mode:` | vibration, mode, symbol |
| 📹 | `:video_camera:` | video, camera, electronics, camera, movie |
| 🎮 | `:video_game:` | video, game, electronics, game, boys, night, boys, night |
| 🎻 | `:violin:` | violin, instruments, sarcastic, sarcastic |
| ♍ | `:virgo:` | virgo, zodiac, symbol |
| 🌋 | `:volcano:` | volcano, places, tropical |
| 🏐 | `:volleyball:` | volleyball, game, ball, sport, volleyball |
| 🆚 | `:vs:` | squared, vs, symbol |
| 🚶 | `:walking:` | pedestrian, people, men, diversity, diversity |
| 🚶🏻 | `:walking_tone1:` | pedestrian, tone, 1 |
| 🚶🏼 | `:walking_tone2:` | pedestrian, tone, 2 |
| 🚶🏽 | `:walking_tone3:` | pedestrian, tone, 3 |
| 🚶🏾 | `:walking_tone4:` | pedestrian, tone, 4 |
| 🚶🏿 | `:walking_tone5:` | pedestrian, tone, 5 |
| 🌘 | `:waning_crescent_moon:` | waning, crescent, moon, symbol, space, sky, moon, moon |
| 🌖 | `:waning_gibbous_moon:` | waning, gibbous, moon, symbol, space, sky, moon, moon |
| ⚠ | `:warning:` | warning, sign, symbol, punctuation |
| 🗑 | `:wastebasket:` | wastebasket, object, work |
| ⌚ | `:watch:` | watch, electronics, time |
| 🐃 | `:water_buffalo:` | water, buffalo, wildlife, animal, animal |
| 🤽 | `:water_polo:` | water, polo |
| 🤽🏻 | `:water_polo_tone1:` | water, polo, tone, 1 |
| 🤽🏼 | `:water_polo_tone2:` | water, polo, tone, 2 |
| 🤽🏽 | `:water_polo_tone3:` | water, polo, tone, 3 |
| 🤽🏾 | `:water_polo_tone4:` | water, polo, tone, 4 |
| 🤽🏿 | `:water_polo_tone5:` | water, polo, tone, 5 |
| 🍉 | `:watermelon:` | watermelon, fruit, food |
| 👋 | `:wave:` | waving, hand, sign, body, hands, hi, diversity, diversity |
| 👋🏻 | `:wave_tone1:` | waving, hand, sign, tone, 1 |
| 👋🏼 | `:wave_tone2:` | waving, hand, sign, tone, 2 |
| 👋🏽 | `:wave_tone3:` | waving, hand, sign, tone, 3 |
| 👋🏾 | `:wave_tone4:` | waving, hand, sign, tone, 4 |
| 👋🏿 | `:wave_tone5:` | waving, hand, sign, tone, 5 |
| 〰 | `:wavy_dash:` | wavy, dash, symbol |
| 🌒 | `:waxing_crescent_moon:` | waxing, crescent, moon, symbol, space, sky, moon, moon |
| 🌔 | `:waxing_gibbous_moon:` | waxing, gibbous, moon, symbol, space, sky, moon, moon |
| 🚾 | `:wc:` | water, closet, symbol |
| 😩 | `:weary:` | weary, face, sad, smiley, tired, stressed, emotion, emotion |
| 💒 | `:wedding:` | wedding, places, wedding, building, love, parties, parties |
| 🐳 | `:whale:` | spouting, whale, wildlife, tropical, whales, whales, animal, animal |
| 🐋 | `:whale2:` | whale, wildlife, tropical, whales, whales, animal, animal |
| ☸ | `:wheel_of_dharma:` | wheel, of, dharma, religion, symbol |
| ♿ | `:wheelchair:` | wheelchair, symbol, symbol |
| ✅ | `:white_check_mark:` | white, heavy, check, mark, symbol |
| ⚪ | `:white_circle:` | medium, white, circle, shapes, symbol, circle, circle |
| 💮 | `:white_flower:` | white, flower, flower, symbol |
| ⬜ | `:white_large_square:` | white, large, square, shapes, symbol, square, square |
| ◽ | `:white_medium_small_square:` | white, medium, small, square, shapes, symbol, square, square |
| ◻ | `:white_medium_square:` | white, medium, square, shapes, symbol, square, square |
| ▫ | `:white_small_square:` | white, small, square, shapes, symbol, square, square |
| 🔳 | `:white_square_button:` | white, square, button, shapes, symbol, square, square |
| 🌥 | `:white_sun_behind_cloud:`, `:white_sun_cloud:` | white, sun, behind, cloud, weather, sky, cloud, cold, sun |
| 🌦 | `:white_sun_behind_cloud_with_rain:`, `:white_sun_rain_cloud:` | white, sun, behind, cloud, with, rain, weather, sky, cloud, cold, rain, sun |
| 🌤 | `:white_sun_with_small_cloud:`, `:white_sun_small_cloud:` | white, sun, with, small, cloud, weather, sky, cloud, sun |
| 🥀 | `:wilted_flower:`, `:wilted_rose:` | wilted, flower |
| 🌬 | `:wind_blowing_face:` | wind, blowing, face, weather, cold |
| 🎐 | `:wind_chime:` | wind, chime, object, japan |
| 🍷 | `:wine_glass:` | wine, glass, drink, italian, alcohol, girls, night, girls, night, parties, parties |
| 😉 | `:wink:` | winking, face, silly, smiley, emotion, emotion |
| 🐺 | `:wolf:` | wolf, face, wildlife, roar, animal, animal |
| 👩 | `:woman:` | woman, people, women, sex, diversity, diversity, feminist, feminist, selfie, selfie, girls, night, girls, night |
| 👩🏻 | `:woman_tone1:` | woman, tone, 1 |
| 👩🏼 | `:woman_tone2:` | woman, tone, 2 |
| 👩🏽 | `:woman_tone3:` | woman, tone, 3 |
| 👩🏾 | `:woman_tone4:` | woman, tone, 4 |
| 👩🏿 | `:woman_tone5:` | woman, tone, 5 |
| 👚 | `:womans_clothes:` | womans, clothes, women, fashion |
| 👒 | `:womans_hat:` | womans, hat, women, fashion, accessories |
| 🚺 | `:womens:` | womens, symbol, symbol |
| 😟 | `:worried:` | worried, face, sad, smiley, emotion, emotion |
| 🔧 | `:wrench:` | wrench, object, tool |
| 🤼 | `:wrestling:`, `:wrestlers:` | wrestlers |
| 🤼🏻 | `:wrestling_tone1:`, `:wrestlers_tone1:` | wrestlers, tone, 1 |
| 🤼🏼 | `:wrestling_tone2:`, `:wrestlers_tone2:` | wrestlers, tone, 2 |
| 🤼🏽 | `:wrestling_tone3:`, `:wrestlers_tone3:` | wrestlers, tone, 3 |
| 🤼🏾 | `:wrestling_tone4:`, `:wrestlers_tone4:` | wrestlers, tone, 4 |
| 🤼🏿 | `:wrestling_tone5:`, `:wrestlers_tone5:` | wrestlers, tone, 5 |
| ✍ | `:writing_hand:` | writing, hand, body, hands, write, diversity, diversity |
| ✍🏻 | `:writing_hand_tone1:` | writing, hand, tone, 1 |
| ✍🏼 | `:writing_hand_tone2:` | writing, hand, tone, 2 |
| ✍🏽 | `:writing_hand_tone3:` | writing, hand, tone, 3 |
| ✍🏾 | `:writing_hand_tone4:` | writing, hand, tone, 4 |
| ✍🏿 | `:writing_hand_tone5:` | writing, hand, tone, 5 |
| ❌ | `:x:` | cross, mark, symbol, sol, sol |
| 💛 | `:yellow_heart:` | yellow, heart, love, symbol |
| 💴 | `:yen:` | banknote, with, yen, sign, money, money |
| ☯ | `:yin_yang:` | yin, yang, symbol |
| 😋 | `:yum:` | face, savouring, delicious, food, happy, silly, smiley, emotion, emotion, sarcastic, sarcastic, good, good |
| ⚡ | `:zap:` | high, voltage, sign, weather, sky, diarrhea, diarrhea |
| 0⃣ | `:zero:` | keycap, digit, zero, number, math, symbol |
| 🤐 | `:zipper_mouth_face:`, `:zipper_mouth:` | zipper-mouth, face, mad, smiley |
| 💤 | `:zzz:` | sleeping, symbol, tired, goodnight, goodnight |
